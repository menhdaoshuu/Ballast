#!/system/bin/sh
# Ballast v6.0 Apex - Early Boot LMKD PSI & ART dex2oat Space-Balanced Tuning
MODDIR=${0%/*}
CONF="/data/adb/ksu_mem_opt.conf"
ENABLE_LMKD_PSI=1
ENABLE_ART_OPT=1
[ -f "$CONF" ] && . "$CONF"

if command -v resetprop >/dev/null 2>&1; then
    if [ "$ENABLE_LMKD_PSI" = "1" ]; then
        resetprop -n ro.lmk.use_psi true
        resetprop -n ro.lmk.use_minfree_levels false
        resetprop -n ro.lmk.psi_partial_stall_ms 150
        resetprop -n ro.lmk.psi_complete_stall_ms 700
        resetprop -n ro.lmk.thrashing_limit 120
        resetprop -n ro.lmk.thrashing_limit_decay 10
        resetprop -n ro.lmk.swap_free_low_percentage 10
        resetprop -n ro.lmk.swap_compression_ratio 2
        resetprop -n ro.lmk.kill_heaviest_task true
        setprop lmkd.reinit 1 2>/dev/null
    fi
    if [ "$ENABLE_ART_OPT" = "1" ]; then
        # Keep hot paths fast with speed-profile while avoiding bloated 'everything' .odex file-page mappings
        resetprop -n pm.dexopt.bg-dexopt speed-profile
        resetprop -n pm.dexopt.install speed-profile
        resetprop -n pm.dexopt.first-boot verify
        resetprop -n pm.dexopt.boot-after-ota verify
        # v6.5.4: 借用紧凑堆回收策略，逼迫 system_server/systemui 与所有 Java 进程及时归还闲置堆内存给内核（不降低 heapsize 上限，零 OOM 风险）
        resetprop -n dalvik.vm.heapminfree 2m
        resetprop -n dalvik.vm.heapmaxfree 8m
        resetprop -n dalvik.vm.heaptargetutilization 0.75
    fi
fi
exit 0
