#!/system/bin/sh
# Ballast (压舱石) 跨系统适配信息一键扫描脚本
# 安装后位于系统目录 /system/bin/ballast_probe 及 /data/adb/ksu/bin/ballast_probe
# 用法: su -c ballast_probe
# 输出: /storage/emulated/0/Ballast_ROM_Probe_<Brand>_<Model>_<Timestamp>.txt

TS=$(date '+%Y%m%d_%H%M%S' 2>/dev/null || echo "00000000_000000")
BRAND=$(getprop ro.product.brand 2>/dev/null | tr -cd 'A-Za-z0-9._-')
MODEL=$(getprop ro.product.model 2>/dev/null | tr -cd 'A-Za-z0-9._-')
[ -z "$BRAND" ] && BRAND="Android"
[ -z "$MODEL" ] && MODEL="Device"

OUT_DIR="/storage/emulated/0"
[ -d "$OUT_DIR" ] || OUT_DIR="/sdcard"
mkdir -p "$OUT_DIR" 2>/dev/null
OUT_FILE="${OUT_DIR}/Ballast_ROM_Probe_${BRAND}_${MODEL}_${TS}.txt"

sec() {
    printf "\n==================== %s ====================\n" "$1"
}

echo "正在扫描系统适配信息，请稍候（约 3~5 秒）..."

{
    echo "Ballast (压舱石) 跨系统适配信息采集报告"
    echo "采集时间: $(date '+%Y-%m-%d %H:%M:%S' 2>/dev/null)"
    echo "说明: 已自动排除 IMEI / 序列号 / MAC / 手机号等个人隐私字段"

    sec "1. 设备 / ROM / 内核基础信息"
    echo "uname: $(uname -a 2>/dev/null)"
    for _p in \
        ro.product.brand ro.product.manufacturer ro.product.model ro.product.device \
        ro.product.board ro.hardware ro.soc.manufacturer ro.soc.model ro.product.cpu.abi \
        ro.build.version.release ro.build.version.sdk ro.build.display.id ro.build.fingerprint \
        ro.build.version.oplusrom ro.build.version.oplusrom.display \
        ro.mi.os.version.name ro.miui.ui.version.name \
        ro.vivo.os.version ro.vivo.os.build.display.id \
        ro.build.version.magic ro.build.version.emui \
        ro.build.version.oneui ro.build.version.sem \
        ro.flyme.version.id ro.build.version.zui ro.build.version.myos; do
        _v=$(getprop "$_p" 2>/dev/null)
        [ -n "$_v" ] && echo "${_p}=${_v}"
    done

    sec "2. Root 环境与基础工具"
    echo "id: $(id 2>/dev/null)"
    echo "ksud: $(ksud -V 2>/dev/null || echo none)"
    echo "magisk: $(magisk -v 2>/dev/null || echo none)"
    echo "apd: $(apd -V 2>/dev/null || echo none)"
    echo "resetprop: $(command -v resetprop 2>/dev/null || echo none)"
    echo "su_2000_test: $(su 2000 -c id 2>/dev/null || su -u 2000 -c id 2>/dev/null || su shell -c id 2>/dev/null || echo failed)"
    echo "backlight_nodes:"
    for _bl in /sys/class/backlight/*/brightness /sys/class/leds/lcd-backlight/brightness; do
        [ -r "$_bl" ] && echo "  $_bl = $(cat "$_bl" 2>/dev/null)"
    done

    sec "3. 物理内存 / Swap / ZRAM 拓扑"
    cat /proc/meminfo 2>/dev/null
    echo "--- /proc/swaps ---"
    cat /proc/swaps 2>/dev/null
    echo "--- /sys/block/zram0 ---"
    if [ -d /sys/block/zram0 ]; then
        for _zf in disksize comp_algorithm max_comp_streams mem_limit mm_stat bd_stat recomp_algorithm writeback_limit backing_dev; do
            [ -r "/sys/block/zram0/$_zf" ] && echo "${_zf}: $(cat "/sys/block/zram0/$_zf" 2>/dev/null)"
        done
    else
        echo "zram0 不存在"
    fi

    sec "4. 内核 VM / MGLRU / PSI 参数"
    for _vf in swappiness direct_swappiness page-cluster vfs_cache_pressure dirty_ratio dirty_background_ratio watermark_scale_factor min_free_kbytes extra_free_kbytes compact_unevictable_allowed; do
        [ -r "/proc/sys/vm/$_vf" ] && echo "vm.${_vf}=$(cat "/proc/sys/vm/$_vf" 2>/dev/null)"
    done
    [ -r /sys/kernel/mm/lru_gen/enabled ] && echo "mglru.enabled=$(cat /sys/kernel/mm/lru_gen/enabled 2>/dev/null)"
    [ -r /sys/kernel/mm/lru_gen/min_ttl_ms ] && echo "mglru.min_ttl_ms=$(cat /sys/kernel/mm/lru_gen/min_ttl_ms 2>/dev/null)"
    [ -r /proc/pressure/memory ] && { echo "--- /proc/pressure/memory ---"; cat /proc/pressure/memory 2>/dev/null; }

    sec "5. Cgroup 挂载与厂商内存控制节点"
    mount 2>/dev/null | grep -i cgroup
    echo "--- /sys/fs/cgroup 顶层 memory.* ---"
    for _cf in /sys/fs/cgroup/memory.*; do
        [ -r "$_cf" ] || continue
        echo ">>> $_cf"
        head -n 6 "$_cf" 2>/dev/null
    done
    echo "--- UID Cgroup 目录样本 ---"
    ls -d /sys/fs/cgroup/uid_* /sys/fs/cgroup/apps/uid_* /dev/memcg/* /sys/fs/cgroup/freezer* 2>/dev/null | head -n 25
    echo "--- 厂商特殊内存/墓碑内核节点 ---"
    ls -d /proc/*mem* /proc/*hans* /proc/*millet* /proc/*zram* /sys/module/*zram* /sys/module/*lmk* 2>/dev/null | head -n 40

    sec "6. LMKD / ART 堆 / Freezer / ActivityManager 配置"
    getprop 2>/dev/null | grep -iE '(\[ro\.lmk\.|\[dalvik\.vm\.heap|\[pm\.dexopt\.|\[persist\.sys\.zram|\[ro\.vendor\.qti\.sys\.fw|\[sys\.oplus\.|\[persist\.miui\.|\[persist\.vivo\.|\[persist\.sys\.hans|\[persist\.sys\.millet)' | sort | head -n 120
    echo "--- device_config activity_manager_native_boot ---"
    cmd device_config list activity_manager_native_boot 2>/dev/null | grep -iE 'freez|cache|phantom|oom|mem|bg' | head -n 40
    echo "--- device_config activity_manager ---"
    cmd device_config list activity_manager 2>/dev/null | grep -iE 'freez|cache|phantom|oom|mem|bg' | head -n 40
    echo "--- activity_manager_constants ---"
    settings get global activity_manager_constants 2>/dev/null

    sec "7. Top 45 内存占用进程 (RSS 降序) 与 dumpsys meminfo 摘要"
    ps -eo pid,uid,rss,args 2>/dev/null | sort -k3 -nr | head -n 45
    echo "--- dumpsys meminfo 摘要 ---"
    dumpsys meminfo 2>/dev/null | awk '/Total PSS by process:/,/^$/' | head -n 45

    sec "8. 系统厂商包名与穿戴/输入法/桌面/侧边栏清单"
    echo "--- 穿戴/健康/输入法/桌面/游戏/侧边栏相关包名 ---"
    (pm list packages -u 2>/dev/null || awk '{print "package:"$1}' /data/system/packages.list 2>/dev/null) | grep -iE 'launcher|home|keyboard|ime|input|health|wear|watch|band|accessory|mydevices|sidebar|game|voice|speech|breeno|xiaoai|jovi|yoyo|bixby' | sort | head -n 100
    echo "--- 厂商系统预装包名 (前 180 条) ---"
    (pm list packages -s 2>/dev/null || awk '{print "package:"$1}' /data/system/packages.list 2>/dev/null) | grep -iE 'oplus|heytap|coloros|oppo|oneplus|realme|miui|xiaomi|vivo|iqoo|honor|hihonor|huawei|samsung|sec\.|meizu|flyme|zui|nubia|zte|nothing' | sort | head -n 180

    sec "9. 后台内存显示 Settings 键与通知栏通道检测"
    echo "--- system (mem/ram/recent) ---"
    settings list system 2>/dev/null | grep -iE '(mem|ram|recent)' | grep -vE 'white_list|whitelist|wallpapers_inuse' | head -n 40
    echo "--- secure (mem/ram/recent) ---"
    settings list secure 2>/dev/null | grep -iE '(mem|ram|recent)' | grep -vE 'white_list|whitelist|wallpapers_inuse|no_frozen' | head -n 40
    echo "--- global (mem/ram/recent) ---"
    settings list global 2>/dev/null | grep -iE '(mem|ram|recent)' | grep -vE 'white_list|whitelist|wallpapers_inuse' | head -n 40
    echo "--- cmd notification list 能力测试 ---"
    if cmd notification list >/dev/null 2>&1; then
        echo "cmd notification list (uid 0): OK ($(cmd notification list 2>/dev/null | wc -l) active)"
    elif su 2000 -c "cmd notification list" >/dev/null 2>&1; then
        echo "cmd notification list (uid 2000): OK ($(su 2000 -c 'cmd notification list' 2>/dev/null | wc -l) active)"
    else
        echo "cmd notification list: UNAVAILABLE"
    fi

    sec "扫描完成"
} > "$OUT_FILE" 2>&1

chmod 0644 "$OUT_FILE" 2>/dev/null
_sz=$(wc -c < "$OUT_FILE" 2>/dev/null || echo 0)
echo "✔ 适配信息扫描完成！"
echo "- 输出文件: $OUT_FILE"
echo "- 文件大小: ${_sz} 字节"
