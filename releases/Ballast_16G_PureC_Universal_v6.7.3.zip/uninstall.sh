#!/system/bin/sh
pkill -f "ram_notify_daemon.sh" >/dev/null 2>&1
rm -f /data/adb/ksu/bin/ram_notify /data/adb/ksu/bin/ballast_probe /data/adb/ballast_ram_notify.pid 2>/dev/null
pkill -f "ballast_daemon" >/dev/null 2>&1
pkill -f "tombstone_daemon.sh" >/dev/null 2>&1

for f in /sys/fs/cgroup/uid_*/cgroup.freeze /sys/fs/cgroup/uid_*/pid_*/cgroup.freeze /sys/fs/cgroup/apps/uid_*/cgroup.freeze /sys/fs/cgroup/apps/uid_*/pid_*/cgroup.freeze; do
    [ -w "$f" ] && echo 0 > "$f" 2>/dev/null
done
for f in /sys/fs/cgroup/uid_*/memory.high /sys/fs/cgroup/apps/uid_*/memory.high /sys/fs/cgroup/uid_1000/pid_*/memory.high /sys/fs/cgroup/apps/uid_1000/pid_*/memory.high; do
    [ -w "$f" ] && echo max > "$f" 2>/dev/null
done

BG_DENY_PKGS=""
DISABLE_PKGS=""
RESTRICT_PKGS=""
[ -f /data/adb/ksu_mem_opt.conf ] && . /data/adb/ksu_mem_opt.conf

for pkg in $BG_DENY_PKGS com.tencent.mm com.tencent.mobileqq com.tencent.tim com.eg.android.AlipayGphone; do
    pm enable "$pkg/com.xiaomi.mipush.sdk.PushMessageHandler" >/dev/null 2>&1
    pm enable "$pkg/com.xiaomi.mipush.sdk.MessageHandleService" >/dev/null 2>&1
    pm enable "$pkg/com.heytap.msp.push.service.DataMessageCallbackService" >/dev/null 2>&1
    pm enable "$pkg/com.heytap.msp.push.service.CompatibleDataMessageCallbackService" >/dev/null 2>&1
    cmd appops set "$pkg" RUN_IN_BACKGROUND allow >/dev/null 2>&1
    cmd appops set "$pkg" RUN_ANY_IN_BACKGROUND allow >/dev/null 2>&1
    cmd appops set "$pkg" START_FOREGROUND allow >/dev/null 2>&1
    cmd appops set "$pkg" BOOT_COMPLETED default >/dev/null 2>&1
    cmd appops set "$pkg" WAKE_LOCK default >/dev/null 2>&1
    cmd appops set "$pkg" 10008 allow >/dev/null 2>&1
    am set-standby-bucket "$pkg" active >/dev/null 2>&1
done

# 恢复本版本 DISABLE_PKGS 及历史旧版曾禁用过的澎湃OS与ColorOS系统服务包
for pkg in $DISABLE_PKGS com.miui.analytics com.miui.systemAdSolution com.miui.bugreport com.miui.uireporter com.miui.misightservice com.xiaomi.security.onetrack com.bsp.catchlog com.xiaomi.ab com.xiaomi.ugd com.miui.hybrid com.mfashiongallery.emag com.miui.virtualsim com.miui.vsimcore com.xiaomi.minigame com.miui.newhome com.android.quicksearchbox com.miui.yellowpage com.miui.greenguard com.miui.thirdappassistant com.xiaomi.otrpbroker com.miui.carlink com.xiaomi.digitalkey com.xiaomi.aireco com.android.traceur com.android.bips com.android.dreams.basic com.google.android.printservice.recommendation com.google.android.gms.location.history com.coloros.assistantscreen com.oplus.pantanal.ums com.heytap.quicksearchbox com.oplus.linker com.nearme.instant.platform com.oplus.deepthinker com.oplus.metis com.oplus.dmp com.oplus.onetrace com.oplus.olc com.oplus.statistics.rom com.oplus.logtrial com.debug.loggerui com.heytap.research com.mediatek.gnssdebugreport com.mediatek.lbs.em2.ui com.oppo.ctautoregist com.heytap.htms com.oplus.gleanerservice com.opos.ads com.heytap.pictorial com.oplus.ocar com.oplus.cardigitalkey com.oppo.instant.local.service com.nearme.instant.card com.oplus.play com.oplus.postmanservice com.oplus.qualityprotect com.oplus.upgradeguide com.coloros.operationManual com.microsoft.appmanager com.microsoft.deviceintegrationservice com.microsoftsdk.crossdeviceservicebroker com.oplus.travelengine com.oplus.smartengine com.oplus.omoji com.coloros.childrenspace com.oplus.aiwriter; do
    pm enable "$pkg" >/dev/null 2>&1
done

for pkg in $RESTRICT_PKGS com.google.android.gms com.android.vending com.google.android.gsf com.xiaomi.aicr com.xiaomi.gamecenter com.xiaomi.gamecenter.sdk.service com.xiaomi.shop com.xiaomi.vipaccount com.xiaomi.market com.mobiletools.systemhelper; do
    am set-standby-bucket "$pkg" active >/dev/null 2>&1
    cmd appops set "$pkg" WAKE_LOCK default >/dev/null 2>&1
done

rm -f /data/adb/ksu_mem_opt.conf /data/adb/ksu_mem_opt.log /data/adb/ksu_mem_opt.status /data/adb/ksu_mem_opt.alg_pinned /data/adb/ksu_mem_opt.prio_fallback /data/adb/ksu_mem_opt.applied_hash /data/adb/ksu_mem_opt.v53_healed
rm -f /data/adb/ksu_tombstone.conf /data/adb/ksu_tombstone.log /data/adb/.ksu_uid_cache /data/adb/ksu/bin/compress_ram /data/adb/ksu/bin/ram_clear /data/adb/ksu/bin/ram_compact /data/adb/ksu/bin/ballast_daemon
rmdir /data/adb/.ballast_compact.lock 2>/dev/null

cmd device_config delete runtime_native usap_pool_enabled >/dev/null 2>&1
setprop persist.device_config.runtime_native.usap_pool_enabled "" 2>/dev/null
setprop persist.traced.enable "" 2>/dev/null
setprop persist.sys.misight.enable "" 2>/dev/null
[ -w /sys/fs/cgroup/memory.avail_buffers ] && echo "2500 2200 2500 1536" > /sys/fs/cgroup/memory.avail_buffers 2>/dev/null
[ -w /sys/fs/cgroup/memory.compress_ratio ] && echo "30" > /sys/fs/cgroup/memory.compress_ratio 2>/dev/null
