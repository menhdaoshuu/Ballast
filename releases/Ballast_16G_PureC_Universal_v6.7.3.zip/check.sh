#!/system/bin/sh
# 校验模块是否真正生效：读取内核实际值并与预期对比
# 用法: su -c sh /data/adb/modules/ksu_sys_mem_opt/check.sh
CONF="/data/adb/ksu_mem_opt.conf"
ENABLE_ZRAM=1
ZRAM_PERCENT=75
ZRAM_MEM_LIMIT_PERCENT=45
ENABLE_VM=1
SWAPPINESS=150
BG_DENY_PKGS=""
DISABLE_PKGS=""
RESTRICT_PKGS=""
RECLAIM_PKGS=""
[ -f "$CONF" ] && . "$CONF"

case "$ZRAM_PERCENT" in ''|*[!0-9]*) ZRAM_PERCENT=30 ;; esac
case "$ZRAM_MEM_LIMIT_PERCENT" in ''|*[!0-9]*) ZRAM_MEM_LIMIT_PERCENT=20 ;; esac
case "$SWAPPINESS" in ''|*[!0-9]*) SWAPPINESS=150 ;; esac
[ "$ZRAM_PERCENT" -lt 10 ] && ZRAM_PERCENT=10
[ "$ZRAM_PERCENT" -gt 80 ] && ZRAM_PERCENT=80

PASS=0
FAIL=0
SKIP=0

ok()   { echo "[PASS] $1"; PASS=$((PASS + 1)); }
bad()  { echo "[FAIL] $1"; FAIL=$((FAIL + 1)); }
skip() { echo "[SKIP] $1"; SKIP=$((SKIP + 1)); }

# check_eq 描述 节点 预期值
check_eq() {
    if [ ! -e "$2" ]; then skip "$1 (节点不存在)"; return; fi
    local actual
    actual=$(cat "$2" 2>/dev/null)
    if [ "$actual" = "$3" ]; then ok "$1 = $actual"; else bad "$1 实际=$actual 预期=$3"; fi
}

MEM_KB=$(awk '/MemTotal/ {print $2}' /proc/meminfo)
MODDIR=${0%/*}
if [ -x "$MODDIR/bin/ballast_daemon" ] && "$MODDIR/bin/ballast_daemon" --selftest >/dev/null 2>&1; then
    ok "Pure-C 原生引擎 (bin/ballast_daemon) 自检通过"
else
    skip "Pure-C 原生引擎未启用，使用 Shell 引擎兜底"
fi

if [ "$ENABLE_ZRAM" = "1" ]; then
    Z=/sys/block/zram0
    if [ ! -d "$Z" ]; then
        skip "zram0 不存在"
    else
        # 容量允许 1% 误差(页对齐)，使用 awk 计算 MB 避免 Android 32 位 Shell 整数溢出
        exp_mb=$(( MEM_KB * ZRAM_PERCENT / 100 / 1024 ))
        act=$(cat "$Z/disksize" 2>/dev/null)
        act_mb=$(awk -v b="${act:-0}" 'BEGIN { printf "%.0f", b/1024/1024 }')
        diff_mb=$(( act_mb > exp_mb ? act_mb - exp_mb : exp_mb - act_mb ))
        if [ "$act_mb" -gt 0 ] && [ "$diff_mb" -le $(( exp_mb / 50 + 1 )) ]; then
            ok "ZRAM 容量 ${act_mb} MB (预期 ${exp_mb} MB)"
        else
            bad "ZRAM 容量 ${act_mb} MB, 预期 ${exp_mb} MB"
        fi

        alg=$(sed -n 's/.*\[\(.*\)\].*/\1/p' "$Z/comp_algorithm" 2>/dev/null)
        if grep -qw zstd "$Z/comp_algorithm" 2>/dev/null; then
            if [ "$alg" = "zstd" ]; then ok "压缩算法 = zstd"; elif [ -f /data/adb/ksu_mem_opt.alg_pinned ]; then skip "内核固定压缩算法为 $alg (无法改为 zstd)"; else bad "压缩算法 = $alg (内核支持 zstd 但未选用; 原始: $(cat $Z/comp_algorithm))"; fi
        else
            skip "内核不支持 zstd, 当前 = $alg"
        fi

        if grep -q zram0 /proc/swaps; then
            prio=$(awk '/zram0/ {print $5}' /proc/swaps)
            if [ "$prio" = "32758" ]; then
                ok "zram0 已 swapon, 优先级 $prio"
            elif [ -f /data/adb/ksu_mem_opt.prio_fallback ]; then
                skip "zram0 已 swapon, 默认优先级 $prio (内核不支持指定 32758)"
            else
                bad "zram0 已 swapon, 优先级 $prio (预期 32758)"
            fi
        else
            bad "zram0 未出现在 /proc/swaps"
        fi

        [ -e "$Z/mem_limit" ] && skip "mem_limit 为只写节点，无法读取校验，见日志"
    fi
else
    skip "ENABLE_ZRAM=0, 跳过 ZRAM 检查"
fi

if [ "$ENABLE_VM" = "1" ]; then
    V=/proc/sys/vm
    act=$(cat $V/swappiness 2>/dev/null)
    if [ "$act" = "$SWAPPINESS" ] || [ "$act" = "100" -a "$SWAPPINESS" -gt 100 ]; then
        ok "swappiness = $act"
    else
        bad "swappiness 实际=$act 预期=$SWAPPINESS"
    fi
    check_eq "page-cluster" $V/page-cluster 0
    check_eq "vfs_cache_pressure" $V/vfs_cache_pressure 130
    check_eq "dirty_ratio" $V/dirty_ratio 15
    check_eq "dirty_background_ratio" $V/dirty_background_ratio 5
    check_eq "watermark_scale_factor" $V/watermark_scale_factor 10
    [ -e "$V/compact_unevictable_allowed" ] && check_eq "compact_unevictable_allowed" $V/compact_unevictable_allowed 0
    if [ -e /sys/kernel/mm/lru_gen/enabled ]; then
        act=$(cat /sys/kernel/mm/lru_gen/enabled)
        case "$act" in 0x0003|0x0007|0x3|0x7|3|7) ok "MGLRU enabled = $act (ARM64 通常只支持 0x0003)" ;; *) bad "MGLRU enabled = $act (预期 0x0003/0x0007)" ;; esac
    else
        skip "内核无 MGLRU"
    fi
    fz=$(cmd device_config get activity_manager_native_boot use_freezer 2>/dev/null)
    [ "$fz" = "true" ] && ok "use_freezer = true" || skip "use_freezer = ${fz:-null} (部分系统需重启或由系统接管)"
    to=$(cmd device_config get activity_manager_native_boot freeze_debounce_timeout 2>/dev/null)
    [ "$to" = "600000" ] && ok "freeze_debounce_timeout = ${to}ms (已与自研墓碑解耦)" || skip "freeze_debounce_timeout = ${to:-null} (非致命，系统接管)"
    if [ "${ENABLE_LMKD_PSI:-1}" = "1" ]; then
        psi_ms=$(getprop ro.lmk.psi_partial_stall_ms 2>/dev/null)
        [ "$psi_ms" = "150" ] && ok "ro.lmk.psi_partial_stall_ms = $psi_ms" || skip "ro.lmk.psi_partial_stall_ms = ${psi_ms:-unset}"
        comp_r=$(getprop ro.lmk.swap_compression_ratio 2>/dev/null)
        [ "$comp_r" = "2" ] && ok "ro.lmk.swap_compression_ratio = $comp_r" || skip "ro.lmk.swap_compression_ratio = ${comp_r:-unset}"
    fi
    art_bg=$(getprop pm.dexopt.bg-dexopt 2>/dev/null)
    [ "$art_bg" = "speed-profile" ] && ok "pm.dexopt.bg-dexopt = speed-profile" || skip "pm.dexopt.bg-dexopt = ${art_bg:-unset}"
    cage_cnt=0
    for _mf in /sys/fs/cgroup/uid_*/memory.high /sys/fs/cgroup/apps/uid_*/memory.high /sys/fs/cgroup/uid_1000/pid_*/memory.high /sys/fs/cgroup/apps/uid_1000/pid_*/memory.high; do
        [ -r "$_mf" ] || continue
        read -r _mv < "$_mf" 2>/dev/null
        case "$_mv" in 1073741824|268435456|201326592|167772160|134217728|100663296|67108864) cage_cnt=$((cage_cnt + 1)) ;; esac
    done
    [ "$cage_cnt" -gt 0 ] && ok "Cgroup v2 系统胖服务软笼已生效 ($cage_cnt 个节点锁定在 64/96/128/160/192/256MB/1GB)" || skip "未检测到生效的 memory.high 软笼"
    if [ -r /sys/fs/cgroup/memory.avail_buffers ]; then
        ab_val=$(awk '/^avail_buffers:/ {print $2}' /sys/fs/cgroup/memory.avail_buffers 2>/dev/null)
        [ "$ab_val" = "900" ] && ok "ColorOS memcg avail_buffers = 900/700/900/768" || skip "ColorOS memcg avail_buffers = ${ab_val:-default}"
        hmf_val=$(getprop dalvik.vm.heapmaxfree 2>/dev/null)
        [ "$hmf_val" = "8m" ] && ok "ART 紧凑堆回收 dalvik.vm.heapmaxfree = 8m" || skip "ART heapmaxfree = ${hmf_val:-default}"
    fi

else
    skip "ENABLE_VM=0, 跳过 VM 检查"
fi

if [ -r /data/system/packages.list ]; then
    ALL_PKGS_CACHE=$(awk '{print "package:"$1}' /data/system/packages.list 2>/dev/null)
else
    ALL_PKGS_CACHE="$(pm list packages -u 2>/dev/null)"
fi
if [ -r /data/system/users/0/package-restrictions.xml ] && grep -q '<pkg ' /data/system/users/0/package-restrictions.xml 2>/dev/null; then
    DISABLED_PKGS_CACHE=$( sed -n 's/.*<pkg name="\([^"]*\)".*enabled="[234]".*/package:\1/p' /data/system/users/0/package-restrictions.xml 2>/dev/null )
else
    DISABLED_PKGS_CACHE="$(pm list packages -d 2>/dev/null)"
fi
_NL="
"
pkg_installed() { case "${_NL}${ALL_PKGS_CACHE}${_NL}" in *"${_NL}package:$1${_NL}"*) return 0 ;; esac; return 1; }
pkg_disabled() { case "${_NL}${DISABLED_PKGS_CACHE}${_NL}" in *"${_NL}package:$1${_NL}"*) return 0 ;; esac; return 1; }

for pkg in $BG_DENY_PKGS; do
    if ! pkg_installed "$pkg"; then skip "$pkg 未安装"; continue; fi
    st=$(cmd appops get "$pkg" RUN_IN_BACKGROUND 2>/dev/null)
    case "$st" in *deny*) ok "$pkg 后台运行已禁止" ;; *) bad "$pkg 后台运行未禁止 ($st)" ;; esac
done

for pkg in $DISABLE_PKGS; do
    if ! pkg_installed "$pkg"; then
        skip "$pkg 未安装"
        continue
    fi
    if pkg_disabled "$pkg"; then
        ok "$pkg 已禁用"
    else
        bad "$pkg 未禁用"
    fi
done

for pkg in $RESTRICT_PKGS; do
    if ! pkg_installed "$pkg"; then skip "$pkg 未安装"; continue; fi
    bk=$(am get-standby-bucket "$pkg" 2>/dev/null)
    wl=$(cmd appops get "$pkg" WAKE_LOCK 2>/dev/null)
    case "$bk" in
        *45*|*restricted*|*RESTRICTED*) ok "$pkg 待机桶 = restricted ($bk)" ;;
        *)
            case "$wl" in
                *ignore*|*deny*) ok "$pkg 唤醒锁已限制 (待机桶由系统豁免=$bk, WAKE_LOCK=ignore)" ;;
                *) bad "$pkg 待机桶 = $bk (预期 45/restricted)" ;;
            esac
            ;;
    esac
done

for pkg in $RECLAIM_PKGS; do
    if ! pkg_installed "$pkg"; then skip "$pkg 未安装"; continue; fi
    ok "$pkg 已配置定向冷内存换入 ZRAM"
done

# v6.7.3 全机制实时生效核验
if pgrep -f "ballast_daemon daemon" >/dev/null 2>&1; then
    _bd_pid=$(pgrep -f "ballast_daemon daemon" | head -n 1)
    ok "Pure-C 守护进程运行中 (PID=${_bd_pid})"
elif pgrep -f "tombstone_daemon.sh" >/dev/null 2>&1; then
    ok "Shell 回退守护进程运行中"
else
    bad "守护进程未运行 (ballast_daemon / tombstone_daemon.sh 均未存活)"
fi

if [ -r /sys/fs/cgroup/memory.compress_ratio ]; then
    _cr_val=$(cat /sys/fs/cgroup/memory.compress_ratio 2>/dev/null)
    [ "$_cr_val" = "60" ] && ok "ColorOS memcg compress_ratio = 60" || skip "ColorOS memcg compress_ratio = ${_cr_val:-unset}"
fi
_hmin=$(getprop dalvik.vm.heapminfree 2>/dev/null)
_hutil=$(getprop dalvik.vm.heaptargetutilization 2>/dev/null)
[ "$_hmin" = "2m" ] && ok "ART heapminfree = 2m (targetutilization=${_hutil:-default})" || skip "ART heapminfree = ${_hmin:-default}"

# 欢太健康手表保活与防抖动核验 (UID memory.high 必须为 max，防止 127% CPU 抖动)
if pkg_installed "com.heytap.health"; then
    _h_uid=$(awk '$1=="com.heytap.health" {print $2; exit}' /data/system/packages.list 2>/dev/null)
    _h_mh=""
    for _hp in "/sys/fs/cgroup/apps/uid_${_h_uid}/memory.high" "/sys/fs/cgroup/uid_${_h_uid}/memory.high"; do
        [ -r "$_hp" ] && read -r _h_mh < "$_hp" 2>/dev/null && break
    done
    if [ "$_h_mh" = "max" ] || [ -z "$_h_mh" ]; then
        ok "欢太健康手表通道防护: UID memory.high=${_h_mh:-max} (无 127% CPU 抖动风险)"
    else
        bad "欢太健康 UID memory.high=${_h_mh} (预期 max，可能引发 CPU 抖动)"
    fi
fi

# 流媒体 1GB 前台软顶 / 256MB 后台软笼核验
_stm_ok=0
for _sp in com.ss.android.ugc.aweme com.ss.android.ugc.aweme.mobile com.ss.android.ugc.live com.ss.android.yumme.video com.ss.android.ugc.trill com.phoenix.read com.smile.gifmaker com.xingin.xhs tv.danmaku.bili com.tencent.qqlive com.qiyi.video com.youku.phone com.google.android.youtube com.zhiliaoapp.musically com.netflix.mediaclient; do
    _su=$(awk -v p="$_sp" '$1==p {print $2; exit}' /data/system/packages.list 2>/dev/null)
    [ -z "$_su" ] && continue
    for _scp in "/sys/fs/cgroup/apps/uid_${_su}/memory.high" "/sys/fs/cgroup/uid_${_su}/memory.high"; do
        if [ -r "$_scp" ]; then
            read -r _smv < "$_scp" 2>/dev/null
            case "$_smv" in 1073741824|268435456) _stm_ok=$((_stm_ok + 1)) ;; esac
            break
        fi
    done
done
[ "$_stm_ok" -gt 0 ] && ok "流媒体防膨胀软笼已激活 (${_stm_ok} 款已装视频 App 锁定 1GB/256MB)" || skip "当前未检测到已激活软笼的流媒体 App"

# v6.7.3: 实时可用内存与最近任务内存显示精准核验
_mem_avail_kb=$(awk '/^MemAvailable:/ {print $2; exit}' /proc/meminfo 2>/dev/null)
_mem_total_kb=$(awk '/^MemTotal:/ {print $2; exit}' /proc/meminfo 2>/dev/null)
if [ -n "$_mem_avail_kb" ] && [ -n "$_mem_total_kb" ]; then
    _avail_gb=$(awk -v a="$_mem_avail_kb" 'BEGIN{printf "%.2f", a/1048576}')
    _total_gb=$(awk -v t="$_mem_total_kb" 'BEGIN{printf "%.2f", t/1048576}')
    ok "实时可用内存: ${_avail_gb} GB 可用 | ${_total_gb} GB 总计"
fi
if command -v settings >/dev/null 2>&1; then
    _miui_v="$(getprop ro.miui.ui.version.name 2>/dev/null)$(getprop ro.mi.os.version.name 2>/dev/null)"
    _oplus_v="$(getprop ro.build.version.oplusrom 2>/dev/null)"
    if [ "$ROM_TYPE" = "HyperOS" ] || [ -n "$_miui_v" ]; then
        _mval=$(settings get system miui_recents_show_mem_info 2>/dev/null)
        if [ "$_mval" = "1" ]; then
            ok "最近任务内存显示 (HyperOS): 已开启 (miui_recents_show_mem_info=1)"
        else
            bad "最近任务内存显示 (HyperOS): 未开启 (当前=${_mval:-null})"
        fi
    elif [ "$ROM_TYPE" = "ColorOS" ] || [ -n "$_oplus_v" ]; then
        _v1=$(settings get secure allow_memory_info_display 2>/dev/null)
        _v2=$(settings get secure display_memory_information_recent_task 2>/dev/null)
        if [ "$_v1" = "1" ] && [ "$_v2" = "1" ]; then
            ok "最近任务内存显示 (ColorOS): 已开启 (allow_memory_info_display=1, display_memory_information_recent_task=1)"
        else
            bad "最近任务内存显示 (ColorOS): 未完全开启 (allow=${_v1:-null}, display=${_v2:-null})"
        fi
    fi
fi

if [ "${ENABLE_RAM_NOTIFY:-1}" = "1" ]; then
    if pgrep -f "ram_notify_daemon.sh daemon" >/dev/null 2>&1; then
        if cmd notification list 2>/dev/null | grep -q '|ballast_ram|' || su 2000 -c "cmd notification list" 2>/dev/null | grep -q '|ballast_ram|'; then
            ok "通知栏实时内存条: 运行中且通知存活 (划掉=一键压缩已就绪)"
        else
            ok "通知栏实时内存条: 守护运行中 (等待通知栏点亮/息屏中)"
        fi
    else
        bad "通知栏实时内存条: 未运行 (可执行 ram_notify on 启动)"
    fi
fi

echo "---- 结果: PASS=$PASS FAIL=$FAIL SKIP=$SKIP ----"
[ "$FAIL" -eq 0 ]
