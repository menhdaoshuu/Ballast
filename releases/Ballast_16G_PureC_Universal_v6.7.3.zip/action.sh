#!/system/bin/sh
# Ballast (压舱石 16G 双系统通用版) - 双引擎内存清理、ZRAM 回写压缩与极速墓碑
MODDIR=${0%/*}

echo "=========================================="
echo "     Ballast 16G 双引擎内存清理与压缩      "
echo "=========================================="

RAM_BEFORE=$(awk '/MemAvailable/ {print $2}' /proc/meminfo)
FREE_BEFORE=$(awk '/MemFree/ {print $2}' /proc/meminfo)
SWAP_TOTAL=$(awk '/SwapTotal/ {print $2}' /proc/meminfo)
SWAP_FREE_BEFORE=$(awk '/SwapFree/ {print $2}' /proc/meminfo)
ZRAM_USED_BEFORE=$(( (SWAP_TOTAL - SWAP_FREE_BEFORE) / 1024 ))

ACTION_MODE="$1"

if [ -z "$ACTION_MODE" ] && command -v getevent >/dev/null 2>&1; then
    echo "请选择要执行的内存操作 (3秒无操作默认全开)："
    echo "  [音量+] 引擎① 轻量缓存清理 (drop_caches + compact_memory)"
    echo "  [音量-] 引擎①+② 深度压缩与ZRAM回写 (memcg换出 + 冷页压榨)"
    ev=$(timeout 3 getevent -qlc 1 2>/dev/null | grep -E 'KEY_VOLUMEUP|KEY_VOLUMEDOWN' | head -n 1)
    case "$ev" in
        *KEY_VOLUMEUP*)
            echo "-> 已选择: [引擎① 轻量缓存清理]"
            ACTION_MODE="clear"
            ;;
        *KEY_VOLUMEDOWN*)
            echo "-> 已选择: [引擎①+② 深度压缩与ZRAM回写]"
            ACTION_MODE="compact"
            ;;
        *)
            echo "-> 默认执行: [引擎①+② 轻量清理 + 深度压缩与ZRAM回写]"
            ACTION_MODE="both"
            ;;
    esac
fi

sh "$MODDIR/ram_compact.sh" "${ACTION_MODE:-both}" 2

echo ">>> [墓碑状态核验] 确认 Tombstone 守护进程运行与原生 Freezer 解耦兜底..."
cmd device_config put activity_manager_native_boot use_freezer true >/dev/null 2>&1
cmd device_config put activity_manager_native_boot freeze_debounce_timeout 600000 >/dev/null 2>&1
cmd device_config put activity_manager_native_boot freezer_cutoff_adj 900 >/dev/null 2>&1
if ! pgrep -f "ballast_daemon|tombstone_daemon.sh" >/dev/null 2>&1; then
    if [ -x "$MODDIR/bin/ballast_daemon" ] && "$MODDIR/bin/ballast_daemon" --selftest >/dev/null 2>&1; then
        "$MODDIR/bin/ballast_daemon" daemon >/dev/null 2>&1 &
    elif [ -f "$MODDIR/tombstone_daemon.sh" ]; then
        sh "$MODDIR/tombstone_daemon.sh" >/dev/null 2>&1 &
    fi
fi
echo "  ✓ 5秒无损墓碑守护已就绪 (adj<=200前台服务豁免 + 微信后台消息秒收)"

sleep 1
RAM_AFTER=$(awk '/MemAvailable/ {print $2}' /proc/meminfo)
FREE_AFTER=$(awk '/MemFree/ {print $2}' /proc/meminfo)
SWAP_FREE_AFTER=$(awk '/SwapFree/ {print $2}' /proc/meminfo)
ZRAM_USED_AFTER=$(( (SWAP_TOTAL - SWAP_FREE_AFTER) / 1024 ))

DIFF_RAM=$(( (RAM_AFTER - RAM_BEFORE) / 1024 ))
DIFF_FREE=$(( (FREE_AFTER - FREE_BEFORE) / 1024 ))
DIFF_ZRAM=$(( ZRAM_USED_AFTER - ZRAM_USED_BEFORE ))

echo "------------------------------------------"
echo "【双引擎执行结果汇总】"
echo "- 可用内存 (MemAvailable): $((RAM_BEFORE / 1024)) MB -> $((RAM_AFTER / 1024)) MB (净增: ${DIFF_RAM} MB)"
echo "- 空闲内存 (MemFree)     : $((FREE_BEFORE / 1024)) MB -> $((FREE_AFTER / 1024)) MB (净增: ${DIFF_FREE} MB)"
echo "- ZRAM 交换区占用        : ${ZRAM_USED_BEFORE} MB -> ${ZRAM_USED_AFTER} MB (变动: ${DIFF_ZRAM} MB)"
echo "- 终端快捷命令: su -c ram_clear (轻量清理) | su -c ram_compact (深度压缩)"
echo "=========================================="
