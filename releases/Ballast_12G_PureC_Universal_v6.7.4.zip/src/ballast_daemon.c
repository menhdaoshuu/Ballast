/*
 * Ballast (压舱石) v6.7.2-12G - Event-Driven Pure C Native Engine & O(1) UID Cgroup Daemon
 * 12G Memory Lossless Keep Edition for Xiaomi HyperOS & ColorOS (Android 12 ~ 17 / GKI)
 *
 * Features:
 *   1. Zero-Fork Single-Pass /proc Scanner (getdents64 / opendir) — replaces pidof/pgrep/pkill/awk/cat
 *   2. Per-PID Cgroup v2/v1 Freezer (never locks parent uid_<uid>/cgroup.freeze)
 *   3. Double adj <= 200 Exemption (protects foreground, small-window, music, navigation, downloads)
 *   4. Lossless WeChat Compaction (reclaims cold anon pages across main & :appbrand* without freezing)
 *   5. True Kernel Aging ZRAM Writeback (idle=1800 -> writeback -> idle=all) + 10m/30m Screen-Off Cooldown
 *   6. Dual-ROM Core Process Cold-Page Reclaim (Xiaomi HyperOS + OPPO/OnePlus ColorOS)
 *
 * Build (NDK / Termux clang or gcc):
 *   clang -O3 -flto -Wall -Wextra -s src/ballast_daemon.c -o bin/ballast_daemon
 */

#define _GNU_SOURCE
#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>
#include <poll.h>
#include <sys/inotify.h>
#include <unistd.h>

#define LOG_FILE        "/data/adb/ksu_tombstone.log"
#define MEM_CONF_FILE   "/data/adb/ksu_mem_opt.conf"
#define TOMB_CONF_FILE  "/data/adb/ksu_tombstone.conf"
#define COMPACT_LOCK    "/data/adb/.ballast_compact.lock"
#define MAX_FROZEN      512
#define MAX_PKGS        128
#define PKG_NAME_LEN    96

typedef struct {
    char pkg[PKG_NAME_LEN];
    int  pid;
    int  uid;
} frozen_entry_t;

static frozen_entry_t g_frozen[MAX_FROZEN];
static int g_frozen_cnt = 0;

static int g_freeze_delay        = 12;
static int g_poll_interval       = 5;
static int g_screenoff_reclaim_cd = 600;
static int g_screenoff_wb_cd     = 1800;

static char g_bg_deny_pkgs[MAX_PKGS][PKG_NAME_LEN];
static int  g_bg_deny_cnt = 0;

static char g_user_whitelist[MAX_PKGS][PKG_NAME_LEN];
static int  g_user_whitelist_cnt = 0;

/* Dual-ROM (Xiaomi HyperOS + ColorOS) built-in whitelist */
static const char * const k_default_whitelist[] = {
    "com.android.launcher",
    "com.oplus.launcher",
    "com.miui.home",
    "com.z1812.hyperhome",
    "com.vt.launcher",
    "com.android.systemui",
    "com.android.settings",
    "miui.systemui.plugin",
    "com.coloros.smartsidebar",
    "com.fcpower",
    "io.github.hyperisland",
    "io.github.wumisc.antiburn",
    "dev.lackluster.mihelper",
    "io.github.vivibibi30.hyperpguard",
    "cc.liujiale.wxpad",
    "me.weishu.kernelsu",
    "bin.mt.plus.canary",
    "org.frknkrc44.hma_oss",
    "com.omarea.vtools",
    "xzr.konabess",
    "com.oplus.keyboard",
    "com.baidu.input_oppo",
    "com.baidu.input_mi",
    "com.iflytek.inputmethod",
    "com.iflytek.inputmethod.miui",
    "com.sohu.inputmethod.sogou.xiaomi",
    "com.miui.securityinputmethod",
    "com.android.inputmethod.latin",
    "com.google.android.inputmethod.latin",
    "com.heytap.accessory",
    "com.heytap.mydevices",
    "com.heytap.health",
    "com.mi.health",
    "com.xiaomi.xmsf",
    "com.xiaomi.xmsfkeeper",
    "com.miui.securitycenter",
    "com.miui.powerkeeper",
    "com.miui.guardprovider",
    "com.miui.securityadd",
    "com.lbe.security.miui",
    "com.xiaomi.finddevice",
    "com.miui.miwallpaper",
    "com.miui.aod",
    "com.miui.barrage",
    "com.miui.contentextension",
    "com.miui.screenshot",
    "com.miui.notification",
    "com.miui.personalassistant",
    "com.miui.voiceassist",
    "com.xiaomi.mibrain.speech",
    "com.miui.voicetrigger",
    "com.xiaomi.aiservice",
    "com.xiaomi.mi_connect_service",
    "com.milink.service",
    "com.xiaomi.mirror",
    "com.android.phone",
    "com.xiaomi.phone",
    "com.android.incallui",
    "com.android.server.telecom",
    "com.android.bluetooth",
    "com.xiaomi.bluetooth",
    "com.android.nfc",
    "com.follow.clash",
    "com.github.metacubex.clash.meta",
    NULL
};

/* Dual-ROM Core Processes for Gentle Cold Anonymous Page Reclaim */
static const char * const k_core_procs[] = {
    "system_server",
    "com.android.systemui",
    "com.android.settings",
    "com.miui.home",
    "miui.systemui.plugin",
    "com.miui.securitycenter",
    "com.miui.securitycenter.remote",
    "com.miui.powerkeeper",
    "com.xiaomi.xmsf",
    "com.xiaomi.xmsf:services",
    "com.xiaomi.finddevice",
    "com.xiaomi.aicr",
    "com.xiaomi.aicr:cognitionService",
    "com.miui.miwallpaper",
    "com.xiaomi.phone",
    "com.android.launcher",
    "com.oplus.launcher",
    "com.oplus.athena",
    "com.oplus.subsys",
    "com.android.phone",
    "com.oplus.obrain",
    "com.oplus.persist.multimedia",
    "com.oplus.midas",
    "zygote",
    "zygote_secondary",
    "zygote64",
    NULL
};

/* Low-level file I/O helpers (Zero Fork) */
static ssize_t read_file_fast(const char *path, char *buf, size_t max_len) {
    int fd = open(path, O_RDONLY | O_CLOEXEC);
    if (fd < 0) return -1;
    ssize_t n = read(fd, buf, max_len - 1);
    close(fd);
    if (n < 0) return -1;
    buf[n] = '\0';
    return n;
}

static int write_file_fast(const char *path, const char *val) {
    int fd = open(path, O_WRONLY | O_CLOEXEC);
    if (fd < 0) return -1;
    size_t len = strlen(val);
    ssize_t n = write(fd, val, len);
    close(fd);
    return (n == (ssize_t)len) ? 0 : -1;
}

static void log_msg(const char *fmt, ...) {
    struct stat st;
    int flags = O_WRONLY | O_CREAT | O_APPEND | O_CLOEXEC;
    if (stat(LOG_FILE, &st) == 0 && st.st_size > 204800) {
        flags = O_WRONLY | O_CREAT | O_TRUNC | O_CLOEXEC;
    }
    int fd = open(LOG_FILE, flags, 0644);
    if (fd < 0) return;

    time_t now = time(NULL);
    struct tm tm_now;
    localtime_r(&now, &tm_now);
    char line[512];
    int off = snprintf(line, sizeof(line), "[%02d-%02d %02d:%02d:%02d] ",
                       tm_now.tm_mon + 1, tm_now.tm_mday,
                       tm_now.tm_hour, tm_now.tm_min, tm_now.tm_sec);
    if (off > 0 && (size_t)off < sizeof(line) - 2) {
        va_list ap;
        va_start(ap, fmt);
        int n = vsnprintf(line + off, sizeof(line) - (size_t)off - 2, fmt, ap);
        va_end(ap);
        if (n > 0) off += n;
        if ((size_t)off >= sizeof(line) - 2) off = (int)sizeof(line) - 2;
        line[off++] = '\n';
        line[off] = '\0';
        ssize_t w = write(fd, line, (size_t)off);
        (void)w;
    }
    close(fd);
}

/* Monotonic uptime in seconds (Zero Fork) */
static int64_t read_uptime_sec(void) {
    struct timespec ts;
    if (clock_gettime(CLOCK_BOOTTIME, &ts) == 0) {
        return (int64_t)ts.tv_sec;
    }
    char buf[64];
    if (read_file_fast("/proc/uptime", buf, sizeof(buf)) > 0) {
        return (int64_t)strtoll(buf, NULL, 10);
    }
    return (int64_t)time(NULL);
}

/* Multi-node backlight check (Zero Fork) */
static bool is_screen_on_fast(void) {
    char buf[32];
    int found = 0;
    DIR *d = opendir("/sys/class/backlight");
    if (d) {
        struct dirent *de;
        while ((de = readdir(d)) != NULL) {
            if (de->d_name[0] == '.') continue;
            char path[320];
            snprintf(path, sizeof(path), "/sys/class/backlight/%.255s/brightness", de->d_name);
            if (read_file_fast(path, buf, sizeof(buf)) > 0) {
                found = 1;
                if (atoi(buf) > 0) {
                    closedir(d);
                    return true;
                }
            }
        }
        closedir(d);
    }
    if (read_file_fast("/sys/class/leds/lcd-backlight/brightness", buf, sizeof(buf)) > 0) {
        found = 1;
        if (atoi(buf) > 0) return true;
    }
    return found ? false : true;
}

static bool read_proc_adj(int pid, int *out_adj) {
    char path[64], buf[32];
    snprintf(path, sizeof(path), "/proc/%d/oom_score_adj", pid);
    if (read_file_fast(path, buf, sizeof(buf)) <= 0) return false;
    char *endp = NULL;
    long val = strtol(buf, &endp, 10);
    if (endp == buf) return false;
    *out_adj = (int)val;
    return true;
}

static bool read_proc_uid(int pid, int *out_uid) {
    char path[64], buf[1024];
    snprintf(path, sizeof(path), "/proc/%d/status", pid);
    if (read_file_fast(path, buf, sizeof(buf)) <= 0) return false;
    const char *p = strstr(buf, "\nUid:");
    if (!p) return false;
    p += 5;
    while (*p == ' ' || *p == '\t') p++;
    *out_uid = atoi(p);
    return true;
}

static bool read_proc_name(int pid, char *out_name, size_t max_len) {
    char path[64];
    snprintf(path, sizeof(path), "/proc/%d/cmdline", pid);
    ssize_t n = read_file_fast(path, out_name, max_len);
    if (n <= 0 || out_name[0] == '\0') return false;
    for (ssize_t i = 0; i < n; i++) {
        if (out_name[i] == '\0' || isspace((unsigned char)out_name[i])) {
            out_name[i] = '\0';
            break;
        }
    }
    return out_name[0] != '\0';
}

static bool is_bg_push_proc(const char *proc_name) {
    const char *colon = strchr(proc_name, ':');
    if (!colon) return false;
    return (strstr(colon, ":MSF") != NULL ||
            strstr(colon, ":push") != NULL ||
            strstr(colon, ":channel") != NULL ||
            strstr(colon, ":ipc") != NULL ||
            strstr(colon, ":daemon") != NULL ||
            strstr(colon, ":support") != NULL ||
            strstr(colon, ":account") != NULL);
}

static bool is_transient_overlay(const char *pkg) {
    if (!pkg || !pkg[0]) return false;
    static const char * const exact[] = {
        "com.android.systemui",
    "com.android.settings",
        "miui.systemui.plugin",
        "com.coloros.smartsidebar",
        "com.fcpower",
        "io.github.hyperisland",
        "io.github.wumisc.antiburn",
        "com.miui.screenshot",
        "com.oplus.screenshot",
        "com.miui.contentextension",
        "com.miui.securityadd",
        "com.miui.barrage",
        "com.miui.notification",
        "com.miui.voiceassist",
        "com.heytap.speechassist",
        "com.xiaomi.aiasst.vision",
        "com.android.intentresolver",
        "com.android.permissioncontroller",
        "com.lbe.security.miui",
        "com.miui.packageinstaller",
        "com.oplus.keyboard",
        "com.android.inputmethod.latin",
        "com.google.android.inputmethod.latin",
        "com.tencent.wetype",
        "com.miui.securityinputmethod",
        NULL
    };
    for (int i = 0; exact[i]; i++) {
        if (strcmp(pkg, exact[i]) == 0) return true;
    }
    if (strncmp(pkg, "com.baidu.input", 15) == 0 ||
        strncmp(pkg, "com.sohu.inputmethod", 20) == 0 ||
        strncmp(pkg, "com.iflytek.inputmethod", 23) == 0) {
        return true;
    }
    return false;
}


/* v6.7.2-12G Feature 1: In-Memory mtime-cached package UID table from /data/system/packages.list (Zero repeated fopen) */
#define MAX_UID_CACHE 1024
typedef struct {
    char pkg[PKG_NAME_LEN];
    int  uid;
} pkg_uid_entry_t;

static pkg_uid_entry_t g_uid_cache[MAX_UID_CACHE];
static int    g_uid_cache_cnt = 0;
static time_t g_uid_cache_mtime = 0;

static int lookup_pkg_uid_fast(const char *pkg) {
    if (!pkg || !pkg[0]) return -1;
    struct stat st;
    if (stat("/data/system/packages.list", &st) == 0) {
        if (g_uid_cache_cnt == 0 || st.st_mtime != g_uid_cache_mtime) {
            FILE *fp = fopen("/data/system/packages.list", "re");
            if (fp) {
                g_uid_cache_cnt = 0;
                char line[512];
                while (g_uid_cache_cnt < MAX_UID_CACHE && fgets(line, sizeof(line), fp)) {
                    char *sp = strpbrk(line, " \t");
                    if (!sp) continue;
                    size_t plen = (size_t)(sp - line);
                    if (plen == 0 || plen >= PKG_NAME_LEN) continue;
                    int u = atoi(sp + 1);
                    if (u <= 0) continue;
                    memcpy(g_uid_cache[g_uid_cache_cnt].pkg, line, plen);
                    g_uid_cache[g_uid_cache_cnt].pkg[plen] = '\0';
                    g_uid_cache[g_uid_cache_cnt].uid = u;
                    g_uid_cache_cnt++;
                }
                fclose(fp);
                g_uid_cache_mtime = st.st_mtime;
            }
        }
    }
    for (int i = 0; i < g_uid_cache_cnt; i++) {
        if (strcmp(g_uid_cache[i].pkg, pkg) == 0) {
            return g_uid_cache[i].uid;
        }
    }
    return -1;
}

/* v6.7.2-12G Feature 2: /proc/<pid>/wchan check to avoid freezing mid-filesystem-write/lock */
static void wait_if_in_critical_io(int pid) {
    char path[64], wbuf[128];
    snprintf(path, sizeof(path), "/proc/%d/wchan", pid);
    if (read_file_fast(path, wbuf, sizeof(wbuf)) > 0) {
        if (strstr(wbuf, "flock") || strstr(wbuf, "f2fs_file_write") ||
            strstr(wbuf, "ext4_file_write") || strstr(wbuf, "jbd2_") ||
            strstr(wbuf, "vfs_fsync")) {
            struct timespec req = { 0, 150000000L }; /* 150ms grace */
            nanosleep(&req, NULL);
        }
    }
}

/* v6.7.2-12G Feature 3: Proportional 90% Cgroup v2 memory.reclaim (retains 20% hot UI/code pages), strict 'anon'-only fallback */
static bool reclaim_pid_smart(int pid, int uid) {
    if (uid >= 0) {
        static const char * const prefixes[] = { "/sys/fs/cgroup/apps/uid_", "/sys/fs/cgroup/uid_", NULL };
        for (int i = 0; prefixes[i]; i++) {
            char cur_path[160], rec_path[160], cbuf[64];
            snprintf(cur_path, sizeof(cur_path), "%s%d/pid_%d/memory.current", prefixes[i], uid, pid);
            snprintf(rec_path, sizeof(rec_path), "%s%d/pid_%d/memory.reclaim", prefixes[i], uid, pid);
            if (read_file_fast(cur_path, cbuf, sizeof(cbuf)) > 0) {
                long long cur_bytes = atoll(cbuf);
                if (cur_bytes > (4LL * 1024 * 1024)) {
                    long long target_reclaim = (cur_bytes * 9) / 10;
                    char wbuf[64];
                    snprintf(wbuf, sizeof(wbuf), "%lld", target_reclaim);
                    if (write_file_fast(rec_path, wbuf) == 0) {
                        return true;
                    }
                }
            }
        }
    }
    char rpath[64];
    snprintf(rpath, sizeof(rpath), "/proc/%d/reclaim", pid);
    return (write_file_fast(rpath, "anon") == 0);
}

/* v6.7.2-12G Feature 4: inotify + poll event-driven wait on top-app/cgroup.procs (0ms wake on app switch) */
static int g_inotify_fd = -1;
static void init_top_app_inotify(void) {
    if (g_inotify_fd >= 0) return;
    g_inotify_fd = inotify_init1(IN_NONBLOCK | IN_CLOEXEC);
    if (g_inotify_fd >= 0) {
        inotify_add_watch(g_inotify_fd, "/dev/cpuset/top-app/cgroup.procs", IN_MODIFY | IN_CLOSE_WRITE);
        inotify_add_watch(g_inotify_fd, "/sys/fs/cgroup/cpuset/top-app/cgroup.procs", IN_MODIFY | IN_CLOSE_WRITE);
    }
}

static void wait_top_app_or_timeout(int timeout_sec) {
    if (timeout_sec <= 0) timeout_sec = 1;
    init_top_app_inotify();
    if (g_inotify_fd < 0) {
        sleep((unsigned int)timeout_sec);
        return;
    }
    struct pollfd pfd;
    pfd.fd = g_inotify_fd;
    pfd.events = POLLIN;
    pfd.revents = 0;
    int r = poll(&pfd, 1, timeout_sec * 1000);
    if (r > 0 && (pfd.revents & POLLIN)) {
        char drain[512];
        while (read(g_inotify_fd, drain, sizeof(drain)) > 0) {}
    }
}

/* Per-PID Cgroup v2/v1 Freeze (NEVER locks whole-UID /sys/fs/cgroup/uid_<uid>/cgroup.freeze) */
static bool set_freeze_pid(int pid, int state) {
    if (state == 1) wait_if_in_critical_io(pid);
    char path[128], cg_buf[512];
    snprintf(path, sizeof(path), "/proc/%d/cgroup", pid);
    if (read_file_fast(path, cg_buf, sizeof(cg_buf)) <= 0) return false;

    int uid = -1;
    read_proc_uid(pid, &uid);

    /* When thawing (state == 0), also unlock parent uid_<uid>/cgroup.freeze if it was ever locked */
    if (state == 0 && uid >= 0) {
        char uid_cg[128];
        snprintf(uid_cg, sizeof(uid_cg), "/sys/fs/cgroup/uid_%d/cgroup.freeze", uid);
        write_file_fast(uid_cg, "0");
    }

    const char *val_str = state ? "1" : "0";
    char *saveptr = NULL;
    for (char *line = strtok_r(cg_buf, "\n", &saveptr); line; line = strtok_r(NULL, "\n", &saveptr)) {
        char *c1 = strchr(line, ':');
        if (!c1) continue;
        char *c2 = strchr(c1 + 1, ':');
        if (!c2) continue;
        const char *sub = c1 + 1;
        const char *cg_path = c2 + 1;
        if (strncmp(line, "0:", 2) == 0 && strstr(cg_path, "/pid_") != NULL) {
            char fpath[256];
            snprintf(fpath, sizeof(fpath), "/sys/fs/cgroup%s/cgroup.freeze", cg_path);
            if (write_file_fast(fpath, val_str) == 0) return true;
        } else if (strstr(sub, "freezer") != NULL) {
            const char *v1_str = state ? "FROZEN" : "THAWED";
            char fpath[256];
            snprintf(fpath, sizeof(fpath), "/dev/freezer%s/freezer.state", cg_path);
            if (write_file_fast(fpath, v1_str) == 0) return true;
            snprintf(fpath, sizeof(fpath), "/sys/fs/cgroup/freezer%s/freezer.state", cg_path);
            if (write_file_fast(fpath, v1_str) == 0) return true;
        }
    }

    if (uid >= 0) {
        char pid_cg[160];
        snprintf(pid_cg, sizeof(pid_cg), "/sys/fs/cgroup/uid_%d/pid_%d/cgroup.freeze", uid, pid);
        if (write_file_fast(pid_cg, val_str) == 0) return true;
    }
    return false;
}

static bool proc_belongs_to_pkg(const char *proc_name, const char *pkg) {
    size_t len = strlen(pkg);
    if (strncmp(proc_name, pkg, len) != 0) return false;
    return (proc_name[len] == '\0' || proc_name[len] == ':');
}

/* Check if app is visible or running an active foreground service (adj <= 200) */
static bool is_app_active_or_visible(const char *pkg, const char *current_top) {
    if (!pkg || !pkg[0]) return false;
    if (current_top && strcmp(pkg, current_top) == 0) return true;

    /* v5.1: Fast O(1) UID Cgroup scan before fallback to /proc */
    int fast_uid = lookup_pkg_uid_fast(pkg);
    if (fast_uid >= 10000) {
        char cg_dir[128];
        snprintf(cg_dir, sizeof(cg_dir), "/sys/fs/cgroup/uid_%d", fast_uid);
        DIR *cd = opendir(cg_dir);
        if (cd) {
            struct dirent *cde;
            bool active = false;
            while ((cde = readdir(cd)) != NULL) {
                if (strncmp(cde->d_name, "pid_", 4) != 0) continue;
                int pid = atoi(cde->d_name + 4);
                if (pid <= 0) continue;
                char pname[128];
                if (!read_proc_name(pid, pname, sizeof(pname))) continue;
                if (!proc_belongs_to_pkg(pname, pkg)) continue;
                if (is_bg_push_proc(pname)) continue;
                int adj = 1000;
                if (read_proc_adj(pid, &adj) && adj <= 200) {
                    active = true;
                    break;
                }
            }
            closedir(cd);
            return active;
        }
    }

    DIR *d = opendir("/proc");
    if (!d) return false;
    struct dirent *de;
    bool active = false;
    while ((de = readdir(d)) != NULL) {
        if (!isdigit((unsigned char)de->d_name[0])) continue;
        int pid = atoi(de->d_name);
        if (pid <= 0) continue;
        char pname[128];
        if (!read_proc_name(pid, pname, sizeof(pname))) continue;
        if (!proc_belongs_to_pkg(pname, pkg)) continue;
        if (is_bg_push_proc(pname)) continue;
        int adj = 1000;
        if (read_proc_adj(pid, &adj) && adj <= 200) {
            active = true;
            break;
        }
    }
    closedir(d);
    return active;
}

/* Reclaim cold anonymous pages for a specific package (e.g. WeChat lossless compaction) */
static int reclaim_pkg_anon(const char *pkg, bool check_visible, const char *current_top) {
    if (check_visible && is_app_active_or_visible(pkg, current_top)) {
        return 0;
    }
    int fast_uid = lookup_pkg_uid_fast(pkg);
    if (fast_uid >= 10000) {
        char cg_dir[128];
        snprintf(cg_dir, sizeof(cg_dir), "/sys/fs/cgroup/uid_%d", fast_uid);
        DIR *cd = opendir(cg_dir);
        if (cd) {
            struct dirent *cde;
            int cnt = 0;
            while ((cde = readdir(cd)) != NULL) {
                if (strncmp(cde->d_name, "pid_", 4) != 0) continue;
                int pid = atoi(cde->d_name + 4);
                if (pid > 0 && reclaim_pid_smart(pid, fast_uid)) cnt++;
            }
            closedir(cd);
            if (cnt > 0) return cnt;
        }
    }
    DIR *d = opendir("/proc");
    if (!d) return 0;
    struct dirent *de;
    int cnt = 0;
    while ((de = readdir(d)) != NULL) {
        if (!isdigit((unsigned char)de->d_name[0])) continue;
        int pid = atoi(de->d_name);
        if (pid <= 0) continue;
        char pname[128];
        if (!read_proc_name(pid, pname, sizeof(pname))) continue;
        if (!proc_belongs_to_pkg(pname, pkg)) continue;
        char rpath[64];
        snprintf(rpath, sizeof(rpath), "/proc/%d/reclaim", pid);
        if (write_file_fast(rpath, "anon") == 0) {
            cnt++;
        }
    }
    closedir(d);
    return cnt;
}

static void remove_frozen_pkg(const char *pkg) {
    int w = 0;
    for (int i = 0; i < g_frozen_cnt; i++) {
        if (strcmp(g_frozen[i].pkg, pkg) != 0) {
            if (w != i) g_frozen[w] = g_frozen[i];
            w++;
        }
    }
    g_frozen_cnt = w;
}


static void set_pkg_mem_high(const char *pkg, const char *lim) {
    int u = lookup_pkg_uid_fast(pkg);
    if (u < 10000) return;
    char p[160];
    snprintf(p, sizeof(p), "/sys/fs/cgroup/uid_%d/memory.high", u);
    if (write_file_fast(p, lim) != 0) {
        snprintf(p, sizeof(p), "/sys/fs/cgroup/apps/uid_%d/memory.high", u);
        write_file_fast(p, lim);
    }
}

static int trim_wechat_idle_subprocs(void) {
    DIR *d = opendir("/proc");
    if (!d) return 0;
    struct dirent *de;
    int trimmed = 0;
    while ((de = readdir(d)) != NULL) {
        if (!isdigit((unsigned char)de->d_name[0])) continue;
        int pid = atoi(de->d_name);
        if (pid <= 0) continue;
        char pname[128];
        if (!read_proc_name(pid, pname, sizeof(pname))) continue;
        bool is_wc = (strncmp(pname, "com.tencent.mm:appbrand", 23) == 0 ||
                      strncmp(pname, "com.tencent.mm:tools", 20) == 0);
        bool is_ho = (strcmp(pname, "com.heytap.health:once") == 0);
        bool is_hm = (strcmp(pname, "com.heytap.health") == 0 || strstr(pname, ":sandboxed_process") != NULL);
        if (!is_wc && !is_ho && !is_hm) continue;
        int adj = 1000;
        if (!read_proc_adj(pid, &adj) || adj <= 200) continue;
        if (is_wc) {
            if (kill(pid, SIGKILL) == 0) trimmed++;
        } else if (is_ho || is_hm) {
            if (kill(pid, SIGTERM) == 0) trimmed++;
        }
    }
    closedir(d);
    return trimmed;
}

static int freeze_pkg_procs(const char *pkg, const char *current_top, bool emit_stdout) {
    if (strcmp(pkg, "com.tencent.mm") == 0) {
        trim_wechat_idle_subprocs();
        set_pkg_mem_high("com.tencent.mm", "167772160");
        int r = reclaim_pkg_anon("com.tencent.mm", true, current_top);
        if (r > 0 && !emit_stdout) {
            log_msg("【微信无损瘦身】已将微信主进程及小程序/WebView共 %d 个进程的冷匿名页压入 ZRAM (不杀页面)", r);
        }
        return 0;
    }
    if (is_app_active_or_visible(pkg, current_top)) {
        return 0;
    }

    int pids[128];
    int pid_cnt = 0;
    int fast_uid = lookup_pkg_uid_fast(pkg);
    if (fast_uid >= 0 && fast_uid < 10000) return 0;

    bool scanned_cg = false;
    if (fast_uid >= 10000) {
        char cg_dir[128];
        snprintf(cg_dir, sizeof(cg_dir), "/sys/fs/cgroup/uid_%d", fast_uid);
        DIR *cd = opendir(cg_dir);
        if (cd) {
            scanned_cg = true;
            struct dirent *cde;
            while ((cde = readdir(cd)) != NULL) {
                if (strncmp(cde->d_name, "pid_", 4) != 0) continue;
                int pid = atoi(cde->d_name + 4);
                if (pid <= 0) continue;
                char pname[128];
                if (!read_proc_name(pid, pname, sizeof(pname))) continue;
                if (!proc_belongs_to_pkg(pname, pkg)) continue;
                if (!is_bg_push_proc(pname)) {
                    int adj = 1000;
                    if (read_proc_adj(pid, &adj) && adj <= 200) {
                        closedir(cd);
                        if (!emit_stdout) {
                            log_msg("【前台服务保护】检测到 %s 存在活跃服务进程 (PID:%d adj=%d <= 200)，豁免冻结", pkg, pid, adj);
                        }
                        return 0;
                    }
                }
                if (pid_cnt < 128) pids[pid_cnt++] = pid;
            }
            closedir(cd);
        }
    }

    if (!scanned_cg) {
        DIR *d = opendir("/proc");
        if (!d) return 0;
        struct dirent *de;
        while ((de = readdir(d)) != NULL) {
            if (!isdigit((unsigned char)de->d_name[0])) continue;
            int pid = atoi(de->d_name);
            if (pid <= 0) continue;
            char pname[128];
            if (!read_proc_name(pid, pname, sizeof(pname))) continue;
            if (!proc_belongs_to_pkg(pname, pkg)) continue;

            /* System UID (< 10000) protection: never freeze system apps/services */
            int uid = 10000;
            if (read_proc_uid(pid, &uid) && uid < 10000) {
                closedir(d);
                return 0;
            }

            /* Double check adj <= 200 on non-push processes */
            if (!is_bg_push_proc(pname)) {
                int adj = 1000;
                if (read_proc_adj(pid, &adj) && adj <= 200) {
                    closedir(d);
                    if (!emit_stdout) {
                        log_msg("【前台服务保护】检测到 %s 存在活跃服务进程 (PID:%d adj=%d <= 200)，豁免冻结", pkg, pid, adj);
                    }
                    return 0;
                }
            }
            if (pid_cnt < 128) pids[pid_cnt++] = pid;
        }
        closedir(d);
    }

    if (pid_cnt == 0) return 0;
    remove_frozen_pkg(pkg);

    int frozen_cnt = 0;
    for (int i = 0; i < pid_cnt; i++) {
        int pid = pids[i];
        char rpath[64];
        snprintf(rpath, sizeof(rpath), "/proc/%d/reclaim", pid);
        write_file_fast(rpath, "anon");
        if (set_freeze_pid(pid, 1)) {
            frozen_cnt++;
            if (g_frozen_cnt < MAX_FROZEN) {
                snprintf(g_frozen[g_frozen_cnt].pkg, PKG_NAME_LEN, "%s", pkg);
                g_frozen[g_frozen_cnt].pid = pid;
                g_frozen[g_frozen_cnt].uid = -1;
                g_frozen_cnt++;
            }
            if (emit_stdout) {
                printf("%s:%d\n", pkg, pid);
            }
        }
    }
    if (frozen_cnt > 0 && !emit_stdout) {
        log_msg("【无损墓碑】已无损冻结并换出冷页至 ZRAM (保留Activity状态): %s (%d 进程)", pkg, frozen_cnt);
    }
    return frozen_cnt;
}

static int unfreeze_pkg_procs(const char *pkg, bool use_frozen_table) {
    int thawed_cnt = 0;
    if (use_frozen_table) {
        bool has_record = false;
        for (int i = 0; i < g_frozen_cnt; i++) {
            if (strcmp(g_frozen[i].pkg, pkg) == 0) {
                has_record = true;
                if (set_freeze_pid(g_frozen[i].pid, 0)) thawed_cnt++;
            }
        }
        if (!has_record) return 0;
        remove_frozen_pkg(pkg);
    }

    bool scanned_cg = false;
    int fast_uid = lookup_pkg_uid_fast(pkg);
    if (fast_uid >= 10000) {
        char cg_dir[128];
        snprintf(cg_dir, sizeof(cg_dir), "/sys/fs/cgroup/uid_%d", fast_uid);
        DIR *cd = opendir(cg_dir);
        if (cd) {
            scanned_cg = true;
            struct dirent *cde;
            while ((cde = readdir(cd)) != NULL) {
                if (strncmp(cde->d_name, "pid_", 4) != 0) continue;
                int pid = atoi(cde->d_name + 4);
                if (pid <= 0) continue;
                if (set_freeze_pid(pid, 0) && !use_frozen_table) thawed_cnt++;
            }
            closedir(cd);
        }
    }

    if (!scanned_cg) {
        DIR *d = opendir("/proc");
        if (d) {
            struct dirent *de;
            while ((de = readdir(d)) != NULL) {
                if (!isdigit((unsigned char)de->d_name[0])) continue;
                int pid = atoi(de->d_name);
                if (pid <= 0) continue;
                char pname[128];
                if (!read_proc_name(pid, pname, sizeof(pname))) continue;
                if (!proc_belongs_to_pkg(pname, pkg)) continue;
                if (set_freeze_pid(pid, 0) && !use_frozen_table) thawed_cnt++;
            }
            closedir(d);
        }
    }
    if (thawed_cnt > 0 && use_frozen_table) {
        log_msg("【唤醒解冻】已恢复运行: %s (%d 进程)", pkg, thawed_cnt);
    }
    return thawed_cnt;
}

static int kill_bg_pkg_procs(const char *pkg, const char *current_top) {
    if (is_app_active_or_visible(pkg, current_top)) return 0;
    int fast_uid = lookup_pkg_uid_fast(pkg);
    if (fast_uid >= 0 && fast_uid < 10000) return 0;
    if (fast_uid >= 10000) {
        char cg_dir[128];
        snprintf(cg_dir, sizeof(cg_dir), "/sys/fs/cgroup/uid_%d", fast_uid);
        DIR *cd = opendir(cg_dir);
        if (cd) {
            struct dirent *cde;
            int killed = 0;
            while ((cde = readdir(cd)) != NULL) {
                if (strncmp(cde->d_name, "pid_", 4) != 0) continue;
                int pid = atoi(cde->d_name + 4);
                if (pid > 0 && kill(pid, SIGKILL) == 0) killed++;
            }
            closedir(cd);
            return killed;
        }
    }
    DIR *d = opendir("/proc");
    if (!d) return 0;
    struct dirent *de;
    int killed = 0;
    while ((de = readdir(d)) != NULL) {
        if (!isdigit((unsigned char)de->d_name[0])) continue;
        int pid = atoi(de->d_name);
        if (pid <= 0) continue;
        char pname[128];
        if (!read_proc_name(pid, pname, sizeof(pname))) continue;
        if (!proc_belongs_to_pkg(pname, pkg)) continue;
        int uid = 10000;
        if (read_proc_uid(pid, &uid) && uid < 10000) continue;
        if (kill(pid, SIGKILL) == 0) killed++;
    }
    closedir(d);
    return killed;
}

/* Engine 1: Lightweight Cache Drop & Memory Compaction */
static void ram_broom_clear(void) {
    printf(">>> [引擎① 轻量清理 (Pure C)] 正在同步脏页、释放内核可回收缓存并规整内存碎片...\n");
    sync();
    if (write_file_fast("/proc/sys/vm/drop_caches", "3\n") == 0) {
        printf("  ✓ 已释放干净 PageCache / dentry / inode 缓存 (drop_caches=3)\n");
    }
    if (write_file_fast("/proc/sys/vm/compact_memory", "1\n") == 0) {
        printf("  ✓ 已触发物理内存碎片规整 (compact_memory=1)\n");
    }
}

/* Engine 2.1: ZRAM Writeback (True Kernel Aging: idle=1800 -> writeback -> idle=all) & memcg Swapout */
static int ram_zram_writeback(bool screenoff_only) {
    char swaps[2048];
    if (read_file_fast("/proc/swaps", swaps, sizeof(swaps)) <= 0 || strstr(swaps, "zram0") == NULL) {
        return 0;
    }

    int wb_done = 0;
    char blk[128] = {0};
    if (read_file_fast("/sys/block/zram0/hybridswap_loop_device", blk, sizeof(blk)) <= 0) {
        read_file_fast("/sys/block/zram0/backing_dev", blk, sizeof(blk));
    }
    for (int i = 0; blk[i]; i++) {
        if (isspace((unsigned char)blk[i])) { blk[i] = '\0'; break; }
    }

    if (blk[0] && strcmp(blk, "none") != 0 && strcmp(blk, "chp") != 0 &&
        access("/sys/block/zram0/writeback", F_OK) == 0) {
        chmod("/sys/block/zram0/idle", 0664);
        chmod("/sys/block/zram0/writeback", 0664);
        if (access("/sys/block/zram0/writeback_limit_enable", F_OK) == 0) {
            write_file_fast("/sys/block/zram0/writeback_limit_enable", "1\n");
            write_file_fast("/sys/block/zram0/writeback_limit", "131072\n");
        }
        /* Mark pages idle >= 1800s first, flush genuinely cold & incompressible pages, then mark all for next 30m cycle */
        write_file_fast("/sys/block/zram0/idle", "1800\n");
        if (write_file_fast("/sys/block/zram0/writeback", "incompressible\n") == 0) wb_done = 1;
        if (write_file_fast("/sys/block/zram0/writeback", "huge_idle\n") == 0) wb_done = 1;
        if (write_file_fast("/sys/block/zram0/writeback", "idle\n") == 0) wb_done = 1;
        write_file_fast("/sys/block/zram0/idle", "all\n");
        if (wb_done && !screenoff_only) {
            printf("  ✓ 已触发 zram0 块设备真实冷页回写 (上限 512MB)\n");
        }
    }

    if (screenoff_only) return wb_done;

    const char *memcg_roots[] = { "/sys/fs/cgroup", "/dev/memcg", "/sys/fs/cgroup/memory", NULL };
    const char *memcg_root = NULL;
    for (int i = 0; memcg_roots[i]; i++) {
        struct stat st;
        if (stat(memcg_roots[i], &st) == 0 && S_ISDIR(st.st_mode)) {
            memcg_root = memcg_roots[i];
            break;
        }
    }

    if (memcg_root) {
        char p1[256], p2[256], p3[256];
        snprintf(p1, sizeof(p1), "%s/memory.force_swapout_percent", memcg_root);
        snprintf(p2, sizeof(p2), "%s/memory.force_swapout", memcg_root);
        snprintf(p3, sizeof(p3), "%s/memory.force_reclaim_zram", memcg_root);

        const char *acts[2] = { NULL, NULL };
        const char *val = "1\n";
        if (access(p1, F_OK) == 0) {
            acts[0] = "force_swapout_percent";
            acts[1] = "force_shrink_anon_percent";
            val = "60\n";
        } else if (access(p2, F_OK) == 0) {
            acts[0] = "force_swapout";
            acts[1] = "force_shrink_anon";
        } else if (access(p3, F_OK) == 0) {
            acts[0] = "force_reclaim_zram";
            acts[1] = "force_reclaim_anon";
        }

        if (acts[0]) {
            for (int i = 0; i < 2 && acts[i]; i++) {
                char node[256];
                snprintf(node, sizeof(node), "%s/memory.%s", memcg_root, acts[i]);
                write_file_fast(node, val);
                snprintf(node, sizeof(node), "%s/apps/memory.%s", memcg_root, acts[i]);
                write_file_fast(node, val);
                snprintf(node, sizeof(node), "%s/bg/memory.%s", memcg_root, acts[i]);
                write_file_fast(node, val);
            }
            wb_done = 1;
            printf("  ✓ 已触发 memcg 后台冷匿名页温和换入 ZRAM (%s)\n", memcg_root);
        }
    }
    return wb_done;
}

static bool is_core_proc_name(const char *pname) {
    for (int i = 0; k_core_procs[i]; i++) {
        if (strcmp(pname, k_core_procs[i]) == 0) return true;
    }
    return false;
}

/* Engine 2.2: Single-Pass GKI & Dual-ROM Core Cold Anonymous Page Reclaim (adj > 200) */
static int ram_force_reclaim(const char *skip_top_pkg, bool quiet) {
    DIR *d = opendir("/proc");
    if (!d) return 0;
    struct dirent *de;
    int reclaimed_cnt = 0;

    while ((de = readdir(d)) != NULL) {
        if (!isdigit((unsigned char)de->d_name[0])) continue;
        int pid = atoi(de->d_name);
        if (pid <= 0) continue;

        char pname[128] = {0};
        read_proc_name(pid, pname, sizeof(pname));

        int uid = 0;
        if (!read_proc_uid(pid, &uid)) continue;
        int adj = 1000;
        read_proc_adj(pid, &adj);

        /* v6.7.2-12G GoldenBalance: Reclaim dual-ROM core processes and background apps (adj > 200), protecting active foreground/perceptible services (adj <= 200) */
        bool is_core = (pname[0] != '\0' && is_core_proc_name(pname));
        if (!is_core && (uid < 10000 || adj <= 200)) continue;
        if (skip_top_pkg && skip_top_pkg[0] && pname[0] && proc_belongs_to_pkg(pname, skip_top_pkg)) {
            continue;
        }

        if (reclaim_pid_smart(pid, uid)) {
            reclaimed_cnt++;
        }
    }
    closedir(d);

    if (!quiet) {
        printf("  ✓ 已无损将 %d 个后台与双系统核心进程的冷匿名页压入 ZRAM (后台页面完整保留)\n", reclaimed_cnt);
    }
    return reclaimed_cnt;
}

static int ram_compact_run(bool screenoff_only) {
    if (mkdir(COMPACT_LOCK, 0755) != 0) {
        if (!screenoff_only) {
            printf("  ! 已有内存压缩任务正在执行，跳过重复调用\n");
        }
        return 0;
    }
    if (!screenoff_only) {
        printf(">>> [引擎② 无损压缩/回写 (Pure C)] 正在执行 ZRAM 闲置回写与冷匿名页换出...\n");
    }
    ram_zram_writeback(screenoff_only);
    if (!screenoff_only) {
        ram_force_reclaim(NULL, false);
    }
    write_file_fast("/sys/block/zram0/compact", "1\n");
    write_file_fast("/proc/sys/vm/compact_memory", "1\n");
    rmdir(COMPACT_LOCK);
    return 0;
}

/* Parse space-separated package list from ksu_mem_opt.conf */
static void parse_pkg_list(const char *val, char out_list[MAX_PKGS][PKG_NAME_LEN], int *out_cnt) {
    *out_cnt = 0;
    const char *p = val;
    while (*p) {
        while (*p && (isspace((unsigned char)*p) || *p == '"' || *p == '\'')) p++;
        if (!*p) break;
        char token[PKG_NAME_LEN];
        size_t i = 0;
        while (*p && !isspace((unsigned char)*p) && *p != '"' && *p != '\'') {
            if (i < PKG_NAME_LEN - 1) token[i++] = *p;
            p++;
        }
        token[i] = '\0';
        if (i > 0 && *out_cnt < MAX_PKGS) {
            snprintf(out_list[*out_cnt], PKG_NAME_LEN, "%s", token);
            (*out_cnt)++;
        }
    }
}

static void load_configs(void) {
    g_freeze_delay = 10;
    g_poll_interval = 5;
    g_screenoff_reclaim_cd = 600;
    g_screenoff_wb_cd = 1800;
    parse_pkg_list("com.tencent.mobileqq com.tencent.tim com.eg.android.AlipayGphone", g_bg_deny_pkgs, &g_bg_deny_cnt);
    g_user_whitelist_cnt = 0;

    const char *files[] = { MEM_CONF_FILE, TOMB_CONF_FILE, NULL };
    for (int f = 0; files[f]; f++) {
        char buf[8192];
        if (read_file_fast(files[f], buf, sizeof(buf)) <= 0) continue;
        char *saveptr = NULL;
        for (char *line = strtok_r(buf, "\n", &saveptr); line; line = strtok_r(NULL, "\n", &saveptr)) {
            while (*line == ' ' || *line == '\t') line++;
            if (*line == '#' || *line == '\0') continue;
            if (strncmp(line, "FREEZE_DELAY=", 13) == 0) {
                int v = atoi(line + 13);
                if (v > 0) g_freeze_delay = v;
            } else if (strncmp(line, "POLL_INTERVAL=", 14) == 0) {
                int v = atoi(line + 14);
                if (v > 0) g_poll_interval = v;
            } else if (strncmp(line, "SCREENOFF_RECLAIM_CD=", 21) == 0) {
                int v = atoi(line + 21);
                if (v >= 60) g_screenoff_reclaim_cd = v;
            } else if (strncmp(line, "SCREENOFF_WB_CD=", 16) == 0) {
                int v = atoi(line + 16);
                if (v >= 60) g_screenoff_wb_cd = v;
            } else if (strncmp(line, "BG_DENY_PKGS=", 13) == 0) {
                parse_pkg_list(line + 13, g_bg_deny_pkgs, &g_bg_deny_cnt);
            } else if (strncmp(line, "USER_WHITELIST=", 15) == 0) {
                parse_pkg_list(line + 15, g_user_whitelist, &g_user_whitelist_cnt);
            }
        }
    }
}

static bool is_whitelisted_pkg(const char *pkg) {
    if (!pkg || !pkg[0]) return true;
    if (is_transient_overlay(pkg) || is_core_proc_name(pkg)) return true;
    for (int i = 0; k_default_whitelist[i]; i++) {
        if (strcmp(pkg, k_default_whitelist[i]) == 0) return true;
    }
    for (int i = 0; i < g_user_whitelist_cnt; i++) {
        if (strcmp(pkg, g_user_whitelist[i]) == 0) return true;
    }
    /* Exempt any system package whose UID < 10000 via O(1) lookup first */
    int fast_uid = lookup_pkg_uid_fast(pkg);
    if (fast_uid >= 0) {
        return (fast_uid < 10000);
    }
    DIR *d = opendir("/proc");
    if (d) {
        struct dirent *de;
        while ((de = readdir(d)) != NULL) {
            if (!isdigit((unsigned char)de->d_name[0])) continue;
            int pid = atoi(de->d_name);
            if (pid <= 0) continue;
            char pname[128];
            if (!read_proc_name(pid, pname, sizeof(pname))) continue;
            if (!proc_belongs_to_pkg(pname, pkg)) continue;
            int uid = 10000;
            if (read_proc_uid(pid, &uid) && uid < 10000) {
                closedir(d);
                return true;
            }
        }
        closedir(d);
    }
    return false;
}

static bool is_bg_deny_pkg(const char *pkg) {
    if (!pkg || !pkg[0] || strcmp(pkg, "com.tencent.mm") == 0) return false;
    if (is_whitelisted_pkg(pkg)) return false;
    for (int i = 0; i < g_bg_deny_cnt; i++) {
        if (strcmp(pkg, g_bg_deny_pkgs[i]) == 0) return true;
    }
    return false;
}

/* Fast Top-App Resolution via /dev/cpuset/top-app/cgroup.procs (Zero dumpsys overhead) */
static uint64_t g_last_top_sig = 0;
static char     g_last_top_pkg[PKG_NAME_LEN] = {0};

static const char *get_top_app_fast(void) {
    char buf[1024];
    ssize_t n = read_file_fast("/dev/cpuset/top-app/cgroup.procs", buf, sizeof(buf));
    if (n <= 0) {
        n = read_file_fast("/sys/fs/cgroup/cpuset/top-app/cgroup.procs", buf, sizeof(buf));
    }
    if (n <= 0) return g_last_top_pkg;

    /* Compute 64-bit FNV-1a signature of top-app PIDs */
    uint64_t sig = 14695981039346656037ULL;
    for (ssize_t i = 0; i < n; i++) {
        sig ^= (uint8_t)buf[i];
        sig *= 1099511628211ULL;
    }
    if (sig == g_last_top_sig && g_last_top_pkg[0] != '\0') {
        return g_last_top_pkg;
    }

    char best_pkg[PKG_NAME_LEN] = {0};
    int best_score = 1000;
    char *saveptr = NULL;
    for (char *line = strtok_r(buf, "\n", &saveptr); line; line = strtok_r(NULL, "\n", &saveptr)) {
        int pid = atoi(line);
        if (pid <= 0) continue;
        int uid = 0;
        if (!read_proc_uid(pid, &uid)) continue;
        int adj = 1000;
        if (!read_proc_adj(pid, &adj)) continue;
        /* Ignore persistent negative-adj system daemons; allow uid>=10000 (0<=adj<=100) or foreground uid==1000 (adj==0) */
        if (adj < 0 || adj > 100) continue;
        if (uid < 10000 && !(uid == 1000 && adj == 0)) continue;

        char pname[128];
        if (!read_proc_name(pid, pname, sizeof(pname))) continue;
        char *colon = strchr(pname, ':');
        if (colon) *colon = '\0';
        if (pname[0] == '\0' || strchr(pname, '.') == NULL) continue;
        if (is_transient_overlay(pname)) continue;

        /* Prioritize user apps (uid >= 10000, score 0..100) over uid == 1000 system UI (score 101) */
        int eff_score = (uid >= 10000) ? adj : (adj + 101);
        if (eff_score <= best_score) {
            best_score = eff_score;
            snprintf(best_pkg, sizeof(best_pkg), "%.*s", (int)(sizeof(best_pkg) - 1), pname);
        }
    }

    if (best_pkg[0] != '\0') {
        g_last_top_sig = sig;
        snprintf(g_last_top_pkg, sizeof(g_last_top_pkg), "%s", best_pkg);
    }
    return g_last_top_pkg;
}

static void thaw_visible_windows_fast(void) {
    if (g_frozen_cnt == 0) return;

    char thaw_pkgs[MAX_FROZEN][PKG_NAME_LEN];
    int thaw_cnt = 0;

    int w = 0;
    for (int i = 0; i < g_frozen_cnt; i++) {
        int adj = 1000;
        if (!read_proc_adj(g_frozen[i].pid, &adj)) {
            /* Process exited, drop from table */
            continue;
        }
        /* Keep alive entry in g_frozen so unfreeze_pkg_procs finds has_record=true and thaws it! */
        if (w != i) g_frozen[w] = g_frozen[i];
        w++;

        if (adj <= 200) {
            bool exists = false;
            for (int k = 0; k < thaw_cnt; k++) {
                if (strcmp(thaw_pkgs[k], g_frozen[w - 1].pkg) == 0) {
                    exists = true;
                    break;
                }
            }
            if (!exists && thaw_cnt < MAX_FROZEN) {
                snprintf(thaw_pkgs[thaw_cnt++], PKG_NAME_LEN, "%s", g_frozen[w - 1].pkg);
            }
        }
    }
    g_frozen_cnt = w;

    for (int k = 0; k < thaw_cnt; k++) {
        set_pkg_mem_high(thaw_pkgs[k], "max");
        unfreeze_pkg_procs(thaw_pkgs[k], true);
    }
}


static void apply_system_mem_cages(const char *cur_app) {
    static const char * const c128[] = {
        "com.google.android.gms", "com.android.vending",
        "com.miui.securitycenter", "com.xiaomi.aicr", "com.miui.personalassistant", "com.xiaomi.aiservice",
        "com.oplus.athena", "com.oplus.obrain", "com.oplus.aiunit", "com.oplus.appplatform", "com.tencent.mobileqq", "com.tencent.tim", "com.eg.android.AlipayGphone", "com.oplus.safecenter", "com.heytap.mydevices", NULL
    };
    static const char * const c96[] = {
        "com.google.android.gsf",
        "com.miui.powerkeeper", "com.miui.cloudservice", "com.xiaomi.market", "com.xiaomi.joyose", "com.xiaomi.mi_connect_service",
        "com.oplus.exsystemservice", "com.heytap.mcs", "com.coloros.ocs.opencapabilityservice", "com.oplus.atlas", "com.oplus.subsys", "com.miui.gallery", "com.xiaomi.aiasst.service", "com.xiaomi.aiasst.vision", "com.milink.service", "com.xiaomi.mirror", "com.xiaomi.gamecenter", "com.miui.weather2", "com.xiaomi.account", "com.miui.mishare.connectivity", "com.coloros.gallery3d", "com.finshell.wallet", "com.heytap.market", "com.heytap.cloud", "com.oplus.battery", "com.oplus.framework.network.drs", "com.mobiletools.systemhelper", "com.heytap.openid", "com.android.providers.media.module", "com.android.mms", "com.heytap.speechassist", "com.oplus.location", "android.ext.services", "com.android.providers.contacts", "com.oplus.ovoicemanager", "com.android.externalstorage", "com.oplus.melody", "com.coloros.smartsidebar", "com.oplus.games", NULL
    };
    for (int i = 0; c128[i]; i++) {
        int u = lookup_pkg_uid_fast(c128[i]);
        if (u >= 10000) {
            char p[160];
            bool fg = (cur_app && strcmp(c128[i], cur_app) == 0);
            const char *lim = fg ? "max" : "100663296";
            snprintf(p, sizeof(p), "/sys/fs/cgroup/uid_%d/memory.high", u);
            if (write_file_fast(p, lim) != 0) {
                snprintf(p, sizeof(p), "/sys/fs/cgroup/apps/uid_%d/memory.high", u);
                write_file_fast(p, lim);
            }
        }
    }
    static const char * const c256[] = { "com.heytap.health", "com.mi.health", NULL };
    static const char * const c160[] = { "com.oplus.camera", "com.android.camera", "com.oplus.keyboard", NULL };
    for (int i = 0; c256[i]; i++) {
        bool fg = (cur_app && strcmp(c256[i], cur_app) == 0);
        set_pkg_mem_high(c256[i], "max"); (void)fg;
    }
    for (int i = 0; c160[i]; i++) {
        bool fg = (cur_app && strcmp(c160[i], cur_app) == 0);
        set_pkg_mem_high(c160[i], fg ? "max" : "134217728");
    }
    for (int i = 0; c96[i]; i++) {
        int u = lookup_pkg_uid_fast(c96[i]);
        if (u >= 10000) {
            char p[160];
            bool fg = (cur_app && strcmp(c96[i], cur_app) == 0);
            const char *lim = fg ? "max" : "67108864";
            snprintf(p, sizeof(p), "/sys/fs/cgroup/uid_%d/memory.high", u);
            if (write_file_fast(p, lim) != 0) {
                snprintf(p, sizeof(p), "/sys/fs/cgroup/apps/uid_%d/memory.high", u);
                write_file_fast(p, lim);
            }
        }
    }
    static const char * const c64[] = {
        "com.heytap.openid", "com.mobiletools.systemhelper",
        "com.oplus.framework.network.drs", "com.android.mms", "com.oplus.cosa", "com.coloros.ocs.opencapabilityservice", "com.oplus.melody", NULL
    };
    for (int i = 0; c64[i]; i++) {
        bool fg = (cur_app && strcmp(c64[i], cur_app) == 0);
        set_pkg_mem_high(c64[i], fg ? "max" : "67108864");
    }
    static const char * const c_stream[] = { "com.ss.android.ugc.aweme", "com.ss.android.ugc.aweme.lite", "com.ss.android.ugc.aweme.mobile", "com.ss.android.ugc.live", "com.ss.android.yumme.video", "com.ss.android.ugc.trill", "com.phoenix.read", "com.smile.gifmaker", "com.kuaishou.nebula", "com.xingin.xhs", "com.ss.android.article.video", "tv.danmaku.bili", "com.bilibili.app.in", "com.tencent.qqlive", "com.qiyi.video", "com.iqiyi.i18n", "com.youku.phone", "com.hunantv.imgo.activity", "air.tv.douyu.android", "com.duowan.kiwi", "com.google.android.youtube", "com.zhiliaoapp.musically", "com.netflix.mediaclient", NULL };
    for (int i = 0; c_stream[i]; i++) {
        bool fg = (cur_app && strcmp(c_stream[i], cur_app) == 0);
        set_pkg_mem_high(c_stream[i], fg ? "805306368" : "201326592");
    }
}

static int run_daemon_loop(void) {
    load_configs();
    apply_system_mem_cages(NULL);
    struct stat st_mem, st_tomb;
    time_t last_mem_mtime  = (stat(MEM_CONF_FILE, &st_mem) == 0) ? st_mem.st_mtime : 0;
    time_t last_tomb_mtime = (stat(TOMB_CONF_FILE, &st_tomb) == 0) ? st_tomb.st_mtime : 0;

    log_msg("Tombstone v6.7.2-12G Pure-C Universal 12G 守护进程已启动 (零Fork原生C引擎 + uid<10000系统保护 + 双配置热重载 + 熄屏双级冷却CD)...");

    char last_app[PKG_NAME_LEN] = {0};
    char pending_app[PKG_NAME_LEN] = {0};
    int64_t pending_time = 0;
    int64_t last_screenoff_reclaim_ts = 0;
    int64_t last_screenoff_wb_ts = 0;
    bool screen_off_reclaimed = false;
    int loop_cnt = 0;

    while (1) {
        if (!is_screen_on_fast()) {
            if (pending_app[0] != '\0') {
                if (is_bg_deny_pkg(pending_app)) {
                    kill_bg_pkg_procs(pending_app, NULL);
                } else {
                    freeze_pkg_procs(pending_app, NULL, false);
                }
                pending_app[0] = '\0';
            }
            if (!screen_off_reclaimed) {
                int64_t now_off = read_uptime_sec();
                if (last_screenoff_reclaim_ts == 0 || (now_off - last_screenoff_reclaim_ts) >= g_screenoff_reclaim_cd) {
                    reclaim_pkg_anon("com.tencent.mm", true, NULL);
                    int rcnt = ram_force_reclaim(NULL, true);
                    if (rcnt > 0) {
                        log_msg("【熄屏冷页回收 (Pure C)】已将 %d 个后台与核心进程冷页压入 ZRAM", rcnt);
                    }
                    last_screenoff_reclaim_ts = now_off;
                }
                if (last_screenoff_wb_ts == 0 || (now_off - last_screenoff_wb_ts) >= g_screenoff_wb_cd) {
                    ram_compact_run(true);
                    log_msg("【熄屏整合 (Pure C)】已执行无损 ZRAM 闲置回写与内存碎片规整 (冷却CD: %ds)", g_screenoff_wb_cd);
                    last_screenoff_wb_ts = now_off;
                }
                screen_off_reclaimed = true;
            }
            /* v5.1: Block on inotify (30s timeout) instead of blind sleep(30) so screen-on + app switch wakes in <1ms */
            wait_top_app_or_timeout(30);
            continue;
        }
        screen_off_reclaimed = false;

        int dyn_timeout = 60;
        if (pending_app[0] != '\0') {
            int64_t rem = g_freeze_delay - (read_uptime_sec() - pending_time);
            dyn_timeout = (rem > 0 && rem <= g_freeze_delay) ? (int)rem : 1;
        } else if (g_frozen_cnt > 0) {
            dyn_timeout = 15;
        }
        wait_top_app_or_timeout(dyn_timeout);
        thaw_visible_windows_fast();

        const char *cur_app = get_top_app_fast();
        if (!cur_app || !cur_app[0]) continue;

        if (strcmp(cur_app, last_app) != 0) {
            set_pkg_mem_high(cur_app, "max");
            unfreeze_pkg_procs(cur_app, true);
            if (pending_app[0] != '\0' && strcmp(pending_app, cur_app) != 0 && strcmp(pending_app, last_app) != 0) {
                if (!is_app_active_or_visible(pending_app, cur_app)) {
                    if (is_bg_deny_pkg(pending_app)) {
                        kill_bg_pkg_procs(pending_app, cur_app);
                    } else {
                        freeze_pkg_procs(pending_app, cur_app, false);
                    }
                }
                pending_app[0] = '\0';
            }
            if (last_app[0] != '\0' && !is_whitelisted_pkg(last_app)) {
                snprintf(pending_app, sizeof(pending_app), "%s", last_app);
                pending_time = read_uptime_sec();
            }
            snprintf(last_app, sizeof(last_app), "%s", cur_app);
        }

        if (pending_app[0] != '\0') {
            int64_t now = read_uptime_sec();
            if ((now - pending_time) >= g_freeze_delay) {
                if (!is_app_active_or_visible(pending_app, cur_app)) {
                    if (is_bg_deny_pkg(pending_app)) {
                        if (kill_bg_pkg_procs(pending_app, cur_app) > 0) {
                            log_msg("【后台强力压制 (Pure C)】离开前台 -> 彻底清理 %s 全部后台进程", pending_app);
                        }
                    } else {
                        freeze_pkg_procs(pending_app, cur_app, false);
                    }
                }
                pending_app[0] = '\0';
            }
        }

        loop_cnt++;
        if (loop_cnt % 12 == 0) {
            time_t cur_mem_mtime  = (stat(MEM_CONF_FILE, &st_mem) == 0) ? st_mem.st_mtime : 0;
            time_t cur_tomb_mtime = (stat(TOMB_CONF_FILE, &st_tomb) == 0) ? st_tomb.st_mtime : 0;
            if (cur_mem_mtime != last_mem_mtime || cur_tomb_mtime != last_tomb_mtime) {
                load_configs();
    apply_system_mem_cages(NULL);
                last_mem_mtime  = cur_mem_mtime;
                last_tomb_mtime = cur_tomb_mtime;
            }
            for (int i = 0; i < g_bg_deny_cnt; i++) {
                const char *dpkg = g_bg_deny_pkgs[i];
                if (strcmp(cur_app, dpkg) != 0 && strcmp(pending_app, dpkg) != 0 && !is_whitelisted_pkg(dpkg)) {
                    kill_bg_pkg_procs(dpkg, cur_app);
                }
            }
        }
    }
    return 0;
}

int main(int argc, char **argv) {
    const char *cmd = (argc > 1) ? argv[1] : "both";

    if (strcmp(cmd, "--selftest") == 0) {
        return (read_uptime_sec() > 0) ? 0 : 1;
    } else if (strcmp(cmd, "daemon") == 0) {
        return run_daemon_loop();
    } else if (strcmp(cmd, "clear") == 0 || strcmp(cmd, "broom") == 0 || strcmp(cmd, "1") == 0) {
        ram_broom_clear();
        return 0;
    } else if (strcmp(cmd, "screenoff") == 0) {
        return ram_compact_run(true);
    } else if (strcmp(cmd, "compact") == 0 || strcmp(cmd, "reclaim") == 0 || strcmp(cmd, "2") == 0) {
        return ram_compact_run(false);
    } else if (strcmp(cmd, "reclaim_pkg") == 0 && argc > 2) {
        return reclaim_pkg_anon(argv[2], true, (argc > 3) ? argv[3] : NULL);
    } else if (strcmp(cmd, "freeze_pkg") == 0 && argc > 2) {
        freeze_pkg_procs(argv[2], (argc > 3) ? argv[3] : NULL, true);
        return 0;
    } else if (strcmp(cmd, "unfreeze_pkg") == 0 && argc > 2) {
        unfreeze_pkg_procs(argv[2], false);
        return 0;
    } else if (strcmp(cmd, "kill_bg_pkg") == 0 && argc > 2) {
        kill_bg_pkg_procs(argv[2], (argc > 3) ? argv[3] : NULL);
        return 0;
    } else {
        ram_broom_clear();
        return ram_compact_run(false);
    }
}
