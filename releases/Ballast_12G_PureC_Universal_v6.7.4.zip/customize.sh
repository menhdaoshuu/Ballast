#!/system/bin/sh
SKIPUNZIP=0
CONF="/data/adb/ksu_mem_opt.conf"
FINAL_MODDIR="/data/adb/modules/ksu_sys_mem_opt"

ui_print "- Ballast (压舱石) 12G v6.7.4"

API_LEVEL=$(getprop ro.build.version.sdk)
DEVICE_MODEL=$(getprop ro.product.model)
DEVICE_NAME=$(getprop ro.product.device)
MEM_TOTAL_KB=$(awk '/MemTotal/ {print $2}' /proc/meminfo)
MEM_TOTAL_GB=$(( (MEM_TOTAL_KB + 1048576 / 2) / 1048576 ))

# 自动探测当前系统类型 (HyperOS/MIUI vs ColorOS/RealmeUI/OxygenOS)
detect_rom_type() {
    if [ -n "$(getprop ro.mi.os.version.name)" ] || [ -n "$(getprop ro.miui.ui.version.name)" ] || [ -d /system_ext/app/miuisystem ] || grep -q "^com.miui.home " /data/system/packages.list 2>/dev/null; then
        echo "hyperos"
    elif [ -n "$(getprop ro.build.version.oplusrom)" ] || [ -n "$(getprop ro.oplus.version.base)" ] || grep -qE "^(com.oplus.launcher|com.coloros.smartsidebar) " /data/system/packages.list 2>/dev/null; then
        echo "coloros"
    else
        echo "generic"
    fi
}

ROM_TYPE=$(detect_rom_type)

ui_print "- 设备: ${DEVICE_MODEL:-Unknown} | ${ROM_TYPE} (API ${API_LEVEL}) | 约 ${MEM_TOTAL_GB} GB"

if [ "$API_LEVEL" -lt 31 ]; then
    abort "! 本模块仅支持 Android 12 (API 31) 及以上设备！"
fi

if [ -d /sys/block/zram0 ]; then
    :
else
    :
fi

# ─────────────────────────────────────────────────────────────
# 1) 小米澎湃OS (HyperOS / MIUI) 专属策略包名集
# ─────────────────────────────────────────────────────────────
HYPEROS_BG_DENY="com.tencent.mobileqq com.tencent.tim com.eg.android.AlipayGphone com.ss.android.ugc.aweme"
HYPEROS_DISABLE="com.miui.analytics com.miui.systemAdSolution com.miui.bugreport com.miui.uireporter com.miui.misightservice com.xiaomi.security.onetrack com.bsp.catchlog com.xiaomi.ab com.xiaomi.ugd com.miui.hybrid com.mfashiongallery.emag com.miui.virtualsim com.miui.vsimcore com.xiaomi.minigame com.miui.newhome com.android.quicksearchbox com.miui.yellowpage com.miui.greenguard com.miui.thirdappassistant com.xiaomi.otrpbroker com.miui.carlink com.xiaomi.digitalkey com.xiaomi.aireco com.android.traceur com.android.bips com.android.dreams.basic com.google.android.printservice.recommendation com.google.android.gms.location.history"
HYPEROS_RESTRICT="com.google.android.gms com.android.vending com.google.android.gsf com.xiaomi.aicr com.xiaomi.gamecenter com.xiaomi.gamecenter.sdk.service com.xiaomi.shop com.xiaomi.vipaccount com.xiaomi.market"
HYPEROS_RECLAIM="com.tencent.mm com.google.android.gms com.android.vending com.xiaomi.aicr com.xiaomi.xmsf com.xiaomi.finddevice com.miui.securitycenter com.miui.mishare.connectivity com.miui.weather2 com.miui.passwords com.miui.personalassistant com.xiaomi.simactivate.service com.xiaomi.account com.miui.cloudservice com.miui.packageinstaller com.android.mms com.android.settings com.android.intentresolver com.miui.gallery com.miui.screenshot com.mi.health com.xiaomi.aiasst.service com.xiaomi.aiasst.vision com.xiaomi.aiservice com.miui.voiceassist com.xiaomi.mi_connect_service com.milink.service com.xiaomi.mirror com.xiaomi.joyose"
HYPEROS_PROTECTED="com.miui.home com.z1812.hyperhome miui.systemui.plugin com.android.systemui com.miui.securitycenter com.miui.powerkeeper com.lbe.security.miui com.xiaomi.finddevice com.xiaomi.xmsf com.xiaomi.xmsfkeeper com.miui.personalassistant com.miui.notification com.mi.health com.miui.voiceassist com.xiaomi.mibrain.speech com.miui.voicetrigger com.xiaomi.aiservice com.tencent.mm me.weishu.kernelsu bin.mt.plus.canary org.frknkrc44.hma_oss dev.lackluster.mihelper io.github.hyperisland io.github.vivibibi30.hyperpguard io.github.wumisc.antiburn"

# ─────────────────────────────────────────────────────────────
# 2) ColorOS / 一加 / RealmeUI 专属策略包名集
# ─────────────────────────────────────────────────────────────
COLOROS_BG_DENY="com.tencent.mobileqq com.tencent.tim com.eg.android.AlipayGphone com.ss.android.ugc.aweme"
COLOROS_DISABLE="com.coloros.assistantscreen com.oplus.pantanal.ums com.heytap.quicksearchbox com.oplus.linker com.nearme.instant.platform com.oplus.deepthinker com.oplus.metis com.oplus.dmp com.oplus.onetrace com.oplus.olc com.oplus.statistics.rom com.oplus.logtrial com.debug.loggerui com.heytap.research com.mediatek.gnssdebugreport com.mediatek.lbs.em2.ui com.oppo.ctautoregist com.heytap.htms com.oplus.gleanerservice com.opos.ads com.heytap.pictorial com.oplus.ocar com.oplus.cardigitalkey com.oppo.instant.local.service com.nearme.instant.card com.oplus.play com.oplus.postmanservice com.oplus.qualityprotect com.oplus.upgradeguide com.coloros.operationManual com.android.traceur com.android.bips com.android.dreams.basic com.microsoft.appmanager com.microsoft.deviceintegrationservice com.microsoftsdk.crossdeviceservicebroker com.oplus.travelengine com.oplus.smartengine com.oplus.omoji com.coloros.childrenspace com.oplus.aiwriter com.heytap.openid com.oplus.midas com.oplus.sau com.coloros.securityguard com.oplus.framework.network.drs"
COLOROS_RESTRICT="com.google.android.gms com.android.vending com.google.android.gsf com.mobiletools.systemhelper"
COLOROS_RECLAIM="com.tencent.mm com.google.android.gms com.android.vending com.oplus.aiunit com.coloros.gallery3d com.oplus.screenshot com.android.mms com.oplus.exsystemservice com.heytap.mcs com.coloros.alarmclock com.finshell.wallet com.heytap.speechassist com.oplus.ovoicemanager com.oplus.appplatform com.oplus.obrain com.mobiletools.systemhelper com.oplus.atlas com.coloros.ocs.opencapabilityservice"
COLOROS_PROTECTED="com.oplus.launcher com.android.launcher com.android.systemui com.coloros.smartsidebar com.heytap.accessory com.heytap.mydevices com.heytap.health com.heytap.speechassist com.oplus.ovoicemanager com.coloros.sceneservice com.coloros.karaoke com.finshell.wallet com.tencent.mm com.fcpower me.weishu.kernelsu bin.mt.plus.canary org.frknkrc44.hma_oss"

# 根据当前检测到的 ROM 类型绑定目标预设与异构系统剔除列表
if [ "$ROM_TYPE" = "hyperos" ]; then
    TARGET_BG_DENY="$HYPEROS_BG_DENY"
    TARGET_DISABLE="$HYPEROS_DISABLE"
    TARGET_RESTRICT="$HYPEROS_RESTRICT"
    TARGET_RECLAIM="$HYPEROS_RECLAIM"
    TARGET_PROTECTED="$HYPEROS_PROTECTED"
    FOREIGN_PKGS="$COLOROS_DISABLE $COLOROS_RESTRICT $COLOROS_RECLAIM"
    :
elif [ "$ROM_TYPE" = "coloros" ]; then
    TARGET_BG_DENY="$COLOROS_BG_DENY"
    TARGET_DISABLE="$COLOROS_DISABLE"
    TARGET_RESTRICT="$COLOROS_RESTRICT"
    TARGET_RECLAIM="$COLOROS_RECLAIM"
    TARGET_PROTECTED="$COLOROS_PROTECTED"
    FOREIGN_PKGS="$HYPEROS_DISABLE $HYPEROS_RESTRICT $HYPEROS_RECLAIM"
    :
else
    TARGET_BG_DENY="com.tencent.mobileqq com.tencent.tim com.eg.android.AlipayGphone com.ss.android.ugc.aweme"
    TARGET_DISABLE="com.android.traceur com.android.bips com.android.dreams.basic"
    TARGET_RESTRICT="com.google.android.gms com.android.vending com.google.android.gsf"
    TARGET_RECLAIM="com.tencent.mm com.google.android.gms com.android.vending com.android.mms com.android.settings"
    TARGET_PROTECTED="com.android.systemui com.tencent.mm me.weishu.kernelsu bin.mt.plus.canary"
    FOREIGN_PKGS=""
    :
fi

if [ ! -f "$CONF" ]; then
    cat > "$CONF" <<EOF
# ZRAM / VM 调优配置 (Ballast 12G 双系统自适应通用版 - 当前系统: $ROM_TYPE)，修改后重启生效
ROM_TYPE="$ROM_TYPE"
ENABLE_ZRAM=1
# ZRAM 容量占物理内存百分比 (75% 黄金大容量压缩池，承载全量后台冷匿名页)
ZRAM_PERCENT=75
# 压缩数据占用物理内存上限百分比 (45% 保证安全无死锁)
ZRAM_MEM_LIMIT_PERCENT=45
ENABLE_VM=1
ENABLE_LMKD_PSI=1
ENABLE_ART_OPT=1
ENABLE_SYS_CAGE=1
# 标准内核上限 100
SWAPPINESS=150
# 温和无损墓碑延迟秒数 (离开前台12秒后再冻结，防跳转/支付假死)
FREEZE_DELAY=10
# 彻底禁止后台运行的应用包名(压制 QQ / TIM / 支付宝，保留微信正常收消息)
BG_DENY_PKGS="$TARGET_BG_DENY"
# 禁用的系统应用包名(自动匹配当前系统毒瘤/广告/遥测组件，已排除核心桌面/小部件/手表健康/语音助手)
DISABLE_PKGS="$TARGET_DISABLE"
# 轻度限制应用包名(待机受限桶+禁止持锁+降CPU优先级，不阻断前台)
RESTRICT_PKGS="$TARGET_RESTRICT"
# 开机稳态后主动把冷匿名页压入 ZRAM 的应用包名(适合微信/GMS/系统后台内存大户)
RECLAIM_PKGS="$TARGET_RECLAIM"
EOF
    :
else
    :
    sed -i 's|^ZRAM_PERCENT=.*|ZRAM_PERCENT=75|' "$CONF"
    sed -i 's|^ZRAM_MEM_LIMIT_PERCENT=.*|ZRAM_MEM_LIMIT_PERCENT=45|' "$CONF"
    sed -i 's|^SWAPPINESS=100$|SWAPPINESS=150|; s|^SWAPPINESS=130$|SWAPPINESS=150|' "$CONF"
    grep -q '^FREEZE_DELAY=' "$CONF" 2>/dev/null && sed -i 's|^FREEZE_DELAY=5$|FREEZE_DELAY=10|' "$CONF" || printf '\nFREEZE_DELAY=10\n' >> "$CONF"
    for _ek in ENABLE_LMKD_PSI ENABLE_ART_OPT ENABLE_SYS_CAGE; do grep -q "^${_ek}=" "$CONF" 2>/dev/null || printf '%s=1\n' "$_ek" >> "$CONF"; done
    if grep -q "^ROM_TYPE=" "$CONF" 2>/dev/null; then
        sed -i "s|^ROM_TYPE=.*|ROM_TYPE=\"${ROM_TYPE}\"|" "$CONF"
    else
        printf '\nROM_TYPE="%s"\n' "$ROM_TYPE" >> "$CONF"
    fi
    :

    # 增量合并函数：保留用户手动添加的本机包名，剔除另一套系统的异构包名与受保护核心包名，并补齐当前系统默认包
    merge_pkg_key() {
        local _k="$1" _defaults="$2" _exclude="$3" _cur _item _merged=""
        _cur=$(sed -n "s/^${_k}=\"\(.*\)\"/\1/p" "$CONF" 2>/dev/null)
        for _item in $_cur $_defaults; do
            [ -n "$_item" ] || continue
            case " $_defaults " in
                *" $_item "*) ;;
                *)
                    case " $_exclude " in *" $_item "*) continue ;; esac
                    ;;
            esac
            case " $_merged " in *" $_item "*) ;; *) _merged="${_merged:+$_merged }$_item" ;; esac
        done
        if grep -q "^${_k}=" "$CONF" 2>/dev/null; then
            sed -i "s|^${_k}=.*|${_k}=\"${_merged}\"|" "$CONF"
        else
            printf '\n%s="%s"\n' "$_k" "$_merged" >> "$CONF"
        fi
    }

    merge_pkg_key "BG_DENY_PKGS" "$TARGET_BG_DENY" "com.tencent.mm com.fcpower $TARGET_PROTECTED"
    merge_pkg_key "DISABLE_PKGS" "$TARGET_DISABLE" "$FOREIGN_PKGS $TARGET_PROTECTED"
    merge_pkg_key "RESTRICT_PKGS" "$TARGET_RESTRICT" "$FOREIGN_PKGS com.tencent.mm com.mi.health com.heytap.health com.fcpower"
    merge_pkg_key "RECLAIM_PKGS" "$TARGET_RECLAIM" "$FOREIGN_PKGS com.heytap.health com.fcpower"
fi

# 仅在安装/升级期一次性恢复核心组件与 QQ/TIM 前台登录必需的 MsfService（避免在 service.sh 每次开机重复 enable 引发拉起后再杀的矛盾）
for _safe_pkg in $TARGET_PROTECTED; do
    pm enable "$_safe_pkg" >/dev/null 2>&1
done
pm enable "com.tencent.mobileqq/com.tencent.mobileqq.msf.service.MsfService" >/dev/null 2>&1
pm enable "com.tencent.mobileqq/com.tencent.mobileqq.remote.remotecontrol.RemoteControlService" >/dev/null 2>&1
pm enable "com.tencent.tim/com.tencent.mobileqq.msf.service.MsfService" >/dev/null 2>&1
pm enable "com.tencent.mm/com.tencent.mm.booter.CoreService" >/dev/null 2>&1
pm enable 'com.tencent.mm/com.tencent.mm.booter.NotifyReceiver$NotifyService' >/dev/null 2>&1
if [ "$ROM_TYPE" != "coloros" ]; then
    pm enable "com.tencent.mm/com.xiaomi.mipush.sdk.PushMessageHandler" >/dev/null 2>&1
    pm enable "com.tencent.mm/com.xiaomi.mipush.sdk.MessageHandleService" >/dev/null 2>&1
fi
if [ "$ROM_TYPE" != "hyperos" ]; then
    pm enable "com.tencent.mm/com.heytap.msp.push.service.DataMessageCallbackService" >/dev/null 2>&1
    pm enable "com.tencent.mm/com.heytap.msp.push.service.CompatibleDataMessageCallbackService" >/dev/null 2>&1
fi
cmd appops set com.tencent.mm RUN_IN_BACKGROUND allow >/dev/null 2>&1
cmd appops set com.tencent.mm RUN_ANY_IN_BACKGROUND allow >/dev/null 2>&1
cmd appops set com.tencent.mm START_FOREGROUND allow >/dev/null 2>&1
cmd appops set com.tencent.mm BOOT_COMPLETED allow >/dev/null 2>&1
cmd appops set com.tencent.mm WAKE_LOCK allow >/dev/null 2>&1
[ "$ROM_TYPE" = "hyperos" ] && cmd appops set com.tencent.mm 10008 allow >/dev/null 2>&1
am set-standby-bucket com.tencent.mm active >/dev/null 2>&1
dumpsys deviceidle whitelist +com.tencent.mm >/dev/null 2>&1
if [ "$ROM_TYPE" = "hyperos" ]; then
    am set-standby-bucket com.xiaomi.xmsf active >/dev/null 2>&1
    dumpsys deviceidle whitelist +com.xiaomi.xmsf >/dev/null 2>&1
fi
    :

# 若本机装有 Termux clang/gcc 且用户修改过 src/ballast_daemon.c，支持自动重编译；否则直接使用内置静态 ARM64 原生二进制
for _cc in /data/data/com.termux/files/usr/bin/clang /data/data/com.termux/files/usr/bin/gcc; do
    if [ -x "$_cc" ] && [ -f "$MODPATH/src/ballast_daemon.c" ]; then
        if "$_cc" -O3 -s "$MODPATH/src/ballast_daemon.c" -o "$MODPATH/bin/ballast_daemon.new" >/dev/null 2>&1; then
            mv "$MODPATH/bin/ballast_daemon.new" "$MODPATH/bin/ballast_daemon"
    :
            break
        fi
        rm -f "$MODPATH/bin/ballast_daemon.new" 2>/dev/null
    fi
done

set_perm_recursive "$MODPATH" 0 0 0755 0644
set_perm "$MODPATH/post-fs-data.sh" 0 0 0755
set_perm "$MODPATH/service.sh" 0 0 0755
set_perm "$MODPATH/tombstone_daemon.sh" 0 0 0755
set_perm "$MODPATH/uninstall.sh" 0 0 0755
set_perm "$MODPATH/check.sh" 0 0 0755
set_perm "$MODPATH/action.sh" 0 0 0755
set_perm "$MODPATH/ram_compact.sh" 0 0 0755
[ -f "$MODPATH/start_temp_root.sh" ] && set_perm "$MODPATH/start_temp_root.sh" 0 0 0755
[ -f "$MODPATH/bin/ballast_daemon" ] && set_perm "$MODPATH/bin/ballast_daemon" 0 0 0755
[ -f "$MODPATH/system/bin/ballast_probe" ] && set_perm "$MODPATH/system/bin/ballast_probe" 0 0 0755
[ -f "$MODPATH/ballast_probe.sh" ] && set_perm "$MODPATH/ballast_probe.sh" 0 0 0755
    :

# 创建便捷终端命令软链接：统一指向生效目录 $FINAL_MODDIR，杜绝指向安装期临时目录 $MODPATH (modules_update)
mkdir -p /data/adb/ksu/bin 2>/dev/null
ln -sf "$FINAL_MODDIR/action.sh" /data/adb/ksu/bin/compress_ram 2>/dev/null
ln -sf "$FINAL_MODDIR/bin/ballast_daemon" /data/adb/ksu/bin/ballast_daemon 2>/dev/null
printf '#!/system/bin/sh\nexec sh "%s/ram_compact.sh" clear "$@"\n' "$FINAL_MODDIR" > /data/adb/ksu/bin/ram_clear 2>/dev/null
printf '#!/system/bin/sh\nexec sh "%s/ram_compact.sh" compact "$@"\n' "$FINAL_MODDIR" > /data/adb/ksu/bin/ram_compact 2>/dev/null
chmod 0755 /data/adb/ksu/bin/ram_clear /data/adb/ksu/bin/ram_compact 2>/dev/null

rm -f /data/adb/ksu_mem_opt.applied_hash 2>/dev/null
# v6.7.4 免重启热更新：若当前设备已运行旧版 Ballast，自动热同步二进制与脚本并重启守护进程，无需重启手机即可生效！
if [ -d "$FINAL_MODDIR" ] && [ "$MODPATH" != "$FINAL_MODDIR" ]; then
    :
    mkdir -p "$FINAL_MODDIR/bin" "$FINAL_MODDIR/src" 2>/dev/null
    for _hf in action.sh check.sh post-fs-data.sh ram_compact.sh ram_notify_daemon.sh ballast_probe.sh service.sh tombstone_daemon.sh uninstall.sh module.prop; do
        [ -f "$MODPATH/$_hf" ] && cp -f "$MODPATH/$_hf" "$FINAL_MODDIR/$_hf" 2>/dev/null
    done
    [ -f "$MODPATH/src/ballast_daemon.c" ] && cp -f "$MODPATH/src/ballast_daemon.c" "$FINAL_MODDIR/src/ballast_daemon.c" 2>/dev/null
    if [ -f "$MODPATH/bin/ballast_daemon" ]; then
        cp -f "$MODPATH/bin/ballast_daemon" "$FINAL_MODDIR/bin/ballast_daemon.new" 2>/dev/null
        chmod 0755 "$FINAL_MODDIR/bin/ballast_daemon.new" 2>/dev/null
        mv -f "$FINAL_MODDIR/bin/ballast_daemon.new" "$FINAL_MODDIR/bin/ballast_daemon" 2>/dev/null
    fi
    chmod 0755 "$FINAL_MODDIR"/*.sh "$FINAL_MODDIR/bin/ballast_daemon" 2>/dev/null
    # 1) 热重启纯 C 守护进程
    pkill -f "ballast_daemon|tombstone_daemon.sh" >/dev/null 2>&1
    sleep 1
    if [ -x "$FINAL_MODDIR/bin/ballast_daemon" ] && "$FINAL_MODDIR/bin/ballast_daemon" --selftest >/dev/null 2>&1; then
        nohup "$FINAL_MODDIR/bin/ballast_daemon" daemon </dev/null >/dev/null 2>&1 &
    fi
    # 2) 即时下发新增软笼 (mydevices 128MB / keyboard 160MB / avail_buffers 900) 并温和清理闲置欢太健康主进程
    [ -w /sys/fs/cgroup/memory.avail_buffers ] && echo "750 600 750 640" > /sys/fs/cgroup/memory.avail_buffers 2>/dev/null
    [ -w /sys/fs/cgroup/memory.compress_ratio ] && echo "60" > /sys/fs/cgroup/memory.compress_ratio 2>/dev/null
    for _hp_pair in "com.heytap.mydevices:100663296" "com.oplus.keyboard:134217728" "com.coloros.smartsidebar:67108864" "com.oplus.games:67108864"; do
        _hpkg="${_hp_pair%%:*}"
        _hlim="${_hp_pair##*:}"
        _huid=$(awk -v p="$_hpkg" '$1==p {print $2; exit}' /data/system/packages.list 2>/dev/null)
        if [ -n "$_huid" ] && [ "$_huid" -ge 10000 ] 2>/dev/null; then
            for _hcp in "/sys/fs/cgroup/apps/uid_${_huid}/memory.high" "/sys/fs/cgroup/uid_${_huid}/memory.high"; do
                [ -w "$_hcp" ] && echo "$_hlim" > "$_hcp" 2>/dev/null && break
            done
        fi
    done
    for _stmp in com.ss.android.ugc.aweme com.ss.android.ugc.aweme.lite com.ss.android.ugc.aweme.mobile com.ss.android.ugc.live com.ss.android.yumme.video com.ss.android.ugc.trill com.phoenix.read com.smile.gifmaker com.kuaishou.nebula com.xingin.xhs com.ss.android.article.video tv.danmaku.bili com.bilibili.app.in com.tencent.qqlive com.qiyi.video com.iqiyi.i18n com.youku.phone com.hunantv.imgo.activity air.tv.douyu.android com.duowan.kiwi com.google.android.youtube com.zhiliaoapp.musically com.netflix.mediaclient; do
        _suid=$(awk -v p="$_stmp" '$1==p {print $2; exit}' /data/system/packages.list 2>/dev/null)
        if [ -n "$_suid" ] && [ "$_suid" -ge 10000 ] 2>/dev/null; then
            for _scp in "/sys/fs/cgroup/apps/uid_${_suid}/memory.high" "/sys/fs/cgroup/uid_${_suid}/memory.high"; do
                [ -w "$_scp" ] && echo "201326592" > "$_scp" 2>/dev/null && break
            done
        fi
    done
    for _hp in $(pidof com.heytap.health com.heytap.health:once 2>/dev/null); do
        _hadj=$(cat "/proc/$_hp/oom_score_adj" 2>/dev/null)
        [ "${_hadj:-0}" -gt 200 ] 2>/dev/null && kill -15 "$_hp" 2>/dev/null
    done
    # v6.7.4: 热更新即时开启最近任务可用内存显示
    if command -v settings >/dev/null 2>&1; then
        _h_miui="$(getprop ro.miui.ui.version.name 2>/dev/null)$(getprop ro.mi.os.version.name 2>/dev/null)"
        _h_oplus="$(getprop ro.build.version.oplusrom 2>/dev/null)"
        if [ -n "$_h_miui" ]; then
            settings put system miui_recents_show_mem_info 1 >/dev/null 2>&1
        elif [ -n "$_h_oplus" ]; then
            settings put secure allow_memory_info_display 1 >/dev/null 2>&1
            settings put secure display_memory_information_recent_task 1 >/dev/null 2>&1
        fi
    fi
        # v6.7.4: 热更新即时启动下拉通知栏实时内存条
    if [ -f "$_LIVE_MOD/ram_notify_daemon.sh" ]; then
        chmod 0755 "$_LIVE_MOD/ram_notify_daemon.sh" 2>/dev/null
        mkdir -p /data/adb/ksu/bin 2>/dev/null
        printf '#!/system/bin/sh\nexec sh "%s/ram_notify_daemon.sh" "$@"\n' "$_LIVE_MOD" > /data/adb/ksu/bin/ram_notify 2>/dev/null
        printf '#!/system/bin/sh\nexec sh "%s/ballast_probe.sh" "$@"\n' "$_LIVE_MOD" > /data/adb/ksu/bin/ballast_probe 2>/dev/null
        chmod 0755 /data/adb/ksu/bin/ram_notify /data/adb/ksu/bin/ballast_probe 2>/dev/null
        pkill -f "ram_notify_daemon.sh daemon" >/dev/null 2>&1
        nohup sh "$_LIVE_MOD/ram_notify_daemon.sh" daemon </dev/null >/dev/null 2>&1 &
    fi
    cp -f "$MODPATH/ballast_probe.sh" /storage/emulated/0/ballast_probe.sh 2>/dev/null
    ui_print "- 扫描脚本: /storage/emulated/0/ballast_probe.sh"
    ui_print "- ✔ 热更新完成 (v6.7.4，免重启生效)"
    :
else
    # 首次刷入/临时 Root 免重启模式：同步至 /data/local/tmp/ballast_run 并立即在后台拉起全套 service.sh + Pure-C 守护！
    :
    _TR_DIR="/data/local/tmp/ballast_run"
    mkdir -p "$_TR_DIR/bin" "$_TR_DIR/src" 2>/dev/null
    for _hf in action.sh check.sh post-fs-data.sh ram_compact.sh ram_notify_daemon.sh ballast_probe.sh service.sh tombstone_daemon.sh uninstall.sh module.prop start_temp_root.sh; do
        [ -f "$MODPATH/$_hf" ] && cp -f "$MODPATH/$_hf" "$_TR_DIR/$_hf" 2>/dev/null
    done
    [ -f "$MODPATH/bin/ballast_daemon" ] && cp -f "$MODPATH/bin/ballast_daemon" "$_TR_DIR/bin/ballast_daemon" 2>/dev/null
    chmod 0755 "$_TR_DIR"/*.sh "$_TR_DIR/bin/ballast_daemon" 2>/dev/null
    sh "$_TR_DIR/post-fs-data.sh" >/dev/null 2>&1
    pkill -f "ballast_daemon|tombstone_daemon.sh" >/dev/null 2>&1
    nohup sh "$_TR_DIR/service.sh" </dev/null >/dev/null 2>&1 &
    cp -f "$MODPATH/ballast_probe.sh" /storage/emulated/0/ballast_probe.sh 2>/dev/null
    ui_print "- 扫描脚本: /storage/emulated/0/ballast_probe.sh"
    ui_print "- ✔ 安装完成 (v6.7.4，已激活；首次建议重启一次)"
    :
fi
