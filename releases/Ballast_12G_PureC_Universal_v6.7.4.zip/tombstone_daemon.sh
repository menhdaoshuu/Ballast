#!/system/bin/sh
# Tombstone Turbo Daemon (v4.2 12G双系统通用版：修复切回解冻 + adj<=200前台服务豁免 + 仅Per-PID精准冻结 + 熄屏双级冷却CD)

LOG_FILE="/data/adb/ksu_tombstone.log"
MODDIR=${0%/*}
NATIVE_BIN="$MODDIR/bin/ballast_daemon"
chmod 0755 "$NATIVE_BIN" 2>/dev/null
if [ -x "$NATIVE_BIN" ] && "$NATIVE_BIN" --selftest >/dev/null 2>&1; then
    exec "$NATIVE_BIN" daemon
fi
CONF="/data/adb/ksu_tombstone.conf"
MEM_CONF="/data/adb/ksu_mem_opt.conf"
UID_CACHE="/data/adb/.ksu_uid_cache"

log() {
    if [ -f "$LOG_FILE" ] && [ "$(wc -c < "$LOG_FILE")" -gt 204800 ]; then
        : > "$LOG_FILE"
    fi
    echo "[$(date '+%m-%d %H:%M:%S')] $1" >> "$LOG_FILE"
}

# 双系统全量免冻结白名单 (同时涵盖 ColorOS 与 小米澎湃OS 的桌面、插件、手环健康、语音助手与输入法)
DEFAULT_WHITELIST="
com.android.launcher
com.oplus.launcher
com.miui.home
com.z1812.hyperhome
com.vt.launcher
com.android.systemui
com.android.settings
miui.systemui.plugin
com.coloros.smartsidebar
com.fcpower
io.github.hyperisland
io.github.wumisc.antiburn
dev.lackluster.mihelper
io.github.vivibibi30.hyperpguard
cc.liujiale.wxpad
me.weishu.kernelsu
bin.mt.plus.canary
org.frknkrc44.hma_oss
com.omarea.vtools
xzr.konabess
com.oplus.keyboard
com.baidu.input_oppo
com.baidu.input_mi
com.iflytek.inputmethod
com.iflytek.inputmethod.miui
com.sohu.inputmethod.sogou.xiaomi
com.miui.securityinputmethod
com.android.inputmethod.latin
com.google.android.inputmethod.latin
com.heytap.accessory
com.heytap.mydevices
com.heytap.health
com.mi.health
com.xiaomi.xmsf
com.xiaomi.xmsfkeeper
com.miui.securitycenter
com.miui.powerkeeper
com.miui.guardprovider
com.miui.securityadd
com.lbe.security.miui
com.xiaomi.finddevice
com.miui.miwallpaper
com.miui.aod
com.miui.barrage
com.miui.contentextension
com.miui.screenshot
com.miui.notification
com.miui.personalassistant
com.miui.voiceassist
com.xiaomi.mibrain.speech
com.miui.voicetrigger
com.xiaomi.aiservice
com.xiaomi.mi_connect_service
com.milink.service
com.xiaomi.mirror
com.android.phone
com.xiaomi.phone
com.android.incallui
com.android.server.telecom
com.android.bluetooth
com.xiaomi.bluetooth
com.android.nfc
com.follow.clash
com.github.metacubex.clash.meta
"

FREEZE_DELAY=10
POLL_INTERVAL=5
# 熄屏冷页回收冷却时间 (600秒=10分钟) 与 熄屏 ZRAM 写盘回写冷却时间 (1800秒=30分钟)，防止频繁亮灭屏刷写闪存
SCREENOFF_RECLAIM_CD=600
SCREENOFF_WB_CD=1800
BG_DENY_PKGS="com.tencent.mobileqq com.tencent.tim com.eg.android.AlipayGphone"
_MEM_CONF_MTIME=""
_TOMB_CONF_MTIME=""

load_Configs() {
    [ -f "$MEM_CONF" ] && . "$MEM_CONF"
    [ -f "$CONF" ] && . "$CONF"
    case "$FREEZE_DELAY" in ''|*[!0-9]*) FREEZE_DELAY=10 ;; esac
    case "$POLL_INTERVAL" in ''|*[!0-9]*) POLL_INTERVAL=5 ;; esac
    case "$SCREENOFF_RECLAIM_CD" in ''|*[!0-9]*) SCREENOFF_RECLAIM_CD=600 ;; esac
    case "$SCREENOFF_WB_CD" in ''|*[!0-9]*) SCREENOFF_WB_CD=1800 ;; esac
    [ -n "$BG_DENY_PKGS" ] || BG_DENY_PKGS="com.tencent.mobileqq com.tencent.tim com.eg.android.AlipayGphone"
}
load_Configs
[ -f "$MEM_CONF" ] && _MEM_CONF_MTIME=$(stat -c %Y "$MEM_CONF" 2>/dev/null)
[ -f "$CONF" ] && _TOMB_CONF_MTIME=$(stat -c %Y "$CONF" 2>/dev/null)

touch "$UID_CACHE" 2>/dev/null

# 纯内置多背光节点遍历检测亮/熄屏状态（零 cat 子进程）
is_screen_on_fast() {
    local _b _val _found=0
    for _b in /sys/class/backlight/*/brightness /sys/class/leds/lcd-backlight/brightness; do
        if [ -r "$_b" ]; then
            _found=1
            read -r _val < "$_b" 2>/dev/null
            _val=${_val%%[[:space:]]*}
            [ "${_val:-0}" -gt 0 ] 2>/dev/null && return 0
        fi
    done
    [ "$_found" -eq 1 ] && return 1
    return 0
}
is_screen_on() { is_screen_on_fast; }

# 纯内置读取 /proc/uptime 整数秒，消除高频 date +%s 子进程 fork
read_uptime_sec() {
    local _up _idle
    if read -r _up _idle < /proc/uptime 2>/dev/null; then
        printf '%s' "${_up%%.*}"
        return 0
    fi
    date +%s
}

# 纯内置读取 /proc/$pid/cmdline 的进程名（零 tr/awk/cat 子进程）
read_proc_name() {
    local _pid="$1" _cmd=""
    [ -r "/proc/$_pid/cmdline" ] || return 1
    IFS= read -r -d '' _cmd < "/proc/$_pid/cmdline" 2>/dev/null || [ -n "$_cmd" ] || return 1
    _cmd=${_cmd%%[[:space:]]*}
    [ -n "$_cmd" ] || return 1
    printf '%s' "$_cmd"
}

# 纯内置读取 /proc/$pid/status 的真实 Uid（零 awk 子进程）
read_proc_uid() {
    local _pid="$1" _k _u _rest
    [ -r "/proc/$_pid/status" ] || return 1
    while read -r _k _u _rest; do
        if [ "$_k" = "Uid:" ]; then
            printf '%s' "$_u"
            return 0
        fi
    done < "/proc/$_pid/status" 2>/dev/null
    return 1
}

# 判断是否为双系统临时浮层（控制中心插件、侧边栏、流体云、灵动岛、输入法、截屏、分享面板等弹出时不视为离开当前前台应用）
is_transient_overlay() {
    case "$1" in
        com.android.systemui|miui.systemui.plugin|com.coloros.smartsidebar|com.fcpower|io.github.hyperisland|io.github.wumisc.antiburn|com.miui.screenshot|com.oplus.screenshot|com.miui.contentextension|com.miui.securityadd|com.miui.barrage|com.miui.notification|com.miui.voiceassist|com.heytap.speechassist|com.xiaomi.aiasst.vision|com.android.intentresolver|com.android.permissioncontroller|com.lbe.security.miui|com.miui.packageinstaller|com.oplus.keyboard|com.baidu.input*|com.android.inputmethod.latin|com.google.android.inputmethod.latin|com.tencent.wetype|com.sohu.inputmethod*|com.iflytek.inputmethod*|com.miui.securityinputmethod)
            return 0
            ;;
    esac
    return 1
}

# 防误判零 dumpsys 快路径：
# 1) 稳态下当 /dev/cpuset/top-app/cgroup.procs 进程集合签名未变化时，直接返回上次确认的包名（0 dumpsys 开销）；
# 2) 仅当 top-app 集合发生变化时调用一次 dumpsys window 精确解析 mFocusedApp / mCurrentFocus。
_LAST_TOP_SIG=""
_LAST_TOP_PKG=""
get_top_app() {
    local _cg_file="" _line _sig="" _cand=""
    for _cg_file in /dev/cpuset/top-app/cgroup.procs /sys/fs/cgroup/cpuset/top-app/cgroup.procs; do
        [ -r "$_cg_file" ] && break
        _cg_file=""
    done

    if [ -n "$_cg_file" ]; then
        while read -r _line; do
            [ -n "$_line" ] && _sig="${_sig}:${_line}"
        done < "$_cg_file" 2>/dev/null

        if [ -n "$_sig" ] && [ "$_sig" = "$_LAST_TOP_SIG" ] && [ -n "$_LAST_TOP_PKG" ]; then
            printf '%s' "$_LAST_TOP_PKG"
            return 0
        fi
    fi

    # 零 dumpsys 纯 /proc + top-app cpuset 解析当前前台包名 (优先 uid>=10000 且 0<=adj<=100 的应用)
    local _tpid _tuid _tadj _tname _tpkg _best_score=1000 _score
    if [ -n "$_cg_file" ]; then
        while read -r _tpid; do
            [ -n "$_tpid" ] && [ -r "/proc/$_tpid/oom_score_adj" ] || continue
            read -r _tadj < "/proc/$_tpid/oom_score_adj" 2>/dev/null
            case "$_tadj" in ''|*[!0-9-]*) continue ;; esac
            [ "$_tadj" -ge 0 ] && [ "$_tadj" -le 100 ] || continue
            _tuid=$(read_proc_uid "$_tpid")
            [ "${_tuid:-0}" -ge 10000 ] || { [ "${_tuid:-0}" -eq 1000 ] && [ "$_tadj" -eq 0 ]; } || continue
            _tname=$(read_proc_name "$_tpid")
            _tpkg=${_tname%%:*}
            case "$_tpkg" in *.*) ;; *) continue ;; esac
            is_transient_overlay "$_tpkg" && continue
            if [ "${_tuid:-0}" -ge 10000 ]; then _score="$_tadj"; else _score=$((_tadj + 101)); fi
            if [ "$_score" -le "$_best_score" ]; then
                _best_score="$_score"
                _cand="$_tpkg"
            fi
        done < "$_cg_file" 2>/dev/null
    fi

    if [ -n "$_cand" ]; then
        if is_transient_overlay "$_cand" && [ -n "$_LAST_TOP_PKG" ]; then
            _cand="$_LAST_TOP_PKG"
        fi
        _LAST_TOP_SIG="$_sig"
        _LAST_TOP_PKG="$_cand"
        printf '%s' "$_cand"
        return 0
    fi

    [ -n "$_LAST_TOP_PKG" ] && printf '%s' "$_LAST_TOP_PKG"
}

is_bg_push_proc() {
    case "$1" in
        *:MSF*|*:push*|*:pushservice*|*:channel*|*:ipc*|*:daemon*|*:support*|*:account*)
            return 0
            ;;
    esac
    return 1
}

# 检查应用是否处于前台、小窗可见，或持有前台服务 (adj <= 200：涵盖后台听歌/导航/录音/下载等 PERCEPTIBLE / FOREGROUND_SERVICE 进程)
is_app_visible() {
    local pkg="$1" pids pid adj proc_name min_adj=1000 has_main=0
    [ -z "$pkg" ] && return 1
    [ "$pkg" = "$CURRENT_APP" ] && return 0

    pids=$( { pidof "$pkg" 2>/dev/null | tr ' ' '\n'; pgrep -f "^${pkg}($|:)" 2>/dev/null; } | sort -u )
    [ -z "$pids" ] && return 1

    for pid in $pids; do
        [ -r "/proc/$pid/oom_score_adj" ] || continue
        proc_name=$(read_proc_name "$pid")
        [ -z "$proc_name" ] && proc_name="$pkg"
        [ "$proc_name" = "$pkg" ] && has_main=1
        is_bg_push_proc "$proc_name" && continue

        adj=""
        read -r adj < "/proc/$pid/oom_score_adj" 2>/dev/null
        case "$adj" in ''|*[!0-9-]*) continue ;; esac
        # adj <= 200 涵盖前台 Activity (0)、可见小窗 (100) 与前台服务/媒体播放/导航 (200)，直接豁免冻结！
        [ "$adj" -le 200 ] && return 0
        [ "$adj" -lt "$min_adj" ] && min_adj="$adj"
    done

    [ "$has_main" -eq 0 ] && [ "$min_adj" -gt 250 ] && return 1
    [ "$min_adj" -gt 250 ] && return 1

    return 1
}

_CHECKED_BG_PIDS=""
thaw_visible_windows() {
    [ -z "$FROZEN_PIDS" ] && return 0
    local entry pkg pid adj thaw_pkgs="" check_pkgs="" new_list="" new_checked="" t_pkg
    for entry in $FROZEN_PIDS; do
        pkg=${entry%:*}
        pid=${entry#*:}
        if [ ! -r "/proc/$pid/oom_score_adj" ]; then
            continue
        fi
        adj=""
        read -r adj < "/proc/$pid/oom_score_adj" 2>/dev/null
        case "$adj" in ''|*[!0-9-]*) new_list="$new_list $entry"; continue ;; esac
        if [ "$adj" -le 200 ]; then
            case " $thaw_pkgs " in
                *" $pkg "*) ;;
                *) thaw_pkgs="$thaw_pkgs $pkg" ;;
            esac
            # 关键修复：必须保留 entry 在 new_list 中，供下方 unfreeze_app 命中 has_record=1 执行实际解冻并由 remove_frozen_pkg 清理！
            new_list="$new_list $entry"
        elif [ "$adj" -le 250 ]; then
            case " $_CHECKED_BG_PIDS " in
                *" ${pid}:${adj} "*)
                    new_checked="$new_checked ${pid}:${adj}"
                    ;;
                *)
                    case " $thaw_pkgs $check_pkgs " in
                        *" $pkg "*) ;;
                        *) check_pkgs="$check_pkgs $pkg" ;;
                    esac
                    new_checked="$new_checked ${pid}:${adj}"
                    ;;
            esac
            new_list="$new_list $entry"
        else
            new_list="$new_list $entry"
        fi
    done
    _CHECKED_BG_PIDS="${new_checked# }"

    for t_pkg in $check_pkgs; do
        if is_app_visible "$t_pkg"; then
            thaw_pkgs="$thaw_pkgs $t_pkg"
        fi
    done

    FROZEN_PIDS="${new_list# }"

    for t_pkg in $thaw_pkgs; do
        unfreeze_app "$t_pkg"
    done
}

get_uid_cached() {
    local target="$1" uid _p _u
    while read -r _p _u; do
        if [ "$_p" = "$target" ]; then
            printf '%s' "$_u"
            return 0
        fi
    done < "$UID_CACHE" 2>/dev/null
    # 直接从 /data/system/packages.list 读取 UID，彻底消除 dumpsys package Binder 开销
    if [ -r /data/system/packages.list ]; then
        while read -r _p _u _rest; do
            if [ "$_p" = "$target" ]; then
                uid="$_u"
                break
            fi
        done < /data/system/packages.list 2>/dev/null
    fi
    [ -n "$uid" ] && echo "$target $uid" >> "$UID_CACHE"
    echo "$uid"
}

is_whitelisted() {
    local target="$1" uid item
    for item in $DEFAULT_WHITELIST $USER_WHITELIST; do
        [ "$item" = "$target" ] && return 0
    done
    uid=$(get_uid_cached "$target")
    if [ -n "$uid" ] && [ "$uid" -lt 10000 ]; then
        return 0
    fi
    return 1
}

is_bg_deny_pkg() {
    local target="$1" item
    [ -z "$target" ] && return 1
    [ "$target" = "com.tencent.mm" ] && return 1
    is_whitelisted "$target" && return 1
    for item in $BG_DENY_PKGS; do
        [ "$item" = "$target" ] && return 0
    done
    return 1
}

# Per-PID 精准冻结：严禁向整组 /sys/fs/cgroup/uid_${uid}/cgroup.freeze 写入 1，防止父节点锁死导致进程切回无法解冻
set_freeze() {
    local pid="$1" state="$2" cg_v2="" cg_v1="" uid _id _sub _path
    [ -d "/proc/$pid" ] || return 1

    while IFS=':' read -r _id _sub _path; do
        if [ "$_id" = "0" ] && [ -n "$_path" ]; then
            cg_v2="$_path"
        elif [ -z "$cg_v1" ]; then
            case "$_sub" in *freezer*) cg_v1="$_path" ;; esac
        fi
    done < "/proc/$pid/cgroup" 2>/dev/null

    if [ -n "$cg_v2" ]; then
        uid=$(read_proc_uid "$pid")
        # 解冻时若父级 uid 节点曾被锁死，一并解锁
        if [ "$state" = "0" ] && [ -n "$uid" ] && [ -w "/sys/fs/cgroup/uid_${uid}/cgroup.freeze" ]; then
            echo 0 > "/sys/fs/cgroup/uid_${uid}/cgroup.freeze" 2>/dev/null
        fi
        # 仅当 cg_v2 路径明确指向 pid_ 子目录时才写入，绝不向 uid_ 根容器写 1
        case "$cg_v2" in
            */pid_*)
                if [ -w "/sys/fs/cgroup${cg_v2}/cgroup.freeze" ]; then
                    echo "$state" > "/sys/fs/cgroup${cg_v2}/cgroup.freeze" 2>/dev/null && return 0
                fi
                ;;
        esac
        if [ -n "$uid" ] && [ -w "/sys/fs/cgroup/uid_${uid}/pid_${pid}/cgroup.freeze" ]; then
            echo "$state" > "/sys/fs/cgroup/uid_${uid}/pid_${pid}/cgroup.freeze" 2>/dev/null && return 0
        fi
    fi

    if [ -n "$cg_v1" ]; then
        local v1_val="THAWED"
        [ "$state" = "1" ] && v1_val="FROZEN"
        if [ -w "/dev/freezer${cg_v1}/freezer.state" ]; then
            echo "$v1_val" > "/dev/freezer${cg_v1}/freezer.state" 2>/dev/null && return 0
        elif [ -w "/sys/fs/cgroup/freezer${cg_v1}/freezer.state" ]; then
            echo "$v1_val" > "/sys/fs/cgroup/freezer${cg_v1}/freezer.state" 2>/dev/null && return 0
        fi
    fi
    return 1
}

FROZEN_PIDS=""

remove_frozen_pkg() {
    local target_pkg="$1" entry e_pkg new_list=""
    for entry in $FROZEN_PIDS; do
        e_pkg=${entry%:*}
        [ "$e_pkg" = "$target_pkg" ] && continue
        new_list="$new_list $entry"
    done
    FROZEN_PIDS="${new_list# }"
}

# 微信无损冷页瘦身：仅对微信全进程执行冷匿名页(anon)换出至 ZRAM，绝不单方面冻结小程序/WebView子进程或发送 TRIM_COMPLETE
smart_compact_wechat() {
    local pids pid reclaimed_cnt=0
    if is_app_visible "com.tencent.mm"; then
        return
    fi
    pids=$( { pidof "com.tencent.mm" 2>/dev/null | tr ' ' '\n'; pgrep -f "^com\.tencent\.mm($|:)" 2>/dev/null; } | sort -u )
    [ -z "$pids" ] && return

    for pid in $pids; do
        [ -d "/proc/$pid" ] || continue
        if [ -w "/proc/$pid/reclaim" ]; then
            echo "anon" > "/proc/$pid/reclaim" 2>/dev/null && reclaimed_cnt=$((reclaimed_cnt + 1))
        fi
    done
    [ "$reclaimed_cnt" -gt 0 ] && log "【微信无损瘦身】已将微信主进程及小程序/WebView共 ${reclaimed_cnt} 个进程的冷匿名页压入 ZRAM (不杀页面)"
}

freeze_and_compress() {
    local pkg="$1" pids pid adj proc_name frozen_cnt=0
    if [ "$pkg" = "com.tencent.mm" ]; then
        smart_compact_wechat
        return
    fi
    if is_app_visible "$pkg"; then
        return
    fi
    pids=$( { pidof "$pkg" 2>/dev/null | tr ' ' '\n'; pgrep -f "^${pkg}($|:)" 2>/dev/null; } | sort -u )
    [ -z "$pids" ] && return

    # 二次核验：若包内存在 adj <= 200 的非推送进程（如后台听歌、导航、下载前台服务），整包豁免冻结！
    for pid in $pids; do
        [ -r "/proc/$pid/oom_score_adj" ] || continue
        proc_name=$(read_proc_name "$pid")
        is_bg_push_proc "${proc_name:-$pkg}" && continue
        adj=""
        read -r adj < "/proc/$pid/oom_score_adj" 2>/dev/null
        case "$adj" in ''|*[!0-9-]*) continue ;; esac
        if [ "$adj" -le 200 ]; then
            log "【前台服务保护】检测到 $pkg 存在活跃服务进程 (PID:$pid adj=$adj <= 200)，豁免冻结"
            return
        fi
    done

    remove_frozen_pkg "$pkg"

    for pid in $pids; do
        [ -d "/proc/$pid" ] || continue
        if [ -w "/proc/$pid/reclaim" ]; then
            echo "anon" > "/proc/$pid/reclaim" 2>/dev/null
        fi
        if set_freeze "$pid" 1; then
            frozen_cnt=$((frozen_cnt + 1))
            FROZEN_PIDS="${FROZEN_PIDS:+$FROZEN_PIDS }${pkg}:${pid}"
        fi
    done
    [ "$frozen_cnt" -gt 0 ] && log "【无损墓碑】已无损冻结并换出冷页至 ZRAM (保留Activity状态): $pkg (${frozen_cnt} 进程)"
}

unfreeze_app() {
    local pkg="$1" pids pid entry e_pkg e_pid thawed_cnt=0 has_record=0
    case " $FROZEN_PIDS " in
        *" ${pkg}:"*) has_record=1 ;;
    esac
    # 快路径：thaw_visible_windows 已保留全部待解冻记录，若 FROZEN_PIDS 无该包记录则说明从未被冻结，直接零开销返回
    [ "$has_record" -eq 0 ] && return 0

    for entry in $FROZEN_PIDS; do
        e_pkg=${entry%:*}
        e_pid=${entry#*:}
        if [ "$e_pkg" = "$pkg" ] && [ -d "/proc/$e_pid" ]; then
            set_freeze "$e_pid" 0 && thawed_cnt=$((thawed_cnt + 1))
        fi
    done
    remove_frozen_pkg "$pkg"

    pids=$( { pidof "$pkg" 2>/dev/null | tr ' ' '\n'; pgrep -f "^${pkg}($|:)" 2>/dev/null; } | sort -u )
    for pid in $pids; do
        [ -d "/proc/$pid" ] || continue
        set_freeze "$pid" 0
    done
    [ "$thawed_cnt" -gt 0 ] && log "【唤醒解冻】已恢复运行: $pkg (${thawed_cnt} 进程)"
}

kill_if_bg() {
    local pkg="$1"
    if [ -n "$(pidof "$pkg" 2>/dev/null)" ] || pgrep -f "^${pkg}:" >/dev/null 2>&1; then
        is_app_visible "$pkg" && return
        am force-stop "$pkg" >/dev/null 2>&1
        pkill -9 -f "^${pkg}($|:)" >/dev/null 2>&1
    fi
}

log "Tombstone v4.2 Universal 12G 守护进程已启动 (切回秒解冻 + adj<=200服务保护 + 熄屏双级冷却CD)..."

reclaim_all_bg() {
    local cur_top="$1" pid_dir pid adj uid pname pkg cnt=0
    for pid_dir in /proc/[0-9]*; do
        pid=${pid_dir#/proc/}
        [ -r "$pid_dir/oom_score_adj" ] || continue
        adj=""
        read -r adj < "$pid_dir/oom_score_adj" 2>/dev/null
        [ -z "$adj" ] && continue
        # 仅对 adj > 200 的純后台缓存进程执行冷页回收，不打扰 adj <= 200 的后台听歌/导航服务
        [ "$adj" -gt 200 ] || continue
        uid=$(read_proc_uid "$pid")
        [ "${uid:-0}" -ge 10000 ] || continue
        pname=$(read_proc_name "$pid")
        pkg=${pname%%:*}
        [ -n "$cur_top" ] && [ "$pkg" = "$cur_top" ] && continue
        if [ -w "$pid_dir/reclaim" ]; then
            echo "anon" > "$pid_dir/reclaim" 2>/dev/null && cnt=$((cnt + 1))
        fi
    done
    [ "$cnt" -gt 0 ] && log "【熄屏冷页回收】已将 ${cnt} 个后台进程冷页压入 ZRAM"
}

LAST_APP=""
PENDING_APP=""
PENDING_TIME=0
LOOP_CNT=0
LAST_SCREENOFF_RECLAIM_TS=0
LAST_SCREENOFF_WB_TS=0

while true; do
    if ! is_screen_on; then
        if [ -n "$PENDING_APP" ]; then
            if is_bg_deny_pkg "$PENDING_APP"; then
                kill_if_bg "$PENDING_APP"
            else
                freeze_and_compress "$PENDING_APP"
            fi
            PENDING_APP=""
        fi
        if [ "${SCREEN_OFF_RECLAIMED:-0}" -eq 0 ]; then
            NOW_OFF=$(read_uptime_sec)
            # 冷却保护 ①：距离上次熄屏全量冷页回收需满 SCREENOFF_RECLAIM_CD (默认 600s=10分钟)
            if [ "$LAST_SCREENOFF_RECLAIM_TS" -eq 0 ] || [ $(( NOW_OFF - LAST_SCREENOFF_RECLAIM_TS )) -ge "$SCREENOFF_RECLAIM_CD" ]; then
                smart_compact_wechat
                reclaim_all_bg ""
                for lpid in $(pidof com.miui.home com.z1812.hyperhome miui.systemui.plugin com.xiaomi.aicr com.android.launcher com.oplus.launcher 2>/dev/null); do
                    [ -w "/proc/$lpid/reclaim" ] && echo "anon" > "/proc/$lpid/reclaim" 2>/dev/null
                done
                LAST_SCREENOFF_RECLAIM_TS="$NOW_OFF"
            fi
            # 冷却保护 ②：距离上次熄屏 ZRAM 闲置块写盘需满 SCREENOFF_WB_CD (默认 1800s=30分钟)，杜绝短时间反复亮灭屏磨损闪存
            if [ "$LAST_SCREENOFF_WB_TS" -eq 0 ] || [ $(( NOW_OFF - LAST_SCREENOFF_WB_TS )) -ge "$SCREENOFF_WB_CD" ]; then
                if [ -f "${0%/*}/ram_compact.sh" ]; then
                    sh "${0%/*}/ram_compact.sh" screenoff >/dev/null 2>&1
                    log "【熄屏整合】已执行无损 ZRAM 闲置回写与内存碎片规整 (冷却CD: ${SCREENOFF_WB_CD}s)"
                fi
                LAST_SCREENOFF_WB_TS="$NOW_OFF"
            fi
            SCREEN_OFF_RECLAIMED=1
        fi
        sleep 30
        continue
    fi
    SCREEN_OFF_RECLAIMED=0

    sleep "$POLL_INTERVAL"
    thaw_visible_windows
    CURRENT_APP=$(get_top_app)
    [ -z "$CURRENT_APP" ] && continue

    if [ "$CURRENT_APP" != "$LAST_APP" ]; then
        unfreeze_app "$CURRENT_APP"
        if [ -n "$PENDING_APP" ] && [ "$PENDING_APP" != "$CURRENT_APP" ] && [ "$PENDING_APP" != "$LAST_APP" ]; then
            if ! is_app_visible "$PENDING_APP"; then
                if is_bg_deny_pkg "$PENDING_APP"; then
                    kill_if_bg "$PENDING_APP"
                else
                    freeze_and_compress "$PENDING_APP"
                fi
            fi
            PENDING_APP=""
        fi
        if [ -n "$LAST_APP" ] && ! is_whitelisted "$LAST_APP"; then
            PENDING_APP="$LAST_APP"
            PENDING_TIME=$(read_uptime_sec)
        fi
        LAST_APP="$CURRENT_APP"
    fi

    if [ -n "$PENDING_APP" ]; then
        NOW=$(read_uptime_sec)
        if [ $(( NOW - PENDING_TIME )) -ge "$FREEZE_DELAY" ]; then
            if ! is_app_visible "$PENDING_APP"; then
                if is_bg_deny_pkg "$PENDING_APP"; then
                    log "【后台强力压制】离开前台 -> 彻底清理 $PENDING_APP 全部后台进程"
                    am force-stop "$PENDING_APP" >/dev/null 2>&1
                    pkill -9 -f "^${PENDING_APP}($|:)" >/dev/null 2>&1
                else
                    freeze_and_compress "$PENDING_APP"
                fi
            fi
            PENDING_APP=""
        fi
    fi

    LOOP_CNT=$((LOOP_CNT + 1))
    if [ $((LOOP_CNT % 12)) -eq 0 ]; then
        _cur_mem_mtime=""
        _cur_tomb_mtime=""
        [ -f "$MEM_CONF" ] && _cur_mem_mtime=$(stat -c %Y "$MEM_CONF" 2>/dev/null)
        [ -f "$CONF" ] && _cur_tomb_mtime=$(stat -c %Y "$CONF" 2>/dev/null)
        if [ "$_cur_mem_mtime" != "$_MEM_CONF_MTIME" ] || [ "$_cur_tomb_mtime" != "$_TOMB_CONF_MTIME" ]; then
            load_Configs
            _MEM_CONF_MTIME="$_cur_mem_mtime"
            _TOMB_CONF_MTIME="$_cur_tomb_mtime"
        fi
        for _deny_pkg in $BG_DENY_PKGS; do
            [ "$CURRENT_APP" != "$_deny_pkg" ] && [ "$PENDING_APP" != "$_deny_pkg" ] && ! is_whitelisted "$_deny_pkg" && kill_if_bg "$_deny_pkg"
        done
    fi
done
