#!/system/bin/sh
# Ballast 双引擎无损内存清理与 ZRAM 压缩回写脚本 (12G ColorOS & 小米澎湃OS 双系统无损保后台通用版，适配 Android 12~17)
# 模式:
#   clear / broom : 模式①「轻量缓存清理」—— sync + drop_caches(3) + compact_memory(1)
#   compact       : 模式②「无损深度压缩/回写」—— ZRAM writeback + 厂商 memcg 匿名页换出 + /proc/$pid/reclaim(anon)
#   screenoff     : 熄屏静默整合模式 —— 仅执行 ZRAM 闲置块回写 + 物理内存碎片规整 (不刷 drop_caches、不触发水位挤压)

MODE="${1:-both}"
LEVEL="${2:-2}"
LOCK_DIR="/data/adb/.ballast_compact.lock"
MODDIR=${0%/*}
NATIVE_BIN="$MODDIR/bin/ballast_daemon"
chmod 0755 "$NATIVE_BIN" 2>/dev/null

# v5.3 无损高可用增效器：严禁 am kill-all 杀后台！仅温和释放系统底座闲置图形缓存 + 触发 ZRAM zsmalloc 物理紧缩
lossless_trim_and_zram_compact() {
    local mode_tag="${1:-both}"
    if [ "$mode_tag" != "screenoff" ] && [ "$mode_tag" != "clear" ] && [ "$mode_tag" != "broom" ] && [ "$mode_tag" != "1" ]; then
        # 仅向系统底座与桌面发送温和 BACKGROUND (40) 归还闲置图形纹理池，绝不调用 am kill-all 杀后台进程！
        for _cp in system_server com.android.systemui com.oplus.launcher com.miui.home com.android.launcher com.oplus.keyboard com.tencent.mm; do
            am send-trim-memory "$_cp" BACKGROUND >/dev/null 2>&1
        done
        # v6.4.3: 温和清理闲置的欢太健康 :once 与已退后台缓存主进程（永远保留 :transport 与 :SportDaemonService 保手表）
        for _hp in $(pidof com.heytap.health:once 2>/dev/null); do
            _hadj=$(cat "/proc/$_hp/oom_score_adj" 2>/dev/null)
            [ "${_hadj:-0}" -gt 200 ] 2>/dev/null && kill -15 "$_hp" 2>/dev/null
        done
        for _hp in $(pidof com.heytap.health 2>/dev/null); do
            _hadj=$(cat "/proc/$_hp/oom_score_adj" 2>/dev/null)
            [ "${_hadj:-0}" -gt 200 ] 2>/dev/null && kill -15 "$_hp" 2>/dev/null
        done
        # 触发 ColorOS 17 根 Cgroup 冷匿名页主动压入 ZRAM，一键立竿见影抬升可用内存
        for _mact in force_swapout_percent force_shrink_anon_percent; do
            [ -w "/sys/fs/cgroup/memory.${_mact}" ] && echo 75 > "/sys/fs/cgroup/memory.${_mact}" 2>/dev/null
        done
        echo "  ✓ 已触发根 Cgroup 冷匿名页主动压出 + 欢太健康闲置子进程清理（保留手表通道）" 
    fi
    # 触发 ZRAM zsmalloc 物理内存紧缩，将碎片化 zspage 直接归还给 MemAvailable
    if [ -w /sys/block/zram0/compact ]; then
        echo 1 > /sys/block/zram0/compact 2>/dev/null
        [ "$mode_tag" != "screenoff" ] && echo "  ✓ 已触发 zram0 zsmalloc 物理页紧缩 (无损归还压缩池碎片内存)"
    fi
}

if [ -x "$NATIVE_BIN" ] && "$NATIVE_BIN" --selftest >/dev/null 2>&1; then
    "$NATIVE_BIN" "$MODE" "$LEVEL"
    lossless_trim_and_zram_compact "$MODE"
    exit 0
fi

# ─────────────────────────────────────────────────────────────
# 引擎 ①：轻量缓存清理与碎片规整
# ─────────────────────────────────────────────────────────────
ram_broom_clear() {
    echo ">>> [引擎① 轻量清理] 正在同步脏页、释放内核可回收缓存并规整内存碎片..."
    sync
    if [ -w /proc/sys/vm/drop_caches ]; then
        echo 3 > /proc/sys/vm/drop_caches 2>/dev/null
        echo "  ✓ 已释放干净 PageCache / dentry / inode 缓存 (drop_caches=3)"
    fi
    if [ -w /proc/sys/vm/compact_memory ]; then
        echo 1 > /proc/sys/vm/compact_memory 2>/dev/null
        echo "  ✓ 已触发物理内存碎片规整 (compact_memory=1)"
    fi
}

# ─────────────────────────────────────────────────────────────
# 引擎 ②：无损内存冷页压缩与 ZRAM 闲置回写（不销毁后台 Activity 页面状态）
# ─────────────────────────────────────────────────────────────
ram_zram_writeback() {
    local mode_tag="${1:-normal}" wb_done=0
    if ! grep -q zram0 /proc/swaps 2>/dev/null; then
        return 0
    fi

    # A. 标准内核 /sys/block/zram0/writeback 通道 (兼容 ColorOS hybridswap_loop_device 与 小米 backing_dev，单次限额 512MB)
    local blk=""
    if [ -f /sys/block/zram0/hybridswap_loop_device ]; then
        blk=$(cat /sys/block/zram0/hybridswap_loop_device 2>/dev/null)
    elif [ -f /sys/block/zram0/backing_dev ]; then
        blk=$(cat /sys/block/zram0/backing_dev 2>/dev/null)
    fi

    if [ -n "$blk" ] && [ "$blk" != "none" ] && [ "$blk" != "chp" ] && [ -f /sys/block/zram0/writeback ]; then
        chmod 0664 /sys/block/zram0/idle /sys/block/zram0/writeback 2>/dev/null
        if [ -f /sys/block/zram0/writeback_limit_enable ]; then
            echo 1 > /sys/block/zram0/writeback_limit_enable 2>/dev/null
            echo $((512 * 1024 / 4)) > /sys/block/zram0/writeback_limit 2>/dev/null
        fi
        # 优先按真实闲置秒数 (1800s=30分钟) 标记真正冷页，绝不在回写前粗暴执行 echo all > zram0/idle 把热页当作冷页刷入闪存；
        # 先回写上一周期存活至今的真实冷页与不可压缩页，最后再做下一周期的老化标记。
        echo 1800 > /sys/block/zram0/idle 2>/dev/null
        for t in incompressible huge_idle idle; do
            echo "$t" > /sys/block/zram0/writeback 2>/dev/null && wb_done=1
        done
        echo all > /sys/block/zram0/idle 2>/dev/null
        [ "$wb_done" -eq 1 ] && echo "  ✓ 已触发 zram0 块设备冷页回写 (上限 512MB)"
    fi

    [ "$mode_tag" = "screenoff" ] && return $wb_done

    # B. 厂商 memcg 匿名页换出节点（仅针对匿名页 anon，不强刷 file 页避免应用切回卡顿）
    local memcg_root=""
    for d in /sys/fs/cgroup /dev/memcg /sys/fs/cgroup/memory; do
        [ -d "$d" ] && { memcg_root="$d"; break; }
    done

    if [ -n "$memcg_root" ]; then
        local actions=""
        if [ -f "$memcg_root/memory.force_swapout_percent" ]; then
            actions="force_swapout_percent force_shrink_anon_percent"
        elif [ -f "$memcg_root/memory.force_swapout" ]; then
            actions="force_swapout force_shrink_anon"
        elif [ -f "$memcg_root/memory.force_reclaim_zram" ]; then
            actions="force_reclaim_zram force_reclaim_anon"
        fi

        if [ -n "$actions" ]; then
            for act in $actions; do
                local v=1
                case "$act" in *percent) v=75 ;; esac
                [ -w "$memcg_root/memory.$act" ] && echo "$v" > "$memcg_root/memory.$act" 2>/dev/null
                for sub in "$memcg_root"/apps "$memcg_root"/bg; do
                    [ -d "$sub" ] || continue
                    [ -w "$sub/memory.$act" ] && echo "$v" > "$sub/memory.$act" 2>/dev/null
                done
            done
            wb_done=1
            echo "  ✓ 已触发 memcg 后台冷匿名页温和换入 ZRAM ($memcg_root)"
        fi
    fi
    return $wb_done
}

# 2.2 GKI 进程级无损冷匿名页回收（同时覆盖 ColorOS 与 小米澎湃OS 系统核心底座，仅回收 adj > 200 进程，100% 保留后台页面与前台服务状态）
ram_force_reclaim() {
    local reclaimed_cnt=0 pid_dir pid adj uid _k _u _rest
    for pid_dir in /proc/[0-9]*; do
        pid=${pid_dir#/proc/}
        [ -r "$pid_dir/oom_score_adj" ] || continue
        adj=""
        read -r adj < "$pid_dir/oom_score_adj" 2>/dev/null || continue
        [ -n "$adj" ] && [ "$adj" -gt 200 ] 2>/dev/null || continue
        uid=""
        while read -r _k _u _rest; do
            [ "$_k" = "Uid:" ] && { uid="$_u"; break; }
        done < "$pid_dir/status" 2>/dev/null
        [ "${uid:-0}" -ge 10000 ] || continue
        if [ -w "$pid_dir/reclaim" ]; then
            echo "anon" > "$pid_dir/reclaim" 2>/dev/null && reclaimed_cnt=$((reclaimed_cnt + 1))
        fi
    done

    # 双系统核心底座温和冷匿名页回收 (同时涵盖澎湃OS与ColorOS核心进程，pidof自动跳过非本机进程)
    for core_proc in system_server com.android.systemui com.miui.home miui.systemui.plugin com.miui.securitycenter com.miui.securitycenter.remote com.miui.powerkeeper com.xiaomi.xmsf com.xiaomi.xmsf:services com.xiaomi.finddevice com.xiaomi.aicr com.xiaomi.aicr:cognitionService com.miui.miwallpaper com.xiaomi.phone com.android.launcher com.oplus.launcher com.oplus.athena com.oplus.subsys com.android.phone com.oplus.obrain com.oplus.persist.multimedia com.oplus.midas zygote zygote_secondary zygote64; do
        for cpid in $(pidof "$core_proc" 2>/dev/null); do
            if [ -w "/proc/$cpid/reclaim" ]; then
                echo "anon" > "/proc/$cpid/reclaim" 2>/dev/null && reclaimed_cnt=$((reclaimed_cnt + 1))
            fi
        done
    done
    echo "  ✓ 已无损将 ${reclaimed_cnt} 个后台与双系统核心进程的冷匿名页压入 ZRAM (后台页面完整保留)"
}

ram_compact_run() {
    local mode_tag="${1:-normal}"
    if ! mkdir "$LOCK_DIR" 2>/dev/null; then
        echo "  ! 已有内存压缩任务正在执行，跳过重复调用"
        return 0
    fi
    trap 'rmdir "$LOCK_DIR" 2>/dev/null' EXIT INT TERM

    echo ">>> [引擎② 无损压缩/回写] 正在执行 ZRAM 闲置回写与冷匿名页换出..."
    ram_zram_writeback "$mode_tag"
    [ "$mode_tag" != "screenoff" ] && ram_force_reclaim
    if [ -w /proc/sys/vm/compact_memory ]; then
        echo 1 > /proc/sys/vm/compact_memory 2>/dev/null
    fi

    rmdir "$LOCK_DIR" 2>/dev/null
    trap - EXIT INT TERM
}

case "$MODE" in
    clear|broom|1)
        ram_broom_clear
        ;;
    screenoff)
        ram_compact_run "screenoff"
        ;;
    compact|reclaim|2)
        ram_compact_run "normal"
        ;;
    both|all|*)
        ram_broom_clear
        ram_compact_run "normal"
        ;;
esac
