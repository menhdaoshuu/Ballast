#!/system/bin/sh
# Ballast v6.7.5 零Fork低耗通知栏实时内存条 + 划掉一键执行压缩 (纯内置 read 解析，零 LSPosed)
MODDIR="${0%/*}"
[ "$MODDIR" = "$0" ] && MODDIR="/data/adb/modules/ksu_sys_mem_opt"
CONF="/data/adb/ksu_mem_opt.conf"
PID_FILE="/data/adb/ballast_ram_notify.pid"
TAG="ballast_ram"
POST_MODE=""

if [ "$1" = "daemon" ]; then
    if [ -f "$PID_FILE" ]; then
        _old=$(cat "$PID_FILE" 2>/dev/null)
        [ -n "$_old" ] && [ "$_old" != "$$" ] && kill "$_old" 2>/dev/null
    fi
    echo "$$" > "$PID_FILE" 2>/dev/null
fi

# 纯 Shell 内置 read 解析 /proc/meminfo，零 awk/cut 子进程开销
read_mem_fast() {
    MEM_TOTAL_KB=0
    MEM_AVAIL_KB=0
    SWAP_TOTAL_KB=0
    SWAP_FREE_KB=0
    while read -r _k _v _; do
        case "$_k" in
            MemTotal:)     MEM_TOTAL_KB="$_v" ;;
            MemAvailable:) MEM_AVAIL_KB="$_v" ;;
            SwapTotal:)    SWAP_TOTAL_KB="$_v" ;;
            SwapFree:)     SWAP_FREE_KB="$_v"; break ;;
        esac
    done < /proc/meminfo 2>/dev/null
    [ "$MEM_TOTAL_KB" -le 0 ] 2>/dev/null && return 1
    AVAIL_MB=$((MEM_AVAIL_KB / 1024))
    USED_PCT=$(( ((MEM_TOTAL_KB - MEM_AVAIL_KB) * 100) / MEM_TOTAL_KB ))
    [ "$USED_PCT" -lt 0 ] && USED_PCT=0
    [ "$USED_PCT" -gt 100 ] && USED_PCT=100
    _su=$((SWAP_TOTAL_KB - SWAP_FREE_KB))
    [ "$_su" -lt 0 ] && _su=0
    SWAP_MB=$((_su / 1024))
    if [ "$SWAP_TOTAL_KB" -gt 0 ]; then
        SWAP_PCT=$(( (_su * 100) / SWAP_TOTAL_KB ))
    else
        SWAP_PCT=0
    fi
    # 整数定点格式化为 X.XX GB (零外部工具)
    _a100=$(( (MEM_AVAIL_KB * 100) / 1048576 ))
    _t100=$(( (MEM_TOTAL_KB * 100) / 1048576 ))
    _su100=$(( (_su * 100) / 1048576 ))
    _st10=$(( (SWAP_TOTAL_KB * 10) / 1048576 ))
    _af=$((_a100 % 100)); [ "$_af" -lt 10 ] && _af="0$_af"
    _tf=$((_t100 % 100)); [ "$_tf" -lt 10 ] && _tf="0$_tf"
    _suf=$((_su100 % 100)); [ "$_suf" -lt 10 ] && _suf="0$_suf"
    AVAIL_GB="$((_a100 / 100)).${_af}"
    TOTAL_GB="$((_t100 / 100)).${_tf}"
    SWAP_USED_GB="$((_su100 / 100)).${_suf}"
    SWAP_TOT_GB="$((_st10 / 10)).$((_st10 % 10))"
    return 0
}

now_sec() {
    read -r _up _ < /proc/uptime 2>/dev/null
    echo "${_up%%.*}"
}

is_screen_on() {
    for _bl in /sys/class/backlight/*/brightness /sys/class/leds/lcd-backlight/brightness; do
        if [ -r "$_bl" ]; then
            read -r _bv < "$_bl" 2>/dev/null
            case "$_bv" in
                *[!0-9]*|"") ;;
                *)
                    [ "$_bv" -gt 0 ] && return 0
                    return 1
                    ;;
            esac
        fi
    done
    dumpsys power 2>/dev/null | grep -q 'mWakefulness=Awake'
}

post_notify() {
    _title="$1"
    _body="$2"
    # 首次自动探测并缓存可用的 UID 2000 发送通道，后续直接命中零多余尝试
    case "$POST_MODE" in
        su2000) su 2000 -c "cmd notification post -t '$_title' '$TAG' '$_body'" >/dev/null 2>&1 && return 0 ;;
        suu2000) su -u 2000 -c "cmd notification post -t '$_title' '$TAG' '$_body'" >/dev/null 2>&1 && return 0 ;;
        sushell) su shell -c "cmd notification post -t '$_title' '$TAG' '$_body'" >/dev/null 2>&1 && return 0 ;;
        sulp) su -lp 2000 -c "cmd notification post -t '$_title' '$TAG' '$_body'" >/dev/null 2>&1 && return 0 ;;
        direct) cmd notification post -t "$_title" "$TAG" "$_body" >/dev/null 2>&1 && return 0 ;;
    esac
    if su 2000 -c "cmd notification post -t '$_title' '$TAG' '$_body'" >/dev/null 2>&1; then
        POST_MODE="su2000"; return 0
    elif su -u 2000 -c "cmd notification post -t '$_title' '$TAG' '$_body'" >/dev/null 2>&1; then
        POST_MODE="suu2000"; return 0
    elif su shell -c "cmd notification post -t '$_title' '$TAG' '$_body'" >/dev/null 2>&1; then
        POST_MODE="sushell"; return 0
    elif su -lp 2000 -c "cmd notification post -t '$_title' '$TAG' '$_body'" >/dev/null 2>&1; then
        POST_MODE="sulp"; return 0
    else
        POST_MODE="direct"
        cmd notification post -t "$_title" "$TAG" "$_body" >/dev/null 2>&1
    fi
}

is_notify_alive() {
    if cmd notification list 2>/dev/null | grep -q "|${TAG}|"; then
        return 0
    elif su 2000 -c "cmd notification list" 2>/dev/null | grep -q "|${TAG}|"; then
        return 0
    elif su shell -c "cmd notification list" 2>/dev/null | grep -q "|${TAG}|"; then
        return 0
    fi
    return 1
}

post_once() {
    _extra="$1"
    read_mem_fast || return 1
    _title="压舱石 · ${AVAIL_GB} GB 可用 | ${TOTAL_GB} GB"
    if [ -n "$_extra" ]; then
        _body="${_extra} · 物理 ${USED_PCT}% · ZRAM ${SWAP_PCT}%"
    elif [ "${SWIPE_ACTION_READY:-0}" = "1" ] && [ "${ENABLE_RAM_NOTIFY_ACTION:-1}" = "1" ]; then
        _body="物理占用 ${USED_PCT}% · ZRAM ${SWAP_PCT}% (${SWAP_USED_GB}/${SWAP_TOT_GB} GB) · 划掉=一键压缩"
    else
        _dstat="守护待机"
        pgrep -f "ballast_daemon" >/dev/null 2>&1 && _dstat="纯C守护运行中"
        _body="物理占用 ${USED_PCT}% · ZRAM ${SWAP_PCT}% (${SWAP_USED_GB}/${SWAP_TOT_GB} GB) · ${_dstat}"
    fi
    post_notify "$_title" "$_body"
    LAST_AVAIL_MB="$AVAIL_MB"
    LAST_SWAP_MB="$SWAP_MB"
    LAST_POST_TS=$(now_sec)
}

run_swipe_action() {
    read_mem_fast
    _before_mb="${AVAIL_MB:-0}"
    _before_pct="${USED_PCT:-0}"
    post_notify "压舱石 · 正在一键压缩内存..." "当前物理占用 ${_before_pct}% · 正在执行无损冷页压实"
    if [ -f "$MODDIR/action.sh" ]; then
        sh "$MODDIR/action.sh" >/dev/null 2>&1
    elif [ -f "$MODDIR/ram_compact.sh" ]; then
        sh "$MODDIR/ram_compact.sh" both 2 >/dev/null 2>&1
    fi
    read_mem_fast
    _delta=$((AVAIL_MB - _before_mb))
    if [ "$_delta" -gt 0 ]; then
        post_once "刚已压缩 (+${_delta} MB)"
    else
        post_once "刚已执行压缩"
    fi
    LAST_ACTION_TS=$(now_sec)
}

set_conf_kv() {
    _ck="$1"
    _cv="$2"
    mkdir -p /data/adb 2>/dev/null
    [ -f "$CONF" ] || touch "$CONF" 2>/dev/null
    if [ -f "$CONF" ]; then
        if grep -q "^${_ck}=" "$CONF"; then
            sed -i "s/^${_ck}=.*/${_ck}=${_cv}/" "$CONF" 2>/dev/null
        else
            echo "${_ck}=${_cv}" >> "$CONF" 2>/dev/null
        fi
    fi
}

case "$1" in
    once)
        post_once
        exit $?
        ;;
    action)
        if [ "$2" = "off" ]; then
            set_conf_kv "ENABLE_RAM_NOTIFY_ACTION" "0"
            echo "已关闭通知栏「划掉=一键压缩」功能"
        else
            set_conf_kv "ENABLE_RAM_NOTIFY_ACTION" "1"
            echo "已开启通知栏「划掉=一键压缩」功能"
        fi
        exit 0
        ;;
    off|stop)
        set_conf_kv "ENABLE_RAM_NOTIFY" "0"
        [ -f "$PID_FILE" ] && kill "$(cat "$PID_FILE" 2>/dev/null)" 2>/dev/null
        rm -f "$PID_FILE" 2>/dev/null
        pkill -f "ram_notify_daemon.sh daemon" >/dev/null 2>&1
        echo "已关闭压舱石通知栏实时内存条"
        exit 0
        ;;
    on|start)
        set_conf_kv "ENABLE_RAM_NOTIFY" "1"
        nohup sh "$0" daemon </dev/null >/dev/null 2>&1 &
        echo "已开启压舱石通知栏实时内存条"
        exit 0
        ;;
    status)
        if pgrep -f "ram_notify_daemon.sh daemon" >/dev/null 2>&1; then
            echo "运行中 ($(pgrep -af 'ram_notify_daemon.sh daemon' | head -n 1))"
        else
            echo "未运行"
        fi
        exit 0
        ;;
    daemon)
        ;;
    *)
        post_once
        exit $?
        ;;
esac

_w=0
while [ $_w -lt 20 ]; do
    [ "$(getprop sys.boot_completed 2>/dev/null)" = "1" ] && break
    sleep 2
    _w=$((_w + 1))
done

LAST_AVAIL_MB=-9999
LAST_SWAP_MB=-9999
LAST_POST_TS=0
LAST_ACTION_TS=0
SWIPE_ACTION_READY=0
ENABLE_RAM_NOTIFY=1
ENABLE_RAM_NOTIFY_ACTION=1
[ -f "$CONF" ] && . "$CONF" 2>/dev/null
if [ "${ENABLE_RAM_NOTIFY:-1}" != "1" ]; then
    rm -f "$PID_FILE" 2>/dev/null
    exit 0
fi

post_once
sleep 1
if is_notify_alive; then
    SWIPE_ACTION_READY=1
    post_once
fi

while true; do
    ENABLE_RAM_NOTIFY=1
    ENABLE_RAM_NOTIFY_ACTION=1
    [ -f "$CONF" ] && . "$CONF" 2>/dev/null
    if [ "${ENABLE_RAM_NOTIFY:-1}" != "1" ]; then
        rm -f "$PID_FILE" 2>/dev/null
        exit 0
    fi

    if ! is_screen_on; then
        sleep 15
        continue
    fi

    sleep 8
    _now=$(now_sec)

    if [ "$SWIPE_ACTION_READY" = "1" ] && [ "${ENABLE_RAM_NOTIFY_ACTION:-1}" = "1" ]; then
        if ! is_notify_alive; then
            _act_dt=$((_now - LAST_ACTION_TS))
            if [ "$_act_dt" -ge 30 ]; then
                run_swipe_action
                continue
            else
                post_once
                continue
            fi
        fi
    fi

    read_mem_fast || continue
    _da=$((AVAIL_MB - LAST_AVAIL_MB))
    [ "$_da" -lt 0 ] && _da=$((-_da))
    _ds=$((SWAP_MB - LAST_SWAP_MB))
    [ "$_ds" -lt 0 ] && _ds=$((-_ds))
    _dt=$((_now - LAST_POST_TS))

    if [ "$_da" -ge 128 ] || [ "$_ds" -ge 128 ] || { [ "$_dt" -ge 32 ] && [ "$_da" -ge 64 ]; }; then
        post_once
    fi
done
