#!/system/bin/sh
MODDIR=${0%/*}
LOG_FILE="/data/adb/ksu_mem_opt.log"
CONF="/data/adb/ksu_mem_opt.conf"
PIN_FILE="/data/adb/ksu_mem_opt.alg_pinned"
PRIO_FALLBACK_FILE="/data/adb/ksu_mem_opt.prio_fallback"
APPLIED_HASH_FILE="/data/adb/ksu_mem_opt.applied_hash"
LAST_CONF_SIG=""
[ -r "$APPLIED_HASH_FILE" ] && read -r LAST_CONF_SIG < "$APPLIED_HASH_FILE" 2>/dev/null

# 日志超过 200KB 时截断，否则追加
if [ -f "$LOG_FILE" ] && [ "$(wc -c < "$LOG_FILE")" -gt 204800 ]; then
    : > "$LOG_FILE"
fi

log_info() { echo "[$(date '+%m-%d %H:%M:%S')] [INFO] $1" >> "$LOG_FILE"; }
log_warn() { echo "[$(date '+%m-%d %H:%M:%S')] [WARN] $1" >> "$LOG_FILE"; }

# 默认配置，可被 $CONF 覆盖
ROM_TYPE=""
ENABLE_ZRAM=1
ZRAM_PERCENT=75
ZRAM_MEM_LIMIT_PERCENT=45
ENABLE_VM=1
SWAPPINESS=150
BG_DENY_PKGS=""
DISABLE_PKGS=""
RESTRICT_PKGS=""
RECLAIM_PKGS=""
[ -f "$CONF" ] && . "$CONF"

# 若配置未记录 ROM_TYPE，动态探测当前系统 (HyperOS/MIUI vs ColorOS/Oplus)
if [ -z "$ROM_TYPE" ]; then
    if [ -n "$(getprop ro.mi.os.version.name)" ] || [ -n "$(getprop ro.miui.ui.version.name)" ] || [ -d /system_ext/app/miuisystem ]; then
        ROM_TYPE="hyperos"
    elif [ -n "$(getprop ro.build.version.oplusrom)" ] || [ -n "$(getprop ro.oplus.version.base)" ]; then
        ROM_TYPE="coloros"
    else
        ROM_TYPE="generic"
    fi
fi
CUR_CONF_SIG="${ROM_TYPE}|${ZRAM_PERCENT}|${SWAPPINESS}|${BG_DENY_PKGS}|${DISABLE_PKGS}|${RESTRICT_PKGS}"

# 仅接受数字，防止配置错误
case "$ZRAM_PERCENT" in ''|*[!0-9]*) ZRAM_PERCENT=30 ;; esac
case "$ZRAM_MEM_LIMIT_PERCENT" in ''|*[!0-9]*) ZRAM_MEM_LIMIT_PERCENT=20 ;; esac
case "$SWAPPINESS" in ''|*[!0-9]*) SWAPPINESS=150 ;; esac
[ "$ZRAM_PERCENT" -lt 10 ] && ZRAM_PERCENT=10
[ "$ZRAM_PERCENT" -gt 80 ] && ZRAM_PERCENT=80

# 安全写入：检查节点存在与写入结果
write_val() {
    local node="$1" value="$2"
    if [ ! -e "$node" ]; then
        log_warn "跳过不存在的节点: $node"
        return 1
    fi
    if echo "$value" > "$node" 2>/dev/null; then
        log_info "写入成功: $node = $value"
        return 0
    fi
    log_warn "写入失败: $node (目标值: $value)"
    return 1
}

# 等待系统完全启动，避开厂商 post-boot 脚本
until [ "$(getprop sys.boot_completed)" = "1" ]; do
    sleep 2
done
sleep 15

# 兼容等待 ColorOS (init.oplus.nandswap.sh) 与 HyperOS/高通 (qcom-post-boot / kernel-post-boot) 的 zram 初始化结束
wait_vendor_zram() {
    local i=0 svc waited=0
    for svc in init.oplus.nandswap.sh qcom-post-boot kernel-post-boot; do
        [ -z "$(getprop init.svc.$svc)" ] && continue
        i=0
        while [ $i -lt 45 ]; do
            if [ "$(getprop init.svc.$svc)" = "stopped" ]; then
                break
            fi
            sleep 2
            i=$((i + 1))
            waited=$((waited + 2))
        done
    done
    sleep 4
    log_info "已等待厂商 post-boot / zram 脚本完成 (识别系统: $ROM_TYPE, 额外等待 ${waited}s)"
}
wait_vendor_zram
log_info "=== 系统启动完成，开始调优 (Universal 16G Edition - ROM: $ROM_TYPE) ==="

# 格式化并启用 swap，记录每一步的真实报错；带优先级失败则回退为默认优先级并记录标记供 check.sh 区分
activate_swap() {
    local dev="$1" bytes="$2" alg="$3" out
    local MKSWAP=mkswap SWAPON=swapon
    rm -f "$PRIO_FALLBACK_FILE"
    [ -x /system/bin/mkswap ] && MKSWAP=/system/bin/mkswap
    [ -x /system/bin/swapon ] && SWAPON=/system/bin/swapon
    out=$($MKSWAP "$dev" 2>&1) || { log_warn "mkswap 失败: $out"; return 1; }
    out=$($SWAPON -p 32758 "$dev" 2>&1)
    if [ $? -ne 0 ]; then
        log_warn "swapon -p 失败: $(echo "$out" | head -n 1) ，回退为默认优先级重试"
        out=$($SWAPON "$dev" 2>&1)
        if [ $? -ne 0 ]; then
            log_warn "swapon 失败: $out"
            return 1
        fi
        touch "$PRIO_FALLBACK_FILE" 2>/dev/null
    fi
    log_info "当前 comp_algorithm: $(cat /sys/block/zram0/comp_algorithm 2>/dev/null) | swaps: $(grep zram0 /proc/swaps | tr -s ' ')"
    log_info "ZRAM 已启用: $([ -n "$bytes" ] && echo "$((bytes / 1024 / 1024)) MB, 算法: $(alg_now)")"
    return 0
}

alg_now() { sed -n 's/.*\[\(.*\)\].*/\1/p' /sys/block/zram0/comp_algorithm 2>/dev/null; }

setup_zram() {
    local zram_sys="/sys/block/zram0"
    rm -f "$PIN_FILE"
    local zram_dev="/dev/block/zram0"

    if [ ! -d "$zram_sys" ] || [ ! -b "$zram_dev" ]; then
        log_warn "设备不支持 zram0，跳过 ZRAM 配置。"
        return
    fi

    local mem_total_kb mem_avail_kb target_bytes
    mem_total_kb=$(awk '/MemTotal/ {print $2}' /proc/meminfo)
    mem_avail_kb=$(awk '/MemAvailable/ {print $2}' /proc/meminfo)
    target_bytes=$(( mem_total_kb * ZRAM_PERCENT / 100 * 1024 ))

    local swap_used_kb
    swap_used_kb=$(awk '/SwapTotal/ {t=$2} /SwapFree/ {f=$2} END {print t-f}' /proc/meminfo)
    # 16G 大内存适配：只要当前 Swap 占用低于 3GB 且可用物理内存富余 1.5GB 以上，即可安全卸载重置
    if [ "${swap_used_kb:-0}" -gt 3145728 ] || [ "${mem_avail_kb:-0}" -lt $(( ${swap_used_kb:-0} + 1572864 )) ]; then
        log_warn "Swap 已使用 ${swap_used_kb} kB (可用物理内存 ${mem_avail_kb} kB)，跳过 ZRAM 重置。"
        return
    fi

    local avail_algs chosen_alg=""
    avail_algs=$(cat "$zram_sys/comp_algorithm" 2>/dev/null)
    if echo "$avail_algs" | grep -qw "zstd"; then
        chosen_alg="zstd"
    elif echo "$avail_algs" | grep -qw "lz4"; then
        chosen_alg="lz4"
    fi
    log_info "可用算法: $avail_algs | 选定: ${chosen_alg:-保持默认}"

    if grep -q "zram0" /proc/swaps; then
        if ! swapoff "$zram_dev" 2>/dev/null; then
            log_warn "卸载 zram0 失败，终止重配置。"
            return
        fi
    fi

    write_val "$zram_sys/reset" "1"
    [ -n "$chosen_alg" ] && write_val "$zram_sys/comp_algorithm" "$chosen_alg"

    if write_val "$zram_sys/disksize" "$target_bytes"; then
        if [ -n "$chosen_alg" ] && [ "$(alg_now)" != "$chosen_alg" ]; then
            write_val "$zram_sys/comp_algorithm" "$chosen_alg"
            if [ "$(alg_now)" != "$chosen_alg" ]; then
                chosen_alg=$(alg_now)
                echo "$chosen_alg" > "$PIN_FILE"
                log_warn "内核在初始化时固定了压缩算法为 $chosen_alg，无法改为 zstd。"
            fi
        fi
        if [ "$ZRAM_MEM_LIMIT_PERCENT" -gt 0 ] && [ -e "$zram_sys/mem_limit" ]; then
            write_val "$zram_sys/mem_limit" "$(( mem_total_kb * ZRAM_MEM_LIMIT_PERCENT / 100 * 1024 ))"
        fi
        activate_swap "$zram_dev" "$target_bytes" "$chosen_alg"
    else
        log_warn "设置 disksize 失败，尝试恢复 swap。"
        activate_swap "$zram_dev" "" ""
    fi
}

setup_vm() {
    local vm="/proc/sys/vm"
    [ "$SWAPPINESS" -gt 100 ] && [ ! -e /sys/kernel/mm/lru_gen/enabled ] && SWAPPINESS=100
    write_val "$vm/swappiness" "$SWAPPINESS" || write_val "$vm/swappiness" "100"
    write_val "$vm/page-cluster" "0"
    # v5.3 黄金平衡参数：
    # 1) swappiness=130 (MGLRU) + vfs_cache_pressure=100：引导内核积极将冷匿名页压入 ZRAM，同时保留热可执行代码页 (.so/.oat/.dex) 不掉帧；
    # 2) watermark_scale_factor=10 + watermark_boost_factor=0：消除内核 si_mem_available 高水位预留扣减，使 MemAvailable 真实多释放 400~600MB；
    # 3) MGLRU min_ttl_ms=1500：提供 1.5s 年轻代热页防抖保护，既杜绝切应用卡顿，又不阻塞 MemAvailable 统计。
    write_val "$vm/vfs_cache_pressure" "130"
    write_val "$vm/dirty_ratio" "15"
    write_val "$vm/dirty_background_ratio" "5"
    write_val "$vm/watermark_scale_factor" "10"
    [ -e "$vm/watermark_boost_factor" ] && write_val "$vm/watermark_boost_factor" "0"
    [ -e "$vm/compact_unevictable_allowed" ] && write_val "$vm/compact_unevictable_allowed" "0"
    # ColorOS 17 原生 memcg 自动换出水位联调 (默认 2500/2200/2500/1536 -> 900/700/900/768)
    [ -w /sys/fs/cgroup/memory.avail_buffers ] && write_val "/sys/fs/cgroup/memory.avail_buffers" "900 700 900 768"
    [ -w /sys/fs/cgroup/memory.compress_ratio ] && write_val "/sys/fs/cgroup/memory.compress_ratio" "60"

    if [ -e /sys/kernel/mm/lru_gen/enabled ]; then
        write_val "/sys/kernel/mm/lru_gen/enabled" "7"
        write_val "/sys/kernel/mm/lru_gen/min_ttl_ms" "500"
    fi

    # 关闭厂商无意义后台幽灵预加载 (不杀用户已打开的真实后台！)，省下 1~1.5GB 物理内存
    setprop persist.sys.oplus.preload.enable 0 2>/dev/null
    setprop sys.oplus.preload.enable 0 2>/dev/null
    setprop persist.vendor.oplus.preload 0 2>/dev/null
    setprop persist.sys.prestart.proc false 2>/dev/null
    setprop persist.sys.miui_preload_enable 0 2>/dev/null

    local lmk="/sys/module/lowmemorykiller/parameters"
    [ -d "$lmk" ] && write_val "$lmk/minfree" "18432,23040,27648,32256,55296,80640"

    if command -v cmd >/dev/null 2>&1; then
        # v5.3 满血 16G 多任务保活池：扩容至 48 个缓存进程 + 32 个子进程，彻底根治 v5.2 (设为4) 切应用被杀重载的问题！
        cmd device_config put activity_manager max_cached_processes 16 >/dev/null 2>&1
        cmd device_config put activity_manager max_phantom_processes 16 >/dev/null 2>&1
        cmd device_config put activity_manager_native_boot max_cached_processes 16 >/dev/null 2>&1
        settings put global activity_manager_constants max_cached_processes=16,max_empty_time_millis=600000 >/dev/null 2>&1
        # 架构解耦：将 Android 原生 CachedAppOptimizer 退居为深层缓存兜底 (cutoff_adj=900, debounce=600000ms)，
        # 由自研 Pure-C 守护进程执行 12s 温和墓碑 + 80% 冷匿名页压缩
        cmd device_config put activity_manager_native_boot use_freezer true >/dev/null 2>&1
        cmd device_config put activity_manager_native_boot freeze_debounce_timeout 600000 >/dev/null 2>&1
        cmd device_config put activity_manager_native_boot freezer_cutoff_adj 900 >/dev/null 2>&1
        log_info "已调优 max_cached_processes=16 实现高可用内存与多任务平衡，并关闭厂商幽灵预加载"
        cmd device_config put runtime_native usap_pool_enabled false >/dev/null 2>&1
        cmd device_config put runtime_native usap_pool_size_max 1 >/dev/null 2>&1
        cmd device_config put runtime_native usap_pool_size_min 0 >/dev/null 2>&1
    fi
    setprop persist.device_config.runtime_native.usap_pool_enabled false 2>/dev/null
}

get_pids() {
    local target="$1"
    { pidof "$target" 2>/dev/null | tr ' ' '\n'; pgrep -f "^${target}($|:)" 2>/dev/null; } | sort -u
}

# 一次性缓存已安装与已禁用包列表，将开机 100+ 次 pm Binder 调用压缩为 2 次
ALL_PKGS_CACHE=""
DISABLED_PKGS_CACHE=""
# 优先直接解析 /data/system/packages.list 与 package-restrictions.xml，消除开机 pm Binder 调用
refresh_pkg_cache() {
    if [ -r /data/system/packages.list ]; then
        ALL_PKGS_CACHE=$(awk '{print "package:"$1}' /data/system/packages.list 2>/dev/null)
    else
        ALL_PKGS_CACHE="$(pm list packages -u 2>/dev/null)"
    fi
    if [ -r /data/system/users/0/package-restrictions.xml ] && grep -q '<pkg ' /data/system/users/0/package-restrictions.xml 2>/dev/null; then
        DISABLED_PKGS_CACHE=$( sed -n 's/.*<pkg name="\([^"]*\)".*enabled="[234]".*/package:\1/p' /data/system/users/0/package-restrictions.xml 2>/dev/null )
    else
        DISABLED_PKGS_CACHE="$(pm list packages -d 2>/dev/null)"
    fi
}
pkg_is_installed() {
    case "$ALL_PKGS_CACHE" in *"package:$1"*) return 0 ;; esac
    return 1
}
pkg_is_disabled() {
    case "$DISABLED_PKGS_CACHE" in *"package:$1"*) return 0 ;; esac
    return 1
}

stop_unnecessary_daemons() {
    local svc stopped_list=""
    setprop persist.traced.enable 0 2>/dev/null
    setprop persist.sys.misight.enable 0 2>/dev/null
    setprop debug.atrace.tags.enableflags 0 2>/dev/null
    # 同时覆盖小米澎湃OS与 ColorOS / MTK / 高通的非必要日志与遥测守护进程（仅对处于 running 状态的进程生效，绝不触碰 millet_*）
    for svc in misight vendor.mi_misight charge_logger nativehang-dumpstate traced traced_probes traced_perf incidentd dumpstate_nwatchcall qseelogd logcatkernel logcatlog bootlog minidump64 connsyslogger mobile_log_d netdiag bsp_kevent emdlogger wifi_dump bt_dump gps_dump lbs_dbg_ext mtk-mbrain midasd ostats_pullerd ostats_tpd oplus.hardware.olc-2-0 criticallog; do
        if [ "$(getprop "init.svc.$svc")" = "running" ]; then
            stop "$svc" >/dev/null 2>&1
            stopped_list="$stopped_list $svc"
        fi
    done
    [ -n "$stopped_list" ] && log_info "已停止非必要原生日志/遥测守护进程:$stopped_list"
}

# 检查目标应用是否正处于前台或拥有可见/前台服务 (adj <= 200)
is_pkg_foreground_now() {
    local pkg="$1" pid adj
    for pid in $(get_pids "$pkg"); do
        [ -r "/proc/$pid/oom_score_adj" ] || continue
        read -r adj < "/proc/$pid/oom_score_adj" 2>/dev/null
        case "$adj" in ''|*[!0-9-]*) continue ;; esac
        [ "$adj" -le 100 ] && return 0
    done
    return 1
}

deny_background() {
    # v5.0 开机幂等快路径：若配置文件签名未变化（上次开机已持久化写入 /data/system/appops.xml），直接跳过 30+ 次 pm/appops Binder 调用，仅对运行中后台目标执行清理
    if [ -n "$LAST_CONF_SIG" ] && [ "$CUR_CONF_SIG" = "$LAST_CONF_SIG" ]; then
        local _p
        for _p in $BG_DENY_PKGS; do
            [ "$_p" = "com.tencent.mm" ] || [ "$_p" = "com.fcpower" ] && continue
            pkg_is_installed "$_p" || continue
            if ! is_pkg_foreground_now "$_p"; then
                am force-stop "$_p" >/dev/null 2>&1
                pkill -9 -f "^${_p}($|:)" >/dev/null 2>&1
            fi
        done
        log_info "配置未变动，开机幂等跳过重复 pm/appops Binder 调用 (已清理 BG_DENY 后台进程)"
        return 0
    fi
    if pkg_is_installed "com.tencent.mm"; then
        pm enable "com.tencent.mm/com.tencent.mm.booter.CoreService" >/dev/null 2>&1
        pm enable 'com.tencent.mm/com.tencent.mm.booter.NotifyReceiver$NotifyService' >/dev/null 2>&1
        if [ "$ROM_TYPE" != "coloros" ]; then
            pm enable "com.tencent.mm/com.xiaomi.mipush.sdk.PushMessageHandler" >/dev/null 2>&1
            pm enable "com.tencent.mm/com.xiaomi.mipush.sdk.MessageHandleService" >/dev/null 2>&1
        fi
        if [ "$ROM_TYPE" != "hyperos" ]; then
            pm enable "com.tencent.mm/com.heytap.msp.push.service.DataMessageCallbackService" >/dev/null 2>&1
            pm enable "com.tencent.mm/com.heytap.msp.push.service.CompatibleDataMessageCallbackService" >/dev/null 2>&1
        fi
        cmd appops set com.tencent.mm RUN_IN_BACKGROUND allow >/dev/null 2>&1
        cmd appops set com.tencent.mm RUN_ANY_IN_BACKGROUND allow >/dev/null 2>&1
        cmd appops set com.tencent.mm START_FOREGROUND allow >/dev/null 2>&1
        cmd appops set com.tencent.mm BOOT_COMPLETED allow >/dev/null 2>&1
        cmd appops set com.tencent.mm WAKE_LOCK allow >/dev/null 2>&1
        [ "$ROM_TYPE" = "hyperos" ] && cmd appops set com.tencent.mm 10008 allow >/dev/null 2>&1
        am set-standby-bucket com.tencent.mm active >/dev/null 2>&1
        dumpsys deviceidle whitelist +com.tencent.mm >/dev/null 2>&1
        if pkg_is_installed "com.xiaomi.xmsf"; then
            am set-standby-bucket com.xiaomi.xmsf active >/dev/null 2>&1
            dumpsys deviceidle whitelist +com.xiaomi.xmsf >/dev/null 2>&1
        fi
        log_info "已配置微信双系统推送通道常驻保活与消息秒收策略: com.tencent.mm"
    fi
    local pkg
    [ -z "$BG_DENY_PKGS" ] && return
    for pkg in $BG_DENY_PKGS; do
        [ "$pkg" = "com.tencent.mm" ] || [ "$pkg" = "com.fcpower" ] && continue
        if ! pkg_is_installed "$pkg"; then
            log_warn "应用未安装，跳过后台限制: $pkg"
            continue
        fi
        # 阻断厂商推送后台唤醒被压制应用 (MsfService 仅在 customize.sh 安装期恢复，不在开机重复 enable 以免唤醒后再杀)
        pm disable "$pkg/com.xiaomi.mipush.sdk.PushMessageHandler" >/dev/null 2>&1
        pm disable "$pkg/com.xiaomi.mipush.sdk.MessageHandleService" >/dev/null 2>&1
        pm disable "$pkg/com.heytap.msp.push.service.DataMessageCallbackService" >/dev/null 2>&1
        pm disable "$pkg/com.heytap.msp.push.service.CompatibleDataMessageCallbackService" >/dev/null 2>&1
        cmd appops set "$pkg" RUN_IN_BACKGROUND deny >/dev/null 2>&1
        cmd appops set "$pkg" RUN_ANY_IN_BACKGROUND deny >/dev/null 2>&1
        cmd appops set "$pkg" START_FOREGROUND deny >/dev/null 2>&1
        cmd appops set "$pkg" BOOT_COMPLETED ignore >/dev/null 2>&1
        cmd appops set "$pkg" WAKE_LOCK ignore >/dev/null 2>&1
        [ "$ROM_TYPE" = "hyperos" ] && cmd appops set "$pkg" 10008 ignore >/dev/null 2>&1
        am set-standby-bucket "$pkg" restricted >/dev/null 2>&1
        if ! is_pkg_foreground_now "$pkg"; then
            am force-stop "$pkg" >/dev/null 2>&1
            pkill -9 -f "^${pkg}($|:)" >/dev/null 2>&1
        fi
        log_info "已配置前台正常使用、离开前台彻底压制策略: $pkg"
    done
}

disable_apps() {
    # 双系统核心服务防误禁保护
    for _core_guard in com.miui.home miui.systemui.plugin com.miui.securitycenter com.miui.powerkeeper com.lbe.security.miui com.xiaomi.finddevice com.xiaomi.xmsf com.miui.personalassistant com.mi.health com.oplus.launcher com.coloros.smartsidebar com.heytap.accessory com.heytap.mydevices com.heytap.health com.heytap.speechassist com.oplus.ovoicemanager com.android.externalstorage com.oplus.melody com.coloros.smartsidebar com.oplus.games; do
        pkg_is_installed "$_core_guard" && pm enable "$_core_guard" >/dev/null 2>&1
    done
    local pkg
    [ -z "$DISABLE_PKGS" ] && return
    for pkg in $DISABLE_PKGS; do
        case "$pkg" in
            com.miui.home|miui.systemui.plugin|com.miui.securitycenter|com.miui.powerkeeper|com.lbe.security.miui|com.xiaomi.finddevice|com.xiaomi.xmsf|com.miui.personalassistant|com.mi.health|com.oplus.launcher|com.coloros.smartsidebar|com.heytap.accessory|com.heytap.mydevices|com.heytap.health|com.heytap.speechassist|com.oplus.ovoicemanager)
                log_warn "触发双系统核心防呆保护，跳过禁用: $pkg"
                continue
                ;;
        esac
        if ! pkg_is_installed "$pkg"; then
            log_warn "应用不存在，跳过禁用: $pkg"
            continue
        fi
        if pkg_is_disabled "$pkg"; then
            log_info "已处于禁用状态: $pkg"
        elif pm disable-user --user 0 "$pkg" >/dev/null 2>&1; then
            log_info "已禁用应用: $pkg"
        else
            log_warn "禁用失败: $pkg"
        fi
    done
}

restrict_apps() {
    local pkg pid
    [ -z "$RESTRICT_PKGS" ] && return
    for pkg in $RESTRICT_PKGS; do
        pkg_is_installed "$pkg" || continue
        if [ "$CUR_CONF_SIG" != "$LAST_CONF_SIG" ]; then
            am set-standby-bucket "$pkg" restricted >/dev/null 2>&1
            cmd appops set "$pkg" WAKE_LOCK ignore >/dev/null 2>&1
        fi
        for pid in $(get_pids "$pkg"); do
            [ -n "$pid" ] && renice -n 19 -p "$pid" >/dev/null 2>&1
        done
        log_info "已轻度压制: $pkg (待机桶: restricted, WAKE_LOCK: ignore, nice: 19)"
    done
}


apply_sys_mem_cages() {
    [ "${ENABLE_SYS_CAGE:-1}" = "1" ] || return 0
    [ -r /data/system/packages.list ] || return 0
    local _pkg _uid _cnt=0
    for _pkg in com.google.android.gms com.android.vending com.miui.securitycenter com.xiaomi.aicr com.miui.personalassistant com.xiaomi.aiservice com.oplus.athena com.oplus.obrain com.oplus.aiunit com.oplus.appplatform com.tencent.mobileqq com.tencent.tim com.eg.android.AlipayGphone com.oplus.safecenter com.heytap.mydevices; do
        _uid=$(awk -v p="$_pkg" '$1==p {print $2; exit}' /data/system/packages.list 2>/dev/null)
        if [ -n "$_uid" ] && [ "$_uid" -ge 10000 ] 2>/dev/null; then
            for _cp in "/sys/fs/cgroup/uid_${_uid}/memory.high" "/sys/fs/cgroup/apps/uid_${_uid}/memory.high"; do
                if [ -w "$_cp" ]; then
                    echo 134217728 > "$_cp" 2>/dev/null && _cnt=$((_cnt + 1)) && break
                fi
            done
        fi
    done
    for _pkg in com.google.android.gsf com.miui.powerkeeper com.miui.cloudservice com.xiaomi.market com.xiaomi.joyose com.xiaomi.mi_connect_service com.oplus.exsystemservice com.heytap.mcs com.coloros.ocs.opencapabilityservice com.oplus.atlas com.oplus.subsys com.miui.gallery com.xiaomi.aiasst.service com.xiaomi.aiasst.vision com.milink.service com.xiaomi.mirror com.xiaomi.gamecenter com.miui.weather2 com.xiaomi.account com.miui.mishare.connectivity com.coloros.gallery3d com.finshell.wallet com.heytap.market com.heytap.cloud com.oplus.battery com.oplus.framework.network.drs com.mobiletools.systemhelper com.heytap.openid com.android.providers.media.module com.android.mms com.heytap.speechassist com.oplus.location android.ext.services com.android.providers.contacts com.oplus.ovoicemanager com.android.externalstorage com.oplus.melody; do
        _uid=$(awk -v p="$_pkg" '$1==p {print $2; exit}' /data/system/packages.list 2>/dev/null)
        if [ -n "$_uid" ] && [ "$_uid" -ge 10000 ] 2>/dev/null; then
            for _cp in "/sys/fs/cgroup/uid_${_uid}/memory.high" "/sys/fs/cgroup/apps/uid_${_uid}/memory.high"; do
                if [ -w "$_cp" ]; then
                    echo 100663296 > "$_cp" 2>/dev/null && _cnt=$((_cnt + 1)) && break
                fi
            done
        fi
    done
    # 安全防呆：绝不限制 uid_1000 整体 (保护 system_server 与 surfaceflinger)，仅对指定 uid=1000 胖服务做 Per-PID 软笼
    for _u1k in /sys/fs/cgroup/uid_1000/memory.high /sys/fs/cgroup/apps/uid_1000/memory.high; do
        [ -w "$_u1k" ] && echo max > "$_u1k" 2>/dev/null
    done
    local _sp _spid _pnode
    for _sp in com.oplus.subsys com.oplus.athena com.heytap.mcs com.oplus.exsystemservice com.oplus.persist.multimedia com.miui.securitycenter com.miui.powerkeeper; do
        for _spid in $(get_pids "$_sp"); do
            [ -n "$_spid" ] || continue
            for _pnode in "/sys/fs/cgroup/uid_1000/pid_${_spid}/memory.high" "/sys/fs/cgroup/apps/uid_1000/pid_${_spid}/memory.high"; do
                if [ -w "$_pnode" ]; then
                    echo 100663296 > "$_pnode" 2>/dev/null && _cnt=$((_cnt + 1)) && break
                fi
            done
        done
    done
    for _sp64 in com.oplus.midas com.oplus.sau com.oplus.notificationmanager com.oplus.appplatform com.oplus.mediaturbo com.oplus.powermonitor; do
        for _spid in $(get_pids "$_sp64"); do
            [ -n "$_spid" ] || continue
            for _pnode in "/sys/fs/cgroup/uid_1000/pid_${_spid}/memory.high" "/sys/fs/cgroup/apps/uid_1000/pid_${_spid}/memory.high"; do
                if [ -w "$_pnode" ]; then
                    echo 67108864 > "$_pnode" 2>/dev/null && _cnt=$((_cnt + 1)) && break
                fi
            done
        done
    done
    for _g64 in com.heytap.openid com.mobiletools.systemhelper com.oplus.framework.network.drs com.android.mms com.oplus.cosa com.coloros.ocs.opencapabilityservice com.oplus.melody; do
        _guid=$(awk -v p="$_g64" '$1==p {print $2; exit}' /data/system/packages.list 2>/dev/null)
        if [ -n "$_guid" ] && [ "$_guid" -ge 10000 ] 2>/dev/null && ! is_pkg_foreground_now "$_g64"; then
            for _cp in "/sys/fs/cgroup/uid_${_guid}/memory.high" "/sys/fs/cgroup/apps/uid_${_guid}/memory.high"; do
                if [ -w "$_cp" ]; then
                    echo 67108864 > "$_cp" 2>/dev/null && _cnt=$((_cnt + 1)) && break
                fi
            done
        fi
    done
    # v6.4.3: 撤掉健康多进程套件的 UID 级 memory.high（避免 4 进程抢额度触发 127% CPU 抖动），改由守护进程保 :transport 并清理闲置 :once/主界面进程
    for _gmax in com.heytap.health com.mi.health; do
        _guid=$(awk -v p="$_gmax" '$1==p {print $2; exit}' /data/system/packages.list 2>/dev/null)
        if [ -n "$_guid" ] && [ "$_guid" -ge 10000 ] 2>/dev/null; then
            for _cp in "/sys/fs/cgroup/uid_${_guid}/memory.high" "/sys/fs/cgroup/apps/uid_${_guid}/memory.high"; do
                [ -w "$_cp" ] && echo max > "$_cp" 2>/dev/null
            done
        fi
    done
    for _g160 in com.oplus.camera com.android.camera com.oplus.keyboard; do
        _guid=$(awk -v p="$_g160" '$1==p {print $2; exit}' /data/system/packages.list 2>/dev/null)
        if [ -n "$_guid" ] && [ "$_guid" -ge 10000 ] 2>/dev/null && ! is_pkg_foreground_now "$_g160"; then
            for _cp in "/sys/fs/cgroup/uid_${_guid}/memory.high" "/sys/fs/cgroup/apps/uid_${_guid}/memory.high"; do
                if [ -w "$_cp" ]; then
                    echo 167772160 > "$_cp" 2>/dev/null && _cnt=$((_cnt + 1)) && break
                fi
            done
        fi
    done
    # v6.7.5: 23 大国内外流媒体防膨胀软顶 (前台 1GB 防一路暴涨至 2.5~3GB，退后台 256MB 温和压冷页)
    for _stmp in com.ss.android.ugc.aweme com.ss.android.ugc.aweme.lite com.ss.android.ugc.aweme.mobile com.ss.android.ugc.live com.ss.android.yumme.video com.ss.android.ugc.trill com.phoenix.read com.smile.gifmaker com.kuaishou.nebula com.xingin.xhs com.ss.android.article.video tv.danmaku.bili com.bilibili.app.in com.tencent.qqlive com.qiyi.video com.iqiyi.i18n com.youku.phone com.hunantv.imgo.activity air.tv.douyu.android com.duowan.kiwi com.google.android.youtube com.zhiliaoapp.musically com.netflix.mediaclient; do
        _suid=$(awk -v p="$_stmp" '$1==p {print $2; exit}' /data/system/packages.list 2>/dev/null)
        if [ -n "$_suid" ] && [ "$_suid" -ge 10000 ] 2>/dev/null; then
            _slim="268435456"
            is_pkg_foreground_now "$_stmp" && _slim="1073741824"
            for _cp in "/sys/fs/cgroup/uid_${_suid}/memory.high" "/sys/fs/cgroup/apps/uid_${_suid}/memory.high"; do
                if [ -w "$_cp" ]; then
                    echo "$_slim" > "$_cp" 2>/dev/null && _cnt=$((_cnt + 1)) && break
                fi
            done
        fi
    done
    _wc_uid=$(awk '$1=="com.tencent.mm" {print $2; exit}' /data/system/packages.list 2>/dev/null)
    if [ -n "$_wc_uid" ] && ! is_pkg_foreground_now "com.tencent.mm"; then
        for _cp in "/sys/fs/cgroup/uid_${_wc_uid}/memory.high" "/sys/fs/cgroup/apps/uid_${_wc_uid}/memory.high"; do
            if [ -w "$_cp" ]; then
                echo 201326592 > "$_cp" 2>/dev/null && _cnt=$((_cnt + 1)) && break
            fi
        done
    fi
    for _scp in system_server com.android.systemui com.oplus.launcher com.miui.home com.android.launcher com.oplus.keyboard; do am send-trim-memory "$_scp" BACKGROUND >/dev/null 2>&1; done
    log_info "已对 $_cnt 个双系统胖服务/GMS/微信(192MB)/QQ与支付宝(128MB) 挂载 Cgroup v2 memory.high 软笼" 
}

reclaim_cold_pages() {
    # v5.3: 自动治愈修复 v5.2 曾对非毒瘤第三方应用一刀切施加的 RUN_IN_BACKGROUND/WAKE_LOCK 限制，仅压制 BG_DENY_PKGS 与 RESTRICT_PKGS
    if [ ! -f "/data/adb/ksu_mem_opt.v53_healed" ]; then
        local _tp_pkg
        for _tp_pkg in $(pm list packages -3 2>/dev/null | cut -d: -f2); do
            case " $BG_DENY_PKGS $RESTRICT_PKGS " in *" $_tp_pkg "*) continue ;; esac
            cmd appops set "$_tp_pkg" RUN_IN_BACKGROUND allow >/dev/null 2>&1
            cmd appops set "$_tp_pkg" RUN_ANY_IN_BACKGROUND allow >/dev/null 2>&1
            cmd appops set "$_tp_pkg" BOOT_COMPLETED default >/dev/null 2>&1
            cmd appops set "$_tp_pkg" WAKE_LOCK default >/dev/null 2>&1
            am set-standby-bucket "$_tp_pkg" active >/dev/null 2>&1
        done
        touch "/data/adb/ksu_mem_opt.v53_healed" 2>/dev/null
        log_info "v5.3 已解除 v5.2 对普通第三方应用的后台一刀切限制，恢复满血多任务留存"
    fi

    # 开机稳态后仅执行无损冷匿名页换出与 ZRAM 紧缩 (compact 模式)，不刷 drop_caches=3 保留热文件页
    sh "$MODDIR/ram_compact.sh" compact 2 >/dev/null 2>&1
    sync
    [ -w /sys/fs/cgroup/memory.force_swapout_percent ] && echo 75 > /sys/fs/cgroup/memory.force_swapout_percent 2>/dev/null
    [ -w /sys/fs/cgroup/memory.force_shrink_anon_percent ] && echo 75 > /sys/fs/cgroup/memory.force_shrink_anon_percent 2>/dev/null
    [ -w /sys/block/zram0/compact ] && echo 1 > /sys/block/zram0/compact 2>/dev/null
    [ -w /proc/sys/vm/drop_caches ] && echo 1 > /proc/sys/vm/drop_caches 2>/dev/null
    log_info "v5.3 黄金平衡冷匿名页压缩与 ZRAM 物理页紧缩已完成 (保留热代码页与 48 进程后台池)"
    return 0
}

if [ "$ENABLE_ZRAM" = "1" ]; then
    setup_zram
    sleep 20
    want=$(( $(awk '/MemTotal/ {print $2}' /proc/meminfo) * ZRAM_PERCENT / 100 * 1024 ))
    got=$(cat /sys/block/zram0/disksize 2>/dev/null)
    if [ -n "$got" ] && [ "$(( got > want ? got - want : want - got ))" -gt $(( want / 100 )) ]; then
        log_warn "复查发现 zram 容量被改动 ($got != $want)，重试一次"
        setup_zram
    fi
else
    log_info "ZRAM 调优已禁用"
fi

if [ "$ENABLE_VM" = "1" ]; then setup_vm; else log_info "VM 调优已禁用"; fi
if [ "${ENABLE_LMKD_PSI:-1}" = "1" ]; then lmkd --reinit >/dev/null 2>&1 || setprop lmkd.reinit 1 2>/dev/null; fi
refresh_pkg_cache
stop_unnecessary_daemons
deny_background
disable_apps
restrict_apps
printf "%s\n" "$CUR_CONF_SIG" > "$APPLIED_HASH_FILE" 2>/dev/null
apply_sys_mem_cages
reclaim_cold_pages

# v6.7.5: 双系统后台(最近任务)可用内存显示自动开启 (真机实测精准键值，零 LSPosed 依赖)
apply_recents_mem_info() {
    command -v settings >/dev/null 2>&1 || return 0
    _miui_ver="$(getprop ro.miui.ui.version.name 2>/dev/null)$(getprop ro.mi.os.version.name 2>/dev/null)"
    _oplus_ver="$(getprop ro.build.version.oplusrom 2>/dev/null)"
    if [ "$ROM_TYPE" = "HyperOS" ] || [ -n "$_miui_ver" ]; then
        settings put system miui_recents_show_mem_info 1 >/dev/null 2>&1
        log_info "最近任务内存显示: HyperOS/MIUI 已开启 (system/miui_recents_show_mem_info=1)"
    elif [ "$ROM_TYPE" = "ColorOS" ] || [ -n "$_oplus_ver" ]; then
        settings put secure allow_memory_info_display 1 >/dev/null 2>&1
        settings put secure display_memory_information_recent_task 1 >/dev/null 2>&1
        log_info "最近任务内存显示: ColorOS 已开启 (secure/allow_memory_info_display=1, display_memory_information_recent_task=1)"
    fi
}
apply_recents_mem_info

# 启动 Pure-C 主动极速墓碑与深度换出守护服务 (自动兼容原生二进制与 Shell 回退)
pkill -f "ballast_daemon" >/dev/null 2>&1
pkill -f "tombstone_daemon.sh" >/dev/null 2>&1
chmod 0755 "$MODDIR/bin/ballast_daemon" "$MODDIR/tombstone_daemon.sh" 2>/dev/null
if [ -x "$MODDIR/bin/ballast_daemon" ] && "$MODDIR/bin/ballast_daemon" --selftest >/dev/null 2>&1; then
    "$MODDIR/bin/ballast_daemon" daemon </dev/null >/dev/null 2>&1 &
    log_info "已启动 Pure-C Tombstone 原生守护进程 (bin/ballast_daemon daemon)"
elif [ -f "$MODDIR/tombstone_daemon.sh" ]; then
    sh "$MODDIR/tombstone_daemon.sh" </dev/null >/dev/null 2>&1 &
    log_info "已启动 Tombstone 守护进程 (Shell Fallback)"
fi

# v6.7.5: 启动下拉通知栏实时可用内存条守护 (默认开启，可通过 ram_notify off 随时关闭)
pkill -f "ram_notify_daemon.sh daemon" >/dev/null 2>&1
chmod 0755 "$MODDIR/ram_notify_daemon.sh" 2>/dev/null
if [ "${ENABLE_RAM_NOTIFY:-1}" = "1" ] && [ -f "$MODDIR/ram_notify_daemon.sh" ]; then
    nohup sh "$MODDIR/ram_notify_daemon.sh" daemon </dev/null >/dev/null 2>&1 &
    log_info "已启动下拉通知栏实时内存条 (ram_notify_daemon.sh)"
fi

chmod 0755 "$MODDIR/ram_compact.sh" 2>/dev/null
mkdir -p /data/adb/ksu/bin 2>/dev/null
ln -sf "$MODDIR/action.sh" /data/adb/ksu/bin/compress_ram 2>/dev/null
ln -sf "$MODDIR/bin/ballast_daemon" /data/adb/ksu/bin/ballast_daemon 2>/dev/null
printf '#!/system/bin/sh\nexec sh "%s/ram_compact.sh" clear "$@"\n' "$MODDIR" > /data/adb/ksu/bin/ram_clear 2>/dev/null
printf '#!/system/bin/sh\nexec sh "%s/ram_compact.sh" compact "$@"\n' "$MODDIR" > /data/adb/ksu/bin/ram_compact 2>/dev/null
printf '#!/system/bin/sh\nexec sh "%s/ram_notify_daemon.sh" "$@"\n' "$MODDIR" > /data/adb/ksu/bin/ram_notify 2>/dev/null
printf '#!/system/bin/sh\nexec sh "%s/ballast_probe.sh" "$@"\n' "$MODDIR" > /data/adb/ksu/bin/ballast_probe 2>/dev/null
chmod 0755 /data/adb/ksu/bin/ram_clear /data/adb/ksu/bin/ram_compact /data/adb/ksu/bin/ram_notify /data/adb/ksu/bin/ballast_probe 2>/dev/null

log_info "=== 调优执行完毕 ==="

sleep 3
STATUS_FILE="/data/adb/ksu_mem_opt.status"
sh "$MODDIR/check.sh" > "$STATUS_FILE" 2>&1
summary=$(tail -n 1 "$STATUS_FILE" | tr -d '-' | sed 's/^ *//')
if grep -q '^\[FAIL\]' "$STATUS_FILE"; then
    prefix="[⚠ ${ROM_TYPE} 部分未生效 $summary]"
else
    prefix="[✔ ${ROM_TYPE} 运行正常 $summary]"
fi
awk -v p="$prefix" '/^description=/ { printf "description=%s 16G 纯C运存优化（ColorOS/HyperOS 通用）\n", p; next } { print }' "$MODDIR/module.prop" > "$MODDIR/module.prop.new" && mv "$MODDIR/module.prop.new" "$MODDIR/module.prop"
log_info "自检完成 ($ROM_TYPE): $summary"
exit 0
