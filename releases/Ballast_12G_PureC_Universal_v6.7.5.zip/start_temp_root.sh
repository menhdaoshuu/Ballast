#!/system/bin/sh
# Ballast v6.7.5 临时 Root 免重启一键启动脚本 (无需 KernelSU/Magisk 模块管理器，支持从 /sdcard 解压直接运行)
# 用法:
#   su -c sh start_temp_root.sh          # 启动/热刷新全套调优与 Pure-C 守护进程
#   su -c sh start_temp_root.sh stop     # 停止守护进程并还原系统默认参数
#   su -c sh start_temp_root.sh status   # 查看当前运行状态与 MemAvailable

if [ "$(id -u)" != "0" ]; then
    echo "! 请使用 Root 权限执行: su -c sh $0"
    exit 1
fi

SRC_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
RUN_DIR="/data/local/tmp/ballast_run"
CONF="/data/adb/ksu_mem_opt.conf"
ACTION="${1:-start}"

if [ "$ACTION" = "stop" ]; then
    echo ">>> 正在停止 Ballast 临时 Root 守护进程并还原默认参数..."
    pkill -f "ballast_daemon|tombstone_daemon.sh|ram_notify_daemon.sh" >/dev/null 2>&1
    [ -f "$RUN_DIR/uninstall.sh" ] && sh "$RUN_DIR/uninstall.sh" >/dev/null 2>&1
    rm -rf "$RUN_DIR" 2>/dev/null
    echo "  ✓ 已停止并恢复原厂默认状态"
    exit 0
fi

if [ "$ACTION" = "status" ]; then
    pgrep -af "ballast_daemon" || echo "ballast_daemon 未运行"
    grep -E "MemTotal|MemAvailable|SwapFree" /proc/meminfo
    [ -r /sys/fs/cgroup/memory.avail_buffers ] && cat /sys/fs/cgroup/memory.avail_buffers
    exit 0
fi

echo "================================================"
echo " Ballast v6.7.5 临时 Root 免重启一键启动 (12G纯C)"
echo "================================================"
RAM_BEFORE=$(awk '/MemAvailable/ {print $2}' /proc/meminfo)

# 复制到可执行目录 /data/local/tmp/ballast_run (绕过 /sdcard 的 noexec 挂载限制)
mkdir -p "$RUN_DIR/bin" "$RUN_DIR/src" /data/adb 2>/dev/null
for _f in action.sh check.sh customize.sh post-fs-data.sh ram_compact.sh ram_notify_daemon.sh ballast_probe.sh service.sh tombstone_daemon.sh uninstall.sh module.prop; do
    [ -f "$SRC_DIR/$_f" ] && cp -f "$SRC_DIR/$_f" "$RUN_DIR/$_f"
done
[ -f "$SRC_DIR/bin/ballast_daemon" ] && cp -f "$SRC_DIR/bin/ballast_daemon" "$RUN_DIR/bin/ballast_daemon"
[ -f "$SRC_DIR/src/ballast_daemon.c" ] && cp -f "$SRC_DIR/src/ballast_daemon.c" "$RUN_DIR/src/ballast_daemon.c"
chmod 0755 "$RUN_DIR"/*.sh "$RUN_DIR/bin/ballast_daemon" 2>/dev/null

# 自动探测 ROM 并生成默认配置 (若尚不存在)
if [ ! -f "$CONF" ]; then
    if [ -n "$(getprop ro.mi.os.version.name)" ] || [ -n "$(getprop ro.miui.ui.version.name)" ] || [ -d /system_ext/app/miuisystem ]; then
        _rom="hyperos"
    elif [ -n "$(getprop ro.build.version.oplusrom)" ] || [ -n "$(getprop ro.oplus.version.base)" ]; then
        _rom="coloros"
    else
        _rom="generic"
    fi
    cat > "$CONF" <<EOF
ROM_TYPE="$_rom"
ENABLE_ZRAM=1
ZRAM_PERCENT=75
ZRAM_MEM_LIMIT_PERCENT=45
ENABLE_VM=1
ENABLE_LMKD_PSI=1
ENABLE_ART_OPT=1
ENABLE_SYS_CAGE=1
ENABLE_RAM_NOTIFY=1
ENABLE_RAM_NOTIFY_ACTION=1
SWAPPINESS=150
FREEZE_DELAY=10
BG_DENY_PKGS="com.tencent.mobileqq com.tencent.tim com.eg.android.AlipayGphone com.ss.android.ugc.aweme"
DISABLE_PKGS="com.heytap.openid com.oplus.midas com.oplus.sau com.coloros.securityguard com.oplus.framework.network.drs"
RESTRICT_PKGS="com.google.android.gms com.android.vending com.google.android.gsf com.mobiletools.systemhelper"
RECLAIM_PKGS="com.tencent.mm com.google.android.gms com.android.vending com.oplus.aiunit com.coloros.gallery3d com.oplus.screenshot com.android.mms com.oplus.exsystemservice com.heytap.mcs"
EOF
    echo "- 已生成临时 Root 配置文件: $CONF ($_rom)"
fi

# 1) 尝试热注入 LMKD PSI 与 ART 属性 (若环境含 resetprop)
[ -f "$RUN_DIR/post-fs-data.sh" ] && sh "$RUN_DIR/post-fs-data.sh" >/dev/null 2>&1

# 2) 重启守护并执行完整 service.sh (绕过开机等待，直接进入全量调优)
pkill -f "ballast_daemon|tombstone_daemon.sh|ram_notify_daemon.sh" >/dev/null 2>&1
rm -f /data/adb/ksu_mem_opt.applied_hash 2>/dev/null
echo "- 正在应用 ZRAM / VM / avail_buffers / 全量软笼与 Pure-C 守护进程..."
sh "$RUN_DIR/service.sh" >/dev/null 2>&1

RAM_AFTER=$(awk '/MemAvailable/ {print $2}' /proc/meminfo)
echo "------------------------------------------------"
echo "✔ 临时 Root 调优已免重启生效！"
echo "- MemAvailable: $((RAM_BEFORE / 1024)) MB -> $((RAM_AFTER / 1024)) MB"
echo "- 守护进程状态: $(pgrep -af ballast_daemon | head -n 1)"
echo "- 一键强力压缩: su -c sh $RUN_DIR/ram_compact.sh both 2"
echo "- 停止并还原  : su -c sh $0 stop"
echo "================================================"
